# Screens Documentation

This document provides comprehensive documentation for all screens in the `lib/screens/` folder.

## 📁 Screens Overview

```
lib/screens/
├── careRoutinePage/
│   ├── care_routine_page.dart      # Add/Edit care routine form
│   ├── care_routine_history.dart   # Care routine history & management
│   └── body_map_selector.dart      # Body part selection component
├── dashboard/
│   ├── dashboard_screen.dart       # Main dashboard with stats
│   ├── account_edit_page.dart      # User profile editing
│   ├── poem_dashboard_page.dart    # POEM assessment
│   ├── skin_analysis_page.dart     # Skin condition analysis
│   └── weather_page.dart           # Environmental data
├── triggersPage/
│   ├── triggers_page.dart          # Add/Edit trigger form
│   ├── triggers_history.dart       # Trigger history & management
├── insightsPage/
│   └── insights_page.dart          # Analytics and pattern insights
├── onboarding/
│   ├── onboarding_flow.dart        # Main onboarding controller
│   ├── step_one_page.dart          # Eczema severity assessment
│   ├── step_two_page.dart          # Affected areas selection
│   ├── step_three_page.dart        # Trigger preferences
│   ├── step_four_page.dart         # Goals and motivations
│   ├── step_five_page.dart         # Care routine preferences
│   └── step_six_page.dart          # Personal info (name, gender, birthdate, email, password)
├── welcome/
│   └── welcome_screen.dart         # App entry point
├── login/
│   ├── login_page.dart             # Authentication with error handling
│   └── forgot_password_page.dart   # Password reset flow
├── consent/
│   └── consent_page.dart           # Privacy consent
└── test/
    └── notification_test_screen.dart # Notification testing utility
```

---

## 🏠 Welcome & Authentication

### welcome_screen.dart
**Purpose:** App entry point with branding and navigation options

**Key Features:**
- App logo and branding
- GET STARTED button → Onboarding
- I HAVE AN ACCOUNT button → Login
- Developer menu (debug builds only)

**Navigation Flow:**
```
WelcomeScreen
├── → ConsentPage → OnboardingFlow
├── → LoginPage
└── → Developer Menu
    ├── → CareRoutinePage
    ├── → TriggersPage
    └── → NotificationTestScreen
```

**Usage:**
```dart
// Navigate to welcome (app entry point)
Navigator.pushReplacement(
  context,
  MaterialPageRoute(builder: (context) => WelcomeScreen()),
);
```

**UI Components:**
- CustomHeader equivalent styling
- Gradient background
- Primary/secondary buttons
- Developer dropdown menu

---

### login_page.dart
**Purpose:** User authentication and account access with smart error handling

**Key Features:**
- Email/password login
- "Remember Me" checkbox (14-day session)
- Smart error detection:
  - Email not found → Red highlight on email field
  - Wrong password → Red highlight on password field
- Form validation
- Authentication with Firebase
- Forgot Password link
- Auto-clear error highlighting on typing
- Navigation to dashboard on success

**UI/UX:**
```dart
// Error States
_emailHasError    // Red border & background on email field
_passwordHasError // Red border & background on password field

// Error Messages
"Email not found"  // When email doesn't exist in database
"Wrong password"   // When email exists but password is incorrect
```

**Session Management:**
```dart
// Remember Me checked
await _sessionService.saveRememberMeSession(
  userId: user.uid,
  email: email,
);
// Session valid for 14 days
```

**Usage:**
```dart
// Navigate to login
Navigator.push(
  context,
  MaterialPageRoute(builder: (context) => LoginPage()),
);
```

---

### forgot_password_page.dart
**Purpose:** Password reset flow with email verification

**Key Features:**
- Two-step process:
  1. Email verification (checks if email exists)
  2. New password entry with confirmation
- Email validation against Firestore and test credentials
- Password requirements (minimum 6 characters)
- Password confirmation matching
- Updates password in test credentials collection
- Success feedback and redirect to login

**Flow:**
```
User enters email
    ↓
System verifies email exists
    ↓ (if found)
User enters new password + confirmation
    ↓
Password updated in database
    ↓
Redirect to login page
```

**Usage:**
```dart
// Navigate to forgot password
Navigator.push(
  context,
  MaterialPageRoute(builder: (context) => ForgotPasswordPage()),
);
```

---

### consent_page.dart
**Purpose:** Privacy policy and data consent

**Key Features:**
- Privacy policy display
- Consent checkboxes
- Legal compliance
- Proceed to onboarding

---

## 🎯 Onboarding Flow

The onboarding process collects user information and preferences through a multi-step wizard.

### onboarding_flow.dart
**Purpose:** Main controller for the onboarding process

**Key Features:**
- Step navigation (1-6)
- Progress tracking
- Data collection coordination
- Validation between steps

**Data Flow:**
```dart
class OnboardingData {
  String? name;
  int? age;
  double? severityLevel;
  List<String> symptoms;
  List<String> affectedAreas;
  Map<String, dynamic> routinePreferences;
}
```

### step_one_page.dart
**Purpose:** Personal information collection

**Collects:**
- Full name
- Age
- Basic demographics

**UI Pattern:**
- CustomInputField for text inputs
- CustomDropdown for selections
- Navigation buttons

### step_two_page.dart
**Purpose:** Eczema severity assessment

**Features:**
- CustomSlider for severity rating (1-10)
- Dynamic color coding (green → blue → red)
- Visual feedback with labels

**Implementation:**
```dart
CustomSlider(
  value: severityLevel,
  min: 1.0,
  max: 10.0,
  divisions: 9,
  leftLabel: 'Mild',
  rightLabel: 'Severe',
  sliderType: CustomSliderType.severity,
  onChanged: (value) => setState(() => severityLevel = value),
)
```

### step_three_page.dart
**Purpose:** Symptoms selection

**Features:**
- Multi-select symptom chips
- Common symptoms pre-populated
- CustomChip components for selection

### step_four_page.dart
**Purpose:** Affected body areas

**Features:**
- BodyMapSelector integration
- Visual body part selection
- Area categorization

### step_five_page.dart
**Purpose:** Care routine preferences

**Features:**
- Routine type selection
- Frequency preferences
- Product categories

### step_six_page.dart
**Purpose:** Final setup and summary

**Features:**
- Data summary review
- Account creation
- Welcome message

---

## 🧴 Care Routine Management

### care_routine_page.dart
**Purpose:** Add/Edit care routine form

**Key Features:**
- Routine name and type selection
- Product information input
- Affected areas selection (BodyMapSelector)
- Application frequency settings
- Notes and instructions

**Form Fields:**
- Routine Name (CustomInputField)
- Routine Type (CustomDropdown)
- Product Name (CustomInputField)
- Affected Areas (BodyMapSelector)
- Frequency (CustomDropdown)
- Notes (CustomInputField with maxLines)

**Navigation:**
```dart
// Add new routine
Navigator.push(
  context,
  MaterialPageRoute(builder: (context) => CareRoutinePage()),
);

// Edit existing routine
Navigator.push(
  context,
  MaterialPageRoute(
    builder: (context) => CareRoutinePage(editingRoutine: routine),
  ),
);
```

**Usage Example:**
```dart
// Header with history access
CustomHeader(
  title: 'Add Care Routine',
  actions: [
    CustomIconButton(
      icon: Icons.history,
      onPressed: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => CareRoutineHistory()),
      ),
    ),
  ],
)
```

### care_routine_history.dart
**Purpose:** View and manage saved care routines

**Key Features:**
- List all saved routines
- Search functionality (CustomSearchBar)
- Statistics display (CustomStatCard)
- Edit/Delete actions
- FloatingActionButton for new routines

**Statistics Displayed:**
- Total routines count
- Routine types count
- This month's additions

**UI Components:**
```dart
// Search bar
CustomSearchBar(
  hintText: 'Search routines...',
  onChanged: (query) => _filterRoutines(query),
)

// Stats row
Row(
  children: [
    Expanded(child: CustomStatCard(
      title: 'Total Routines',
      value: routines.length.toString(),
      icon: Icons.medical_services,
      iconColor: AppColors.primaryBlue,
    )),
    // More stat cards...
  ],
)

// Empty state
CustomEmptyState(
  icon: Icons.medical_services,
  title: 'No Routines Added',
  message: 'Create your first care routine to start tracking.',
  customAction: HintWidget('Tap the + button to create your first routine'),
)
```

### body_map_selector.dart
**Purpose:** Interactive body part selection component

**Key Features:**
- Categorized body parts (Head & Face, Arms & Hands, etc.)
- Search functionality
- Multi-select with visual feedback
- Selected areas summary
- Expandable categories

**Usage:**
```dart
BodyMapSelector(
  selectedAreas: selectedAreas,
  onAreasChanged: (Set<String> areas) {
    setState(() => selectedAreas = areas);
  },
  showSearchBar: true,
  showSelectedAreasHeader: true,
  height: 400,
)
```

---

## ⚠️ Triggers Management

### triggers_page.dart
**Purpose:** Add/Edit trigger form

**Key Features:**
- Trigger category selection (segmented control)
- Specific trigger input with suggestions
- Severity impact (CustomSlider)
- Reaction time selection
- Affected areas (BodyMapSelector)
- Symptoms triggered (multi-select chips)
- Date identification
- Confidence level (optional CustomSlider)
- Notes field

**Form Sections:**
```dart
// Category selection
_buildTriggerCategorySection() // Horizontal scrolling tabs

// Trigger input with suggestions
CustomInputField(
  label: 'Specific Trigger',
  hintText: 'Enter trigger name',
  controller: specificTriggerController,
)

// Severity slider
CustomSlider(
  title: 'Severity Impact',
  value: severityImpact,
  min: 1, max: 10,
  sliderType: CustomSliderType.severity,
  onChanged: (value) => setState(() => severityImpact = value),
)

// Confidence slider (optional)
if (confidenceLevel != null)
  CustomSlider(
    title: 'Confidence Level (Optional)',
    value: confidenceLevel!,
    min: 0, max: 100,
    sliderType: CustomSliderType.confidence,
    isOptional: true,
    onClear: () => setState(() => confidenceLevel = null),
  )
```

**Navigation:**
```dart
// Add new trigger
Navigator.push(
  context,
  MaterialPageRoute(builder: (context) => TriggersPage()),
);

// Edit existing trigger
Navigator.push(
  context,
  MaterialPageRoute(
    builder: (context) => TriggersPage(editingTrigger: trigger),
  ),
);
```

### triggers_history.dart
**Purpose:** View and manage saved triggers

**Key Features:**
- List all saved triggers
- Search functionality
- Statistics (total, categories, monthly)
- Filter by category/symptoms
- Edit/Delete actions
- FloatingActionButton for new triggers

**Statistics:**
- Total triggers
- Categories count
- This month's additions

**UI Implementation:**
```dart
// Using custom components
CustomHeader(title: 'Triggers History')

CustomSearchBar(
  hintText: 'Search triggers...',
  onChanged: (value) => setState(() => searchQuery = value),
)

// Stats row with custom cards
Row(
  children: [
    Expanded(child: CustomStatCard(
      title: 'Total Triggers',
      value: triggers.length.toString(),
      icon: Icons.warning_amber_rounded,
      iconColor: AppColors.primaryBlue,
    )),
    // More cards...
  ],
)

// Empty state
CustomEmptyState(
  icon: Icons.warning_amber_rounded,
  title: 'No Triggers Added',
  message: 'Start tracking your eczema triggers.',
  actionText: 'Add Your First Trigger',
  onActionPressed: _addNewTrigger,
)
```

---

## 🔧 Development Utilities

### notification_test_screen.dart
**Purpose:** Development tool for testing notifications

**Features:**
- Send test notifications
- Notification scheduling
- Permission testing
- Debug information

**Usage:** Accessible through developer menu in welcome screen

---

## 📱 Screen Navigation Patterns

### Primary Navigation Flow
```
WelcomeScreen
├── ConsentPage → OnboardingFlow → MainApp
└── LoginPage → MainApp
```

### Feature Navigation Pattern
```
FeatureHistory (List View)
├── FloatingActionButton → FeatureForm (Add)
├── Edit Action → FeatureForm (Edit)
├── Delete Action → Confirmation Dialog
└── Search → Filtered List
```

### Form Navigation Pattern
```
FeatureForm
├── Back Button → Previous Screen
├── History Icon → FeatureHistory
├── Save Button → Success + Back
└── Validation Error → Stay with Message
```

---

## 🎨 Design Consistency

### Background Colors
- **Forms & Input Pages:** `Color(0xFFF7F7F7)` (flat)
- **History & List Pages:** `Color(0xFFF7F7F7)` (flat)
- **Welcome & Onboarding:** `AppColors.backgroundGradient`

### Layout Patterns
```dart
// Standard page structure
Scaffold(
  backgroundColor: Color(0xFFF7F7F7),
  body: SafeArea(
    child: Column(
      children: [
        CustomHeader(title: 'Page Title'),
        Expanded(child: _buildContent()),
      ],
    ),
  ),
  floatingActionButton: FloatingActionButton(/* add action */),
)
```

### Header Patterns
```dart
// Form pages
CustomHeader(
  title: 'Add/Edit Item',
  actions: [
    CustomIconButton(
      icon: Icons.history,
      onPressed: () => _openHistory(),
    ),
  ],
)

// History pages
CustomHeader(title: 'Item History')
```

---

## 📊 Data Management

### Storage Pattern
```dart
// Each feature has its own storage service
- TriggerStorage (triggers_storage.dart)
- CareRoutineStorage (care_routine_storage.dart)

// Common methods:
- getAllItems()
- saveItem(item)
- updateItem(id, item)
- deleteItem(id)
- getItemById(id)
```

### Model Pattern
```dart
// Each feature has its own model
- TriggerModel (trigger_model.dart)
- Care routine uses Map<String, dynamic>

// Common model structure:
- id (String)
- createdAt (DateTime)
- lastModified (DateTime)
- toMap() / fromMap() methods
- copyWith() method
```

---

## 🔄 State Management

### Form State Pattern
```dart
class _FeaturePageState extends State<FeaturePage> {
  // Controllers for input fields
  final TextEditingController nameController = TextEditingController();

  // Form state variables
  String selectedCategory = 'Default';
  double sliderValue = 5.0;
  Set<String> selectedItems = <String>{};

  // Lifecycle
  @override
  void initState() {
    super.initState();
    _initializeForEditing(); // If editing existing item
  }

  @override
  void dispose() {
    nameController.dispose();
    super.dispose();
  }
}
```

### List State Pattern
```dart
class _FeatureHistoryState extends State<FeatureHistory> {
  List<FeatureModel> items = [];
  bool isLoading = true;
  String searchQuery = '';

  @override
  void initState() {
    super.initState();
    _loadItems();
  }

  List<FeatureModel> get filteredItems {
    if (searchQuery.isEmpty) return items;
    return items.where((item) =>
      item.name.toLowerCase().contains(searchQuery.toLowerCase())
    ).toList();
  }
}
```

---

## 📊 Dashboard & Account Management

### dashboard_screen.dart
**Purpose:** Main user dashboard with personalized stats and navigation

**Key Features:**
- Personalized welcome message (`Hi, {firstName}!`)
- Real-time statistics (daily logs, weekly logs)
- Severity assessment display (POEM score-based)
- Hamburger menu drawer with:
  - User profile (avatar, name, email)
  - Account editing option
  - Logout with confirmation dialog
- Bottom navigation bar
- Integration with Firestore for real-time data

**Hamburger Menu:**
```dart
Drawer(
  ├── DrawerHeader
  │   ├── User Avatar (CircleAvatar)
  │   ├── Full Name
  │   └── Email Address
  ├── Account ListTile → AccountEditPage
  ├── Divider
  └── Logout ListTile → Confirmation → LoginPage
)
```

**Auto-Refresh:**
- Dashboard refreshes user data when returning from account edit
- Ensures name changes reflect immediately

**Navigation:**
```dart
// On logout
Navigator.pushAndRemoveUntil(
  context,
  MaterialPageRoute(builder: (context) => LoginPage()),
  (route) => false,
);
```

---

### account_edit_page.dart
**Purpose:** User profile editing with clean UI

**Key Features:**
- Edit first name and last name (middle initial removed)
- Edit gender (dropdown)
- Edit birthdate (date picker with app theme)
- Email display (read-only)
- Form validation
- Save changes to Firestore
- Success/error feedback

**UI Components:**
```dart
_buildTextField()       // Standard text input
_buildGenderDropdown()  // Gender selection
_buildBirthdateField()  // Date picker with theme
_buildSaveButton()      // Submit button
```

**Birthdate Picker Theme:**
- Primary color: `AppColors.primaryBlue`
- Custom dialog theme matching app design
- MM/DD/YYYY format display
- Border and dropdown arrow for better UX

**Data Flow:**
```
Load user data from Firestore
    ↓
User edits fields
    ↓
Validate changes
    ↓
Save to Firestore
    ↓
Success message + Navigate back
    ↓
Dashboard refreshes automatically
```

**Usage:**
```dart
// Navigate to account edit
Navigator.push(
  context,
  MaterialPageRoute(builder: (context) => AccountEditPage()),
);
```

---

## 🔔 Testing & Debug Tools

### notification_test_screen.dart
**Purpose:** Development utility for testing notification system

**Location:** `lib/screens/test/notification_test_screen.dart`

**Key Features:**
- Test immediate notifications
- Test minutely repeating notifications
- Test hourly repeating notifications
- Test daily notifications
- View pending notifications
- Cancel all notifications
- Color-coded buttons for different actions

**Access:**
- Available in Care Routine Page → Debug Tools panel
- 3-button debug panel includes "Notification Test" button

**Usage:**
```dart
// Navigate to notification test
Navigator.push(
  context,
  MaterialPageRoute(builder: (context) => NotificationTestScreen()),
);
```

---

## 🔐 Session Management & Auto-Login

### AuthWrapper (core/auth/auth_wrapper.dart)
**Purpose:** Handle automatic login on app start

**Key Features:**
- Checks for valid "Remember Me" session (14 days)
- Auto-authenticates user if session valid
- Shows loading indicator during check
- Redirects to dashboard if authenticated
- Redirects to welcome screen if not authenticated

**Session Flow:**
```
App starts
    ↓
AuthWrapper checks session
    ↓ (valid session found)
Auto-login with saved credentials
    ↓
Navigate to Dashboard
```

**Integration:**
```dart
// main.dart
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const AuthWrapper(), // Entry point
    );
  }
}
```

---

## 📝 Onboarding Updates

### step_six_page.dart
**Purpose:** Final onboarding step - Personal information collection

**Updated Fields:**
- First Name
- Last Name
- Gender (dropdown)
- **Birthdate** (new field with date picker)
- Email Address
- Password

**Birthdate Implementation:**
- Required field for form validation
- Default initial date: 20 years ago
- Date picker with app theme colors
- MM/DD/YYYY display format
- Saves as ISO 8601 string

**Form Validation:**
```dart
bool get isFormValid {
  return firstNameController.text.isNotEmpty &&
         lastNameController.text.isNotEmpty &&
         selectedGender.isNotEmpty &&
         selectedBirthdate != null &&  // New requirement
         emailController.text.isNotEmpty &&
         passwordController.text.isNotEmpty;
}
```

---

This documentation provides a complete overview of all screens, their purposes, key features, and implementation patterns. Each screen follows consistent design principles and uses the custom widgets for optimal performance and maintainability.

## 🔄 Recent Updates Summary

### Authentication & Security
- Implemented "Remember Me" with 14-day session (industry standard)
- Auto-login on app restart
- Forgot password flow with email verification
- Smart error detection (email vs password highlighting)
- Session service with automatic expiration

### User Experience
- Removed middle initial from forms
- Added birthdate to onboarding step 6
- Improved birthdate UI with themed date picker
- Dashboard hamburger menu with profile
- Account editing with immediate refresh
- Logout redirects to login page (not welcome)

### Code Organization
- Moved auth logic to `core/auth/auth_wrapper.dart`
- Created `config/` folder for Firebase options
- Created `utils/` folder for seed data
- Organized test screens in `screens/test/`
- Cleaned up main.dart (minimal and focused)