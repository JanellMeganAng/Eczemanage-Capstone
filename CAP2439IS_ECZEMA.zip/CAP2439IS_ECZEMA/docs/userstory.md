# EczeManage User Story

## My Journey with EczeManage: A Complete User Walkthrough

### Background
*"Hi, I'm Sarah, and I've been dealing with eczema for the past few years. The flare-ups have been unpredictable, and I've struggled to identify what triggers them or which treatments actually work. I recently discovered the EczeManage app, and I'm hoping it will help me better understand and manage my condition."*

---

## First Time Experience

### 1. **Welcome Screen**
When I first open the app, I see the EczeManage welcome screen with a clean gradient background and the app logo.

**What I see:**
- "EczeManage" title in large text
- "Your personal companion for managing eczema with confidence" subtitle
- Two buttons: "GET STARTED" and "I HAVE AN ACCOUNT"

**What I do:**
- Since this is my first time, I tap **"GET STARTED"**

---

### 2. **Consent Page**
The app shows me a consent form explaining how my data will be used.

**What I do:**
- I read through the consent information
- I tap the checkbox to agree to the terms
- I tap **"Continue"** to proceed

---

### 3. **Sign-Up Flow (6 Steps)**

The app takes me through 6 onboarding steps to understand my eczema condition. I can see my progress with dots at the top of the screen.

#### **Step 1: Eczema History**
**Question:** "Which of these applies to you?"

**What I do:**
- I see three options: "Diagnosed with eczema", "Suspected eczema", "Family member has eczema"
- I select **"Diagnosed with eczema"**
- I tap **"Next"** to continue

#### **Step 2: Severity Assessment**
**Question:** "How severe is your eczema currently?"

**What I do:**
- I see a slider from 0-10 (Mild to Severe)
- I drag the slider to **7** because my eczema has been quite bothersome lately
- I tap **"Next"**

#### **Step 3: Body Area Selection**
**Question:** "Which areas are affected?"

**What I do:**
- I see an interactive body map showing front and back views
- I tap on the areas where I have eczema: **"Arms"**, **"Hands"**, and **"Legs"**
- The selected areas highlight in blue
- I tap **"Next"**

#### **Step 4: Trigger Identification**
**Question:** "What triggers your eczema?"

**What I do:**
- I see multiple categories with common triggers
- I select: **"Stress"**, **"Dry weather"**, **"Certain soaps"**, and **"Pollen"**
- I tap **"Next"**

#### **Step 5: Goal Setting**
**Question:** "What are your goals?"

**What I do:**
- I select my management goals:
  - ✓ **"Reduce flare-ups"**
  - ✓ **"Identify triggers"**
  - ✓ **"Track treatment effectiveness"**
  - ✓ **"Better sleep quality"**
- I tap **"Next"**

#### **Step 6: Account Creation**
**Final step:** Creating my account credentials

**What I do:**
- I enter my **email**: sarah.chen@email.com
- I create a **password**: ••••••••
- I enter my **first name**: Sarah
- I enter my **last name**: Chen
- I select my **gender**: Female
- I tap **"Complete Sign-Up"**

**What happens:**
- The app creates my account
- I see a success message
- I'm automatically taken to my Dashboard

---

## My Dashboard (Day 1)

I arrive at my personalized dashboard that says **"Hi, Sarah!"**

### What I see on my Dashboard:

1. **Your Progress Overview Card**
   - Circular gauge showing 0% complete (I haven't logged anything yet)
   - "0 Logs Today" and "0 This Week"
   - Daily Goal Progress: 0/5 entries

2. **Action Buttons**
   - **"POEM Assessment"** - Track eczema impact on daily life
   - **"Skin Analysis"** - Analyze affected body areas

3. **Last Severity Check**
   - Shows my initial severity rating: 7 (Moderate)
   - EASI factors breakdown:
     - Erythema (Redness): 2/3
     - Edema/Papulation (Swelling): 3/3
     - Excoriation (Scratching Damage): 0/3
     - Lichenification (Skin Thickening): 1/3
   - Affected area: Arms

4. **Recommended Actions**
   - High severity alert suggesting dermatologist visit
   - Moisturize reminder

5. **Goals Status**
   - Daily Symptom Logging: 0%
   - Weekly Assessment: 0%

6. **Recent Logs**
   - Empty (since I just started)

### What I do:
- I tap the **hamburger menu** (three lines) in the top left to explore the menu
- I see my profile photo, name, and email
- Menu options:
  - **Account** - Edit my profile
  - **Logout** - Sign out

---

## Taking My First POEM Assessment

I decide to take the POEM assessment to establish a baseline.

**What I do:**
1. From the Dashboard, I tap **"POEM Assessment"**
2. A dialog appears explaining: "The Patient-Oriented Eczema Measure (POEM) helps assess the impact of eczema on your daily life"
3. I tap **"Start"**

**The Assessment:**
I answer 7 questions about the past week (0-4 scale: No days, 1-2 days, 3-4 days, 5-6 days, Every day):

1. *"How many days has your skin been itchy?"* → **5-6 days**
2. *"How many days has your sleep been disturbed?"* → **3-4 days**
3. *"How many days has your skin been bleeding?"* → **1-2 days**
4. *"How many days has your skin been weeping/oozing?"* → **No days**
5. *"How many days has your skin been cracked?"* → **3-4 days**
6. *"How many days has your skin been flaking?"* → **Every day**
7. *"How many days has your skin felt dry/rough?"* → **Every day**

**Result:**
- My POEM score: **18 out of 28** (Moderate to Severe)
- The app categorizes this as "Moderate to Severe Impact"
- I can see my score history in a graph
- I tap **"Back to Dashboard"**

---

## Performing Skin Analysis

Next, I want to do a detailed skin analysis.

**What I do:**
1. From Dashboard, I tap **"Skin Analysis"**
2. A dialog explains: "Select the area of your body affected by eczema for a more detailed assessment"
3. I tap **"Select Area"**

**The Analysis Process:**
1. I see an interactive body map
2. I tap **"Arms"** to analyze that area
3. The app asks me detailed questions:
   - **Erythema (Redness):** "Rate the redness" → I select **2 (Moderate)**
   - **Edema/Papulation (Swelling):** "Rate the swelling" → I select **3 (Severe)**
   - **Excoriation (Scratching damage):** → I select **1 (Mild)**
   - **Lichenification (Thickening):** → I select **2 (Moderate)**
   - **Area affected:** "What percentage?" → I estimate **30%**

4. I tap **"Save Analysis"**

**What happens:**
- The app calculates my regional EASI score
- I can see this analysis in my Skin Analysis History
- I return to Dashboard

---

## Creating My First Care Routine

I want to set up reminders for my skincare routine.

**What I do:**
1. From the bottom navigation bar, I tap **"Care Routine"** (second icon)
2. I tap **"Add New Routine"** or the + button

**Setting up the routine:**

1. **Routine Name:** "Morning Moisturizer"
2. **Routine Type:** Select **"Moisturizer"** from dropdown
3. **Product/Medication:** "CeraVe Moisturizing Cream"
4. **Application Areas:**
   - I tap the body map and select: **Arms**, **Hands**, **Legs**
   - Selected areas show as blue chips above the map
5. **Frequency & Interval:**
   - Frequency: **"Daily"**
   - Interval: **"Every 12 hours"**
6. **Time of Day:**
   - I select the icons for: **Morning** ☀️ and **Evening** 🌙
7. **Reminder:**
   - Toggle is ON (I want notifications)
8. **Notes:** "Apply within 3 minutes of showering"

**What I do:**
- I tap **"Save Care Routine"**

**What happens:**
- Success message: "Care routine saved with reminders!"
- The app schedules notifications for my selected times
- I immediately get a confirmation notification
- I can see my routine in the Care Routine History

---

## Logging My Triggers

I had a flare-up today after using a new soap, so I want to log this trigger.

**What I do:**
1. From the bottom navigation, I tap **"Triggers"** (third icon)
2. I tap **"Add Trigger"**

**Logging the trigger:**

1. **Trigger Category:**
   - I see a horizontal scroll of categories
   - I select **"Products"**

2. **Specific Trigger:**
   - The app suggests common products: Soap, Shampoo, Laundry detergent...
   - I tap on **"Soap"** suggestion
   - It auto-fills "Soap" in the text field

3. **Severity Impact:**
   - I drag the slider to **8** (this really bothered my skin)

4. **Reaction Time:**
   - I select **"Within hours"** from dropdown

5. **Affected Areas:**
   - I see the body map
   - I tap **"Hands"** (where I used the soap)
   - It shows as a blue chip above the map

6. **Symptoms Triggered:**
   - I select multiple symptoms by tapping:
     - ✓ **Itching**
     - ✓ **Redness**
     - ✓ **Dryness**
     - ✓ **Burning sensation**

7. **Date Identified:**
   - I tap the calendar icon
   - I select **today's date**

8. **Confidence Level (Optional):**
   - I tap "Add Confidence Level"
   - I set the slider to **90%** (I'm very confident this was the trigger)

9. **Notes:**
   - I type: "Used new brand of hand soap at work. Hands started itching within an hour."

**What I do:**
- I tap **"Save Trigger"**

**What happens:**
- Success message: "Trigger saved successfully!"
- I can view this in my Triggers History
- The app will use this data for insights

---

## Viewing My Insights

After a few weeks of logging, I want to see what patterns the app has identified.

**What I do:**
1. From the bottom navigation, I tap **"Insights"** (fourth icon)

**What I see:**

**Filters Section:**
- Date Range: "Last month" (I change it from "Last week")
- Insight Categories (I can toggle these on/off):
  - ✓ Weather trends
  - ✓ Care routine effectiveness
  - ✗ Trigger patterns (I turn this on)
  - ✓ Symptom correlations
- Severity Filter: Slider set to show insights rated 5+ severity

**My Insights:**

**Insight Card 1: Weather Impact Pattern**
- Category: Weather trends
- Severity: 7 (Orange badge - Moderate)
- Description: "High humidity days (>70%) correlate with 65% increase in flare-ups"
- 💡 Actionable Change: "Consider using a dehumidifier when humidity exceeds 70%"
- Buttons: [Helpful 👍] [Not Relevant 👎]
- I tap **"Helpful"** ✓

**Insight Card 2: Care Routine Effectiveness**
- Category: Care routine effectiveness
- Severity: 4 (Green badge - Mild)
- Description: "Moisturizer application within 3 minutes of showering reduces symptoms by 40%"
- 💡 Actionable Change: "Apply moisturizer immediately after bathing for optimal results"
- I tap **"Helpful"** ✓

**Insight Card 3: Trigger Pattern**
- Category: Trigger patterns
- Severity: 8 (Red badge - Severe)
- Description: "Soap products trigger flare-ups in 85% of logged instances"
- 💡 Actionable Change: "Switch to fragrance-free, hypoallergenic soap alternatives"
- I tap **"Helpful"** ✓

**What I do:**
- I tap the **Share icon** (top right)
- I select **"Share with doctor"**
- The app generates a PDF report with all my insights
- I can email it directly to my dermatologist

---

## Notification Experience

Throughout my day, I receive helpful reminders:

**9:00 AM:**
> **Good morning! Time for your Morning Moisturizer**
>
> Apply CeraVe Moisturizing Cream to your arms, hands, and legs to keep your skin hydrated 💧

**What I do:**
- I tap the notification
- The app opens to my Care Routine page
- I complete the routine
- I can mark it as "Done" (optional feature)

**9:00 PM:**
> **Good evening! Time for your Morning Moisturizer**
>
> Apply CeraVe Moisturizing Cream to your arms, hands, and legs to keep your skin hydrated 💧

---

## Editing My Profile

I realize I want to update some information.

**What I do:**
1. From Dashboard, I tap the **hamburger menu** (☰)
2. I tap **"Account"**

**Account Edit Page:**
I can edit:
- First Name
- Last Name
- Email
- Gender
- Birthdate
- Password (with current password verification)

**What I do:**
- I update my birthdate
- I tap **"Save Changes"**
- Success message appears
- I tap **"Back"** to return to Dashboard

---

## Viewing My History

### Care Routine History
**What I do:**
1. Go to Care Routine page
2. Tap the **History icon** (top right)

**What I see:**
- List of all my saved routines
- "Morning Moisturizer" - Created 2 weeks ago
- Each routine shows: Name, Product, Frequency, Areas
- I can tap to view details, edit, or delete

### Triggers History
**What I do:**
1. Go to Triggers page
2. Tap the **History icon** (top right)

**What I see:**
- All my logged triggers sorted by date
- Each shows: Category, Specific trigger, Severity, Date
- I can filter by category or severity
- I can tap any trigger to view full details or edit

### POEM History
**What I do:**
1. From Dashboard, tap "POEM Assessment"
2. Tap "View History"

**What I see:**
- Graph showing my POEM scores over time
- I can see trends (improving, stable, worsening)
- Each assessment is clickable to see detailed answers

### Skin Analysis History
**What I do:**
1. From Dashboard, tap "Skin Analysis"
2. Tap "View History"

**What I see:**
- Timeline of all my skin analyses
- Organized by body area and date
- EASI scores for each region
- Visual comparison over time

---

## After 30 Days - Progress Review

After a month of consistent use, my Dashboard looks different:

**Your Progress Overview:**
- **Circular gauge: 80% complete**
- Logs Today: 4/5
- This Week: 18 logs
- Daily Goal Progress: 4/5 entries (4 filled dots)

**Last Severity Check:**
- EASI Score improved from 7 to **4** (Mild) 🎉
- Color changed from Orange to Green

**Goals Status:**
- Daily Symptom Logging: **80%** progress
- Weekly Assessment: **76%** progress

**Recent Logs:**
- Shows my last 5 activities with timestamps

**Recommended Actions:**
- "Great progress! Keep up your routine 🎉"
- "Remember to apply moisturizer tonight"

---

## Key App Features I Use Regularly

### Bottom Navigation Bar (Always visible):
1. **🏠 Dashboard** - Overview and quick actions
2. **💊 Care Routine** - My skincare schedule
3. **⚠️ Triggers** - Log what causes flare-ups
4. **📈 Insights** - AI-generated patterns

### Top Navigation (Hamburger Menu):
- **Account** - Edit profile info
- **Logout** - Sign out of app

---

## My Journey Summary

**Week 1:**
- Created account ✓
- Took baseline POEM assessment ✓
- Set up care routine with reminders ✓
- Logged first trigger ✓

**Week 2:**
- Consistently logged daily activities
- Started seeing first insights
- Adjusted care routine timing

**Week 3:**
- Identified 3 major triggers (soap, pollen, stress)
- Modified routine based on insights
- POEM score improved to 14

**Week 4:**
- Established consistent routine
- Sharing insights with dermatologist
- EASI score dropped from 7 to 4
- Sleep quality improved

---

## What Makes EczeManage Helpful for Me

1. **Personalized Tracking:** The app learns MY specific patterns, not generic eczema advice

2. **Smart Reminders:** I never forget my moisturizer anymore thanks to timely notifications

3. **Trigger Identification:** I discovered that 3 PM stress at work correlates with evening flare-ups

4. **Visual Progress:** Seeing my EASI score drop from 7 to 4 motivates me to keep going

5. **Doctor Communication:** I can share professional reports with my dermatologist instead of trying to remember everything

6. **Body Map:** Pinpointing exact areas helps me see which regions improve or worsen

7. **Actionable Insights:** Instead of just showing data, the app tells me *what to do differently*

---

## Key Pages Navigation Summary

**To access each feature:**

| Feature | How to Get There |
|---------|------------------|
| Dashboard | Tap "Dashboard" icon (bottom nav - 1st) |
| POEM Assessment | Dashboard → "POEM Assessment" button |
| Skin Analysis | Dashboard → "Skin Analysis" button |
| Care Routine | Tap "Care Routine" icon (bottom nav - 2nd) |
| Add Care Routine | Care Routine → "+" or "Add New Routine" |
| Care Routine History | Care Routine → History icon (top right) |
| Triggers | Tap "Triggers" icon (bottom nav - 3rd) |
| Add Trigger | Triggers → "Add Trigger" |
| Trigger History | Triggers → History icon (top right) |
| Insights | Tap "Insights" icon (bottom nav - 4th) |
| Account Settings | Dashboard → Menu (☰) → "Account" |
| Logout | Dashboard → Menu (☰) → "Logout" |

---

## Final Thoughts

*"EczeManage has transformed how I manage my eczema. Instead of feeling helpless during flare-ups, I now have data-backed insights showing me exactly what helps and what hurts. The app has become my digital dermatology assistant, helping me take control of my skin health one day at a time."*

**- Sarah Chen, EczeManage User**

---

*Document Version: 1.0*
*Last Updated: 2025*
*For: EczeManage Mobile Application*
