# Custom Widgets Documentation

This document provides comprehensive documentation for all custom widgets in the `lib/core/widgets/` folder.

## 📁 Widgets Overview

### Import Usage
```dart
import '../../core/widgets/index.dart'; // Import all widgets at once
```

---

## 1. 🏷️ CustomHeader

**File:** `custom_header.dart`

A standardized header component used across all pages for consistent navigation and branding.

### Properties
| Property | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `title` | `String` | ✅ Yes | - | Main title text displayed in center |
| `onBackPressed` | `VoidCallback?` | ❌ No | `Navigator.pop(context)` | Custom back button action |
| `actions` | `List<Widget>?` | ❌ No | `null` | Right-side action buttons |
| `showBackButton` | `bool` | ❌ No | `true` | Show/hide back button |

### Usage Examples
```dart
// Basic header
CustomHeader(title: 'Page Title')

// Header with custom back action
CustomHeader(
  title: 'Settings',
  onBackPressed: () => _handleCustomBack(),
)

// Header with action buttons
CustomHeader(
  title: 'Triggers History',
  actions: [
    CustomIconButton(
      icon: Icons.history,
      onPressed: () => _openHistory(),
    ),
  ],
)

// Header without back button
CustomHeader(
  title: 'Welcome',
  showBackButton: false,
)
```

### Design Specifications
- Height: Auto (padding: 24px horizontal, 20px vertical)
- Background: Transparent
- Title: Quicksand font, 28px, bold, primaryBlue
- Back button: 44x44px, rounded 12px, primaryBlue with 10% opacity background
- Person icon: Always shown on right unless custom actions provided

---

## 2. 📝 CustomInputField

**File:** `custom_input_field.dart`

Reusable text input field with consistent styling across the app.

### Properties
| Property | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `label` | `String?` | ❌ No | `null` | Field label text |
| `hintText` | `String?` | ❌ No | `null` | Placeholder text |
| `controller` | `TextEditingController?` | ❌ No | `null` | Text controller |
| `maxLines` | `int` | ❌ No | `1` | Maximum lines (1 for single line, >1 for textarea) |
| `keyboardType` | `TextInputType` | ❌ No | `TextInputType.text` | Keyboard type |
| `enabled` | `bool` | ❌ No | `true` | Enable/disable field |
| `suffixIcon` | `Widget?` | ❌ No | `null` | Icon/widget on right side |
| `onChanged` | `Function(String)?` | ❌ No | `null` | Text change callback |
| `validator` | `String? Function(String?)?` | ❌ No | `null` | Form validation function |

### Usage Examples
```dart
// Basic text field
CustomInputField(
  label: 'Product Name',
  hintText: 'Enter product name',
  controller: productNameController,
)

// Multi-line notes field
CustomInputField(
  label: 'Notes',
  hintText: 'Add your notes here...',
  maxLines: 4,
  controller: notesController,
)

// Email field with validation
CustomInputField(
  label: 'Email',
  hintText: 'your@email.com',
  keyboardType: TextInputType.emailAddress,
  validator: (value) {
    if (value?.contains('@') != true) return 'Invalid email';
    return null;
  },
)

// Field with suffix icon
CustomInputField(
  label: 'Password',
  suffixIcon: Icon(Icons.visibility),
  controller: passwordController,
)
```

### Design Specifications
- Background: lightGrey color
- Border radius: 12px
- Padding: 16px all sides
- Font: OpenSans, 16px
- Label: OpenSans, 14px, bold, darkBlue
- Hint: OpenSans, 16px, greyText

---

## 3. 📋 CustomDropdown<T>

**File:** `custom_dropdown.dart`

Generic dropdown component that works with any data type.

### Properties
| Property | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `label` | `String?` | ❌ No | `null` | Field label |
| `value` | `T?` | ✅ Yes | - | Currently selected value |
| `items` | `List<T>` | ✅ Yes | - | List of dropdown options |
| `itemLabel` | `String Function(T)` | ✅ Yes | - | Function to get display text from item |
| `onChanged` | `Function(T?)` | ✅ Yes | - | Selection change callback |
| `hintText` | `String?` | ❌ No | `null` | Placeholder text |

### Usage Examples
```dart
// String dropdown
CustomDropdown<String>(
  label: 'Reaction Time',
  value: selectedReactionTime,
  items: ['Immediate', 'Within hours', 'Within days', 'Variable'],
  itemLabel: (item) => item,
  onChanged: (value) => setState(() => selectedReactionTime = value),
)

// Object dropdown
CustomDropdown<Category>(
  label: 'Category',
  value: selectedCategory,
  items: categories,
  itemLabel: (category) => category.name,
  onChanged: (value) => _handleCategoryChange(value),
)

// Enum dropdown
CustomDropdown<Priority>(
  label: 'Priority',
  value: selectedPriority,
  items: Priority.values,
  itemLabel: (priority) => priority.toString().split('.').last,
  onChanged: (value) => setState(() => selectedPriority = value),
)
```

### Design Specifications
- Same styling as CustomInputField
- Arrow icon: keyboard_arrow_down, primaryBlue
- Dropdown background: white
- Item padding: 16px

---

## 4. 🔘 CustomIconButton

**File:** `custom_icon_button.dart`

Reusable icon button with consistent styling and touch targets.

### Properties
| Property | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `icon` | `IconData` | ✅ Yes | - | Icon to display |
| `onPressed` | `VoidCallback` | ✅ Yes | - | Tap callback |
| `backgroundColor` | `Color?` | ❌ No | `primaryBlue.withAlpha(0.1)` | Background color |
| `iconColor` | `Color?` | ❌ No | `primaryBlue` | Icon color |
| `size` | `double` | ❌ No | `44` | Button size (width & height) |
| `iconSize` | `double` | ❌ No | `20` | Icon size |
| `margin` | `EdgeInsets?` | ❌ No | `null` | External margin |
| `isCircular` | `bool` | ❌ No | `false` | Circular vs rounded rectangle |

### Usage Examples
```dart
// Basic icon button
CustomIconButton(
  icon: Icons.edit,
  onPressed: () => _editItem(),
)

// Circular button
CustomIconButton(
  icon: Icons.add,
  onPressed: () => _addNew(),
  isCircular: true,
)

// Custom styled button
CustomIconButton(
  icon: Icons.delete,
  onPressed: () => _deleteItem(),
  backgroundColor: Colors.red.withAlpha(0.1),
  iconColor: Colors.red,
  size: 40,
)

// Button with margin
CustomIconButton(
  icon: Icons.history,
  onPressed: () => _openHistory(),
  margin: EdgeInsets.only(right: 8),
)
```

### Design Specifications
- Default size: 44x44px (optimal touch target)
- Border radius: 12px (or circular)
- Padding: 8px
- Default background: primaryBlue with 10% opacity

---

## 5. 🔍 CustomSearchBar

**File:** `custom_search_bar.dart`

Search input component with consistent styling across history pages.

### Properties
| Property | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `hintText` | `String` | ✅ Yes | - | Placeholder text |
| `onChanged` | `Function(String)` | ✅ Yes | - | Search text change callback |
| `controller` | `TextEditingController?` | ❌ No | `null` | Text controller |
| `margin` | `EdgeInsets` | ❌ No | `EdgeInsets.fromLTRB(24, 0, 24, 16)` | External margin |

### Usage Examples
```dart
// Basic search bar
CustomSearchBar(
  hintText: 'Search triggers...',
  onChanged: (query) => setState(() => searchQuery = query),
)

// Search with controller
CustomSearchBar(
  hintText: 'Search routines...',
  controller: searchController,
  onChanged: _performSearch,
)

// Custom margin
CustomSearchBar(
  hintText: 'Search...',
  onChanged: _handleSearch,
  margin: EdgeInsets.all(16),
)
```

### Design Specifications
- Background: white with shadow
- Border radius: 12px
- Shadow: black with 5% opacity, 8px blur, (0,2) offset
- Search icon: greyText color
- Padding: 16px all sides

---

## 6. 📊 CustomStatCard

**File:** `custom_stat_card.dart`

Statistics display card for showing key metrics in history pages.

### Properties
| Property | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `title` | `String` | ✅ Yes | - | Card title/label |
| `value` | `String` | ✅ Yes | - | Main value to display |
| `icon` | `IconData` | ✅ Yes | - | Icon representing the metric |
| `iconColor` | `Color` | ✅ Yes | - | Icon color |
| `onTap` | `VoidCallback?` | ❌ No | `null` | Optional tap callback |

### Usage Examples
```dart
// Basic stat card
CustomStatCard(
  title: 'Total Triggers',
  value: '25',
  icon: Icons.warning_amber_rounded,
  iconColor: AppColors.primaryBlue,
)

// Clickable stat card
CustomStatCard(
  title: 'This Month',
  value: '8',
  icon: Icons.calendar_today,
  iconColor: Colors.orange,
  onTap: () => _showMonthlyDetails(),
)

// In a row layout
Row(
  children: [
    Expanded(
      child: CustomStatCard(
        title: 'Categories',
        value: categories.length.toString(),
        icon: Icons.category,
        iconColor: Colors.green,
      ),
    ),
    SizedBox(width: 12),
    Expanded(child: /* another card */),
  ],
)
```

### Design Specifications
- Background: white with shadow
- Border radius: 12px
- Padding: 16px
- Icon size: 24px
- Value font: Quicksand, 20px, bold, darkBlue
- Title font: OpenSans, 12px, greyText

---

## 7. 📭 CustomEmptyState

**File:** `custom_empty_state.dart`

Empty state component for when there's no data to display.

### Properties
| Property | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `icon` | `IconData` | ✅ Yes | - | Large icon to display |
| `title` | `String` | ✅ Yes | - | Main title text |
| `message` | `String` | ✅ Yes | - | Descriptive message |
| `actionText` | `String?` | ❌ No | `null` | Button text |
| `onActionPressed` | `VoidCallback?` | ❌ No | `null` | Button callback |
| `customAction` | `Widget?` | ❌ No | `null` | Custom action widget |

### Usage Examples
```dart
// Basic empty state with action
CustomEmptyState(
  icon: Icons.warning_amber_rounded,
  title: 'No Triggers Added',
  message: 'Start tracking your eczema triggers to identify patterns.',
  actionText: 'Add Your First Trigger',
  onActionPressed: () => _addTrigger(),
)

// Empty state without action
CustomEmptyState(
  icon: Icons.search_off,
  title: 'No Results Found',
  message: 'Try adjusting your search terms.',
)

// Empty state with custom action
CustomEmptyState(
  icon: Icons.error_outline,
  title: 'Connection Error',
  message: 'Please check your internet connection.',
  customAction: Row(
    children: [
      Expanded(child: ElevatedButton(/*retry*/)),
      SizedBox(width: 8),
      Expanded(child: OutlinedButton(/*cancel*/)),
    ],
  ),
)
```

### Design Specifications
- Centered layout with padding: 24px
- Icon size: 80px, greyText with 50% opacity
- Title: Quicksand, 24px, bold, darkBlue
- Message: OpenSans, 16px, greyText, center aligned
- Button: Full width, 52px height, 26px border radius

---

## 8. 🏷️ CustomChip

**File:** `custom_chip.dart`

Selectable chip component for tags, categories, and multi-select options.

### Properties
| Property | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `label` | `String` | ✅ Yes | - | Chip text |
| `isSelected` | `bool` | ✅ Yes | - | Selection state |
| `onTap` | `VoidCallback` | ✅ Yes | - | Tap callback |
| `selectedColor` | `Color?` | ❌ No | `primaryBlue` | Selected background color |
| `unselectedColor` | `Color?` | ❌ No | `white` | Unselected background color |
| `selectedTextColor` | `Color?` | ❌ No | `white` | Selected text color |
| `unselectedTextColor` | `Color?` | ❌ No | `primaryBlue` | Unselected text color |
| `showDeleteIcon` | `bool` | ❌ No | `false` | Show delete/close icon |
| `onDelete` | `VoidCallback?` | ❌ No | `null` | Delete callback |

### Usage Examples
```dart
// Basic selectable chip
CustomChip(
  label: 'Itching',
  isSelected: selectedSymptoms.contains('Itching'),
  onTap: () => _toggleSymptom('Itching'),
)

// Chip with delete option
CustomChip(
  label: 'Left Arm',
  isSelected: true,
  onTap: () {},
  showDeleteIcon: true,
  onDelete: () => _removeArea('Left Arm'),
)

// Custom colored chip
CustomChip(
  label: 'Severe',
  isSelected: severity == 'Severe',
  onTap: () => _setSeverity('Severe'),
  selectedColor: Colors.red,
  selectedTextColor: Colors.white,
)

// In a wrap layout
Wrap(
  spacing: 8,
  runSpacing: 8,
  children: symptoms.map((symptom) => CustomChip(
    label: symptom,
    isSelected: selectedSymptoms.contains(symptom),
    onTap: () => _toggleSymptom(symptom),
  )).toList(),
)
```

### Design Specifications
- Border radius: 16px
- Padding: 12px horizontal, 8px vertical
- Border: 1.5px solid
- Font: OpenSans, 13px, bold
- Delete icon size: 16px

---

## 9. 🎚️ CustomSlider

**File:** `custom_slider.dart`

Advanced slider component with multiple types and visual feedback.

### Properties
| Property | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `value` | `double` | ✅ Yes | - | Current slider value |
| `min` | `double` | ✅ Yes | - | Minimum value |
| `max` | `double` | ✅ Yes | - | Maximum value |
| `onChanged` | `ValueChanged<double>` | ✅ Yes | - | Value change callback |
| `divisions` | `int?` | ❌ No | `null` | Number of discrete divisions |
| `title` | `String?` | ❌ No | `null` | Slider title |
| `leftLabel` | `String?` | ❌ No | `null` | Left side label |
| `rightLabel` | `String?` | ❌ No | `null` | Right side label |
| `showValueDisplay` | `bool` | ❌ No | `true` | Show large value display |
| `valueDisplaySuffix` | `String?` | ❌ No | `null` | Suffix for value (%, etc.) |
| `sliderType` | `CustomSliderType` | ❌ No | `CustomSliderType.severity` | Slider type for coloring |
| `isOptional` | `bool` | ❌ No | `false` | Show clear button |
| `onClear` | `VoidCallback?` | ❌ No | `null` | Clear button callback |

### Slider Types
```dart
enum CustomSliderType {
  severity,    // Green → Blue → Red
  confidence,  // Red → Blue → Green
  generic,     // Always primaryBlue
}
```

### Usage Examples
```dart
// Severity slider
CustomSlider(
  title: 'Severity Impact',
  value: severityImpact,
  min: 1,
  max: 10,
  divisions: 9,
  leftLabel: 'Mild',
  rightLabel: 'Severe',
  sliderType: CustomSliderType.severity,
  onChanged: (value) => setState(() => severityImpact = value),
)

// Confidence slider with clear option
CustomSlider(
  title: 'Confidence Level (Optional)',
  value: confidenceLevel ?? 0,
  min: 0,
  max: 100,
  divisions: 20,
  leftLabel: 'Not Sure',
  rightLabel: 'Very Confident',
  sliderType: CustomSliderType.confidence,
  isOptional: true,
  onChanged: (value) => setState(() => confidenceLevel = value),
  onClear: () => setState(() => confidenceLevel = null),
)

// Generic slider
CustomSlider(
  title: 'Amount',
  value: amount,
  min: 0,
  max: 100,
  sliderType: CustomSliderType.generic,
  showValueDisplay: false,
  onChanged: (value) => setState(() => amount = value),
)
```

### Design Specifications
- Container: lightGrey background, 24px padding, 16px border radius
- Large value display: Quicksand, 48px, bold
- Label text: OpenSans, 18px, medium
- Track height: 6px
- Thumb radius: 12px
- Colors change based on slider type and value

---

## 📦 Index File

**File:** `index.dart`

Convenient single import for all custom widgets.

```dart
// Import all widgets at once
import '../../core/widgets/index.dart';

// Now you can use any widget:
CustomHeader(title: 'My Page')
CustomInputField(label: 'Name')
CustomStatCard(title: 'Count', value: '5', icon: Icons.star, iconColor: Colors.blue)
```

---

## 🎨 Design System

### Colors Used
- `AppColors.primaryBlue` - Main brand color
- `AppColors.darkBlue` - Text headings
- `AppColors.greyText` - Secondary text
- `AppColors.lightGrey` - Input backgrounds
- `AppColors.white` - Card backgrounds

### Typography
- **Quicksand**: Headings, titles, large values
- **OpenSans**: Body text, labels, buttons

### Spacing
- **8px**: Small gaps
- **12px**: Medium gaps, border radius
- **16px**: Large gaps, padding
- **24px**: Section spacing

### Touch Targets
- **44x44px**: Minimum touch target size (buttons)
- **52px**: Button height
- **16px**: Text field padding

This design system ensures consistency across all components and screens.