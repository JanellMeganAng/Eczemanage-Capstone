package com.cap2439is.eczema.cap2439is_eczema;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
