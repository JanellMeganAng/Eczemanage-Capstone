/**
 * Weekly log model for tracking weekly eczema assessments.
 *
 * Records PO-SCORAD scores and notes for weekly evaluations
 * to monitor long-term trends in eczema management.
 */
class WeeklyLog {
  /// Unique identifier for the weekly log entry
  final String id;

  /// ID of the user this weekly log belongs to
  final String userId;

  /// Date for this weekly assessment
  final DateTime? date;

  /// Patient-Oriented SCORAD (PO-SCORAD) score for the week
  final int poScoradScore;

  /// Additional notes for the weekly assessment
  final String notes;

  WeeklyLog({
    required this.id,
    required this.userId,
    this.date,
    required this.poScoradScore,
    required this.notes,
  });

  /// Converts the WeeklyLog to a Map for database storage
  Map<String, dynamic> toMap() => {
    'userId': userId,
    'date': date?.toIso8601String(),
    'poScoradScore': poScoradScore,
    'notes': notes,
  };

  /// Creates a WeeklyLog from a Map retrieved from database
  ///
  /// [id] The document ID from the database
  /// [data] The map containing weekly log data
  factory WeeklyLog.fromMap(String id, Map<String, dynamic> data) => WeeklyLog(
    id: id,
    userId: data['userId'] ?? '',
    date: data['date'] != null ? DateTime.tryParse(data['date']) : null,
    poScoradScore: data['poScoradScore'] ?? 0,
    notes: data['notes'] ?? '',
  );
}
