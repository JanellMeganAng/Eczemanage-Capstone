/**
 * Environment log model for tracking environmental conditions.
 *
 * Records weather and environmental data that may correlate with
 * eczema symptoms, including temperature, humidity, air quality, and pollen levels.
 */
class EnvironmentLog {
  /// Unique identifier for the environment log entry
  final String id;

  /// ID of the user this environment log belongs to
  final String userId;

  /// Date for this environmental data reading
  final DateTime? date;

  /// Temperature in degrees (Celsius or Fahrenheit)
  final double? temperature;

  /// Humidity level as a percentage
  final double? humidityPercent;

  /// UV index measurement
  final double? uvIndex;

  /// Air quality index value
  final int? airQualityIndex;

  /// Pollen level measurement
  final int? pollenLevel;

  /// Whether the user was primarily indoors
  final bool? indoors;

  /// Timestamp when this log entry was created
  final DateTime? createdAt;

  EnvironmentLog({
    required this.id,
    required this.userId,
    this.date,
    this.temperature,
    this.humidityPercent,
    this.uvIndex,
    this.airQualityIndex,
    this.pollenLevel,
    this.indoors,
    this.createdAt,
  });

  /// Converts the EnvironmentLog to a Map for database storage
  Map<String, dynamic> toMap() => {
    'userId': userId,
    'date': date?.toIso8601String(),
    'temperature': temperature,
    'humidityPercent': humidityPercent,
    'uvIndex': uvIndex,
    'airQualityIndex': airQualityIndex,
    'pollenLevel': pollenLevel,
    'indoors': indoors,
    'createdAt': createdAt?.toIso8601String(),
  };

  /// Creates an EnvironmentLog from a Map retrieved from database
  ///
  /// [id] The document ID from the database
  /// [data] The map containing environment log data
  factory EnvironmentLog.fromMap(String id, Map<String, dynamic> data) =>
      EnvironmentLog(
        id: id,
        userId: data['userId'] ?? '',
        date: data['date'] != null ? DateTime.tryParse(data['date']) : null,
        temperature: (data['temperature'] as num?)?.toDouble(),
        humidityPercent: (data['humidityPercent'] as num?)?.toDouble(),
        uvIndex: (data['uvIndex'] as num?)?.toDouble(),
        airQualityIndex: data['airQualityIndex'],
        pollenLevel: data['pollenLevel'],
        indoors: data['indoors'],
        createdAt: data['createdAt'] != null
            ? DateTime.tryParse(data['createdAt'])
            : null,
      );
}
