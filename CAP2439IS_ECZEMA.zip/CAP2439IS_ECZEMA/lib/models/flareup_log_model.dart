/**
 * Flare-up log model for tracking eczema flare-up episodes.
 *
 * Records symptoms and severity scores for specific flare-up events
 * to help users monitor their condition over time.
 */
class FlareupLog {
  /// Unique identifier for the flare-up log entry
  final String id;

  /// ID of the user this flare-up log belongs to
  final String userId;

  /// Date when the flare-up occurred
  final DateTime? date;

  /// List of symptoms and their severity scores
  final List<String> symptomsAndScores;

  FlareupLog({
    required this.id,
    required this.userId,
    this.date,
    this.symptomsAndScores = const [],
  });

  /// Converts the FlareupLog to a Map for database storage
  Map<String, dynamic> toMap() => {
    'userId': userId,
    'date': date?.toIso8601String(),
    'symptomsAndScores': symptomsAndScores,
  };

  /// Creates a FlareupLog from a Map retrieved from database
  ///
  /// [id] The document ID from the database
  /// [data] The map containing flare-up log data
  factory FlareupLog.fromMap(String id, Map<String, dynamic> data) =>
      FlareupLog(
        id: id,
        userId: data['userId'] ?? '',
        date: data['date'] != null ? DateTime.tryParse(data['date']) : null,
        symptomsAndScores: List<String>.from(data['symptomsAndScores'] ?? []),
      );
}
