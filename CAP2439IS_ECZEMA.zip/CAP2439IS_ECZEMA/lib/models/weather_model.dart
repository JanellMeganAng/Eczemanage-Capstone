class WeatherData {
  final int temperature;
  final String condition;
  final int humidity;
  final int uvIndex;
  final int windSpeed;
  final String eczemaRisk;
  final String riskMessage;

  WeatherData({
    required this.temperature,
    required this.condition,
    required this.humidity,
    required this.uvIndex,
    required this.windSpeed,
    required this.eczemaRisk,
    required this.riskMessage,
  });
}
