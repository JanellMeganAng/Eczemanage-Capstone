/**
 * Daily log model for tracking daily eczema-related data.
 *
 * Records information about triggers, care routines, and weather data
 * for a specific date to help users track patterns.
 */
class DailyLog {
  /// Unique identifier for the daily log entry
  final String id;

  /// ID of the user this log entry belongs to
  final String userId;

  /// Date for this log entry
  final DateTime? date;

  /// List of triggers experienced on this date
  final List<String> triggers;

  /// List of care routine items used on this date
  final List<String> careRoutine;

  /// Weather conditions recorded for this date
  final List<String> weatherData;

  DailyLog({
    required this.id,
    required this.userId,
    this.date,
    this.triggers = const [],
    this.careRoutine = const [],
    this.weatherData = const [],
  });

  /// Converts the DailyLog to a Map for database storage
  Map<String, dynamic> toMap() => {
    'userId': userId,
    'date': date?.toIso8601String(),
    'triggers': triggers,
    'careRoutine': careRoutine,
    'weatherData': weatherData,
  };

  /// Creates a DailyLog from a Map retrieved from database
  ///
  /// [id] The document ID from the database
  /// [data] The map containing daily log data
  factory DailyLog.fromMap(String id, Map<String, dynamic> data) => DailyLog(
    id: id,
    userId: data['userId'] ?? '',
    date: data['date'] != null ? DateTime.tryParse(data['date']) : null,
    triggers: List<String>.from(data['triggers'] ?? []),
    careRoutine: List<String>.from(data['careRoutine'] ?? []),
    weatherData: List<String>.from(data['weatherData'] ?? []),
  );
}
