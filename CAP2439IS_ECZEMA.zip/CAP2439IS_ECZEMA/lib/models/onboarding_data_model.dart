/// Onboarding data model storing user responses from the setup process.
///
/// Contains information about eczema severity, affected areas, goals,
/// and preferred triggers collected during the onboarding flow.
class OnboardingData {
  /// Unique identifier for the onboarding data
  final String id;

  /// ID of the user this onboarding data belongs to
  final String userId;

  /// User-reported severity level of their eczema
  final String eczemaSeverity;

  /// List of body areas affected by eczema
  final List<String> affectedAreas;

  /// List of user's goals for managing their eczema
  final List<String> goals;

  /// List of triggers the user wants to track
  final List<String> preferredTriggers;

  /// Timestamp when the onboarding was completed
  final DateTime? answeredAt;

  final String diagnosedAt; // 👈 new field

  OnboardingData({
    required this.id,
    required this.userId,
    required this.eczemaSeverity,
    this.affectedAreas = const [],
    this.goals = const [],
    this.preferredTriggers = const [],
    this.answeredAt,
    required this.diagnosedAt,
  });

  /// Converts the OnboardingData to a Map for database storage
  Map<String, dynamic> toMap() => {
    'userId': userId,
    'eczemaSeverity': eczemaSeverity,
    'affectedAreas': affectedAreas,
    'goals': goals,
    'preferredTriggers': preferredTriggers,
    'answeredAt': answeredAt?.toIso8601String(),
    'diagnosedAt': diagnosedAt,
  };

  /// Creates OnboardingData from a Map retrieved from database
  ///
  /// [id] The document ID from the database
  /// [data] The map containing onboarding data
  factory OnboardingData.fromMap(String id, Map<String, dynamic> data) =>
      OnboardingData(
        id: id,
        userId: data['userId'] ?? '',
        eczemaSeverity: data['eczemaSeverity'] ?? '',
        affectedAreas: List<String>.from(data['affectedAreas'] ?? []),
        goals: List<String>.from(data['goals'] ?? []),
        preferredTriggers: List<String>.from(data['preferredTriggers'] ?? []),
        answeredAt: data['answeredAt'] != null
            ? DateTime.tryParse(data['answeredAt'])
            : null,
        diagnosedAt: data['diagnosedAt'] ?? '',
      );
}
