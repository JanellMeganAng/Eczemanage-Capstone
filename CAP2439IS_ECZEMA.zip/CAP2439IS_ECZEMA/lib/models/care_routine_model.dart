class CareRoutineModel {
  final String id;
  final String routineName;
  final String routineType;
  final String productName;
  final Set<String> applicationAreas;
  final String frequency;
  final Set<String> timeOfDay;
  final bool reminderEnabled;
  final String notes;
  final DateTime createdAt;
  final DateTime updatedAt;

  CareRoutineModel({
    required this.id,
    required this.routineName,
    required this.routineType,
    required this.productName,
    required this.applicationAreas,
    required this.frequency,
    required this.timeOfDay,
    required this.reminderEnabled,
    required this.notes,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'routineName': routineName,
      'routineType': routineType,
      'productName': productName,
      'applicationAreas': applicationAreas.toList(),
      'frequency': frequency,
      'timeOfDay': timeOfDay.toList(),
      'reminderEnabled': reminderEnabled,
      'notes': notes,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory CareRoutineModel.fromMap(Map<String, dynamic> map) {
    return CareRoutineModel(
      id: map['id'] ?? '',
      routineName: map['routineName'] ?? '',
      routineType: map['routineType'] ?? '',
      productName: map['productName'] ?? '',
      applicationAreas: Set<String>.from(map['applicationAreas'] ?? []),
      frequency: map['frequency'] ?? '',
      timeOfDay: Set<String>.from(map['timeOfDay'] ?? []),
      reminderEnabled: map['reminderEnabled'] ?? false,
      notes: map['notes'] ?? '',
      createdAt: DateTime.parse(map['createdAt']),
      updatedAt: DateTime.parse(map['updatedAt']),
    );
  }

  CareRoutineModel copyWith({
    String? id,
    String? routineName,
    String? routineType,
    String? productName,
    Set<String>? applicationAreas,
    String? frequency,
    Set<String>? timeOfDay,
    bool? reminderEnabled,
    String? notes,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return CareRoutineModel(
      id: id ?? this.id,
      routineName: routineName ?? this.routineName,
      routineType: routineType ?? this.routineType,
      productName: productName ?? this.productName,
      applicationAreas: applicationAreas ?? this.applicationAreas,
      frequency: frequency ?? this.frequency,
      timeOfDay: timeOfDay ?? this.timeOfDay,
      reminderEnabled: reminderEnabled ?? this.reminderEnabled,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() {
    return 'CareRoutineModel(id: $id, routineName: $routineName, routineType: $routineType, productName: $productName, applicationAreas: $applicationAreas, frequency: $frequency, timeOfDay: $timeOfDay, reminderEnabled: $reminderEnabled, notes: $notes, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is CareRoutineModel &&
        other.id == id &&
        other.routineName == routineName &&
        other.routineType == routineType &&
        other.productName == productName &&
        other.applicationAreas == applicationAreas &&
        other.frequency == frequency &&
        other.timeOfDay == timeOfDay &&
        other.reminderEnabled == reminderEnabled &&
        other.notes == notes &&
        other.createdAt == createdAt &&
        other.updatedAt == updatedAt;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        routineName.hashCode ^
        routineType.hashCode ^
        productName.hashCode ^
        applicationAreas.hashCode ^
        frequency.hashCode ^
        timeOfDay.hashCode ^
        reminderEnabled.hashCode ^
        notes.hashCode ^
        createdAt.hashCode ^
        updatedAt.hashCode;
  }
}