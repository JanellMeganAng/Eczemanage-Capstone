/// User model representing a user in the EczeManage app.
///
/// Contains user authentication data and profile information including
/// personal details like name, email, and birthdate.
class UserModel {
  /// Unique identifier for the user
  final String id;

  /// User's email address for authentication
  final String email;

  /// Hashed password for secure authentication
  final String passwordHash;

  /// User's first name
  final String firstName;

  /// User's last name
  final String lastName;

  /// User's date of birth (optional)
  final DateTime? birthdate;

  /// User's gender
  final String gender;

  /// Timestamp when the user account was created
  final DateTime? createdAt;

  /// Timestamp when the user account was last updated
  final DateTime? updatedAt;

  UserModel({
    required this.id,
    required this.email,
    required this.passwordHash,
    required this.firstName,
    required this.lastName,
    this.birthdate,
    required this.gender,
    this.createdAt,
    this.updatedAt,
  });

  /// Converts the UserModel to a Map for database storage
  Map<String, dynamic> toMap() => {
    'email': email,
    'passwordHash': passwordHash,
    'firstName': firstName,
    'lastName': lastName,
    'birthdate': birthdate?.toIso8601String(),
    'gender': gender,
    'createdAt': createdAt?.toIso8601String(),
    'updatedAt': updatedAt?.toIso8601String(),
  };

  /// Creates a UserModel from a Map retrieved from database
  ///
  /// [id] The document ID from the database
  /// [data] The map containing user data
  factory UserModel.fromMap(String id, Map<String, dynamic> data) => UserModel(
    id: id,
    email: data['email'] ?? '',
    passwordHash: data['passwordHash'] ?? '',
    firstName: data['firstName'] ?? '',
    lastName: data['lastName'] ?? '',
    birthdate: data['birthdate'] != null
        ? DateTime.tryParse(data['birthdate'])
        : null,
    gender: data['gender'] ?? '',
    createdAt: data['createdAt'] != null
        ? DateTime.tryParse(data['createdAt'])
        : null,
    updatedAt: data['updatedAt'] != null
        ? DateTime.tryParse(data['updatedAt'])
        : null,
  );
}
