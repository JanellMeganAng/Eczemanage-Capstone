class TriggerModel {
  final String? id;
  final String triggerCategory;
  final String specificTrigger;
  final double severityImpact;
  final String reactionTime;
  final List<String> affectedAreas;
  final List<String> symptomsTriggered;
  final DateTime dateIdentified;
  final double? confidenceLevel;
  final String notes;
  final DateTime createdAt;

  const TriggerModel({
    this.id,
    required this.triggerCategory,
    required this.specificTrigger,
    required this.severityImpact,
    required this.reactionTime,
    required this.affectedAreas,
    required this.symptomsTriggered,
    required this.dateIdentified,
    this.confidenceLevel,
    required this.notes,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'triggerCategory': triggerCategory,
      'specificTrigger': specificTrigger,
      'severityImpact': severityImpact,
      'reactionTime': reactionTime,
      'affectedAreas': affectedAreas,
      'symptomsTriggered': symptomsTriggered,
      'dateIdentified': dateIdentified.toIso8601String(),
      'confidenceLevel': confidenceLevel,
      'notes': notes,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory TriggerModel.fromMap(Map<String, dynamic> map) {
    return TriggerModel(
      id: map['id'],
      triggerCategory: map['triggerCategory'] ?? '',
      specificTrigger: map['specificTrigger'] ?? '',
      severityImpact: (map['severityImpact'] ?? 0.0).toDouble(),
      reactionTime: map['reactionTime'] ?? '',
      affectedAreas: List<String>.from(map['affectedAreas'] ?? []),
      symptomsTriggered: List<String>.from(map['symptomsTriggered'] ?? []),
      dateIdentified: DateTime.parse(map['dateIdentified']),
      confidenceLevel: map['confidenceLevel']?.toDouble(),
      notes: map['notes'] ?? '',
      createdAt: DateTime.parse(map['createdAt']),
    );
  }

  TriggerModel copyWith({
    String? id,
    String? triggerCategory,
    String? specificTrigger,
    double? severityImpact,
    String? reactionTime,
    List<String>? affectedAreas,
    List<String>? symptomsTriggered,
    DateTime? dateIdentified,
    double? confidenceLevel,
    String? notes,
    DateTime? createdAt,
  }) {
    return TriggerModel(
      id: id ?? this.id,
      triggerCategory: triggerCategory ?? this.triggerCategory,
      specificTrigger: specificTrigger ?? this.specificTrigger,
      severityImpact: severityImpact ?? this.severityImpact,
      reactionTime: reactionTime ?? this.reactionTime,
      affectedAreas: affectedAreas ?? this.affectedAreas,
      symptomsTriggered: symptomsTriggered ?? this.symptomsTriggered,
      dateIdentified: dateIdentified ?? this.dateIdentified,
      confidenceLevel: confidenceLevel ?? this.confidenceLevel,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  String toString() {
    return 'TriggerModel(id: $id, triggerCategory: $triggerCategory, specificTrigger: $specificTrigger, severityImpact: $severityImpact, reactionTime: $reactionTime, affectedAreas: $affectedAreas, symptomsTriggered: $symptomsTriggered, dateIdentified: $dateIdentified, confidenceLevel: $confidenceLevel, notes: $notes, createdAt: $createdAt)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is TriggerModel &&
        other.id == id &&
        other.triggerCategory == triggerCategory &&
        other.specificTrigger == specificTrigger &&
        other.severityImpact == severityImpact &&
        other.reactionTime == reactionTime &&
        other.affectedAreas.toString() == affectedAreas.toString() &&
        other.symptomsTriggered.toString() == symptomsTriggered.toString() &&
        other.dateIdentified == dateIdentified &&
        other.confidenceLevel == confidenceLevel &&
        other.notes == notes &&
        other.createdAt == createdAt;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        triggerCategory.hashCode ^
        specificTrigger.hashCode ^
        severityImpact.hashCode ^
        reactionTime.hashCode ^
        affectedAreas.hashCode ^
        symptomsTriggered.hashCode ^
        dateIdentified.hashCode ^
        confidenceLevel.hashCode ^
        notes.hashCode ^
        createdAt.hashCode;
  }
}