import '../models/user_model.dart';
import '../models/daily_log_model.dart';
import '../models/onboarding_data_model.dart';
import '../models/flareup_log_model.dart';
import '../models/weekly_log_model.dart';
import '../models/environment_log_model.dart';
import '../services/firestore_services.dart';
import '../services/auth_service.dart';

Future<void> seedDatabase() async {
  final firestoreService = FirestoreService();
  final authService = AuthService();

  // Create a test user with Firebase Auth if it doesn't exist
  try {
    final userExists = await authService.isEmailRegistered(
      "jose_dela_cruz@test.com",
    );

    if (!userExists) {
      final testUser = UserModel(
        id: "", // Will be set by Firebase Auth
        email: "jose_dela_cruz@test.com",
        passwordHash: "password123", // Plain password for registration
        firstName: "Jose",
        lastName: "Dela Cruz",
        birthdate: DateTime(2000, 1, 1),
        gender: "Male",
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      // Register the test user
      final user = await authService.registerWithEmailAndPassword(testUser);

      if (user != null) {
        // Create onboarding data for test user
        await firestoreService.setOnboardingData(
          OnboardingData(
            id: "${user.uid}_onboarding",
            userId: user.uid,
            eczemaSeverity: "Moderate",
            affectedAreas: ["Arms", "Neck"],
            goals: ["Reduce itching", "Improve sleep"],
            preferredTriggers: ["Pollen"],
            answeredAt: DateTime.now(),
            diagnosedAt: "Since childhood",
          ),
        );

        // Use the Firebase Auth UID for all other data
        final userId = user.uid;

        await firestoreService.setDailyLog(
          DailyLog(
            id: "daily1",
            userId: userId,
            date: DateTime.now(),
            triggers: ["Dust", "Sweat"],
            careRoutine: ["Moisturizer", "Cool shower"],
            weatherData: ["Humid", "Hot"],
          ),
        );

        await firestoreService.setFlareupLog(
          FlareupLog(
            id: "flare1",
            userId: userId,
            date: DateTime.now(),
            symptomsAndScores: ["Itching:3", "Redness:2"],
          ),
        );

        await firestoreService.setWeeklyLog(
          WeeklyLog(
            id: "week1",
            userId: userId,
            date: DateTime.now(),
            poScoradScore: 15,
            notes: "Mild improvement compared to last week.",
          ),
        );

        await firestoreService.setEnvironmentLog(
          EnvironmentLog(
            id: "env1",
            userId: userId,
            date: DateTime.now(),
            temperature: 30.5,
            humidityPercent: 70.0,
            uvIndex: 5.2,
            airQualityIndex: 60,
            pollenLevel: 3,
            indoors: false,
            createdAt: DateTime.now(),
          ),
        );

        // Sign out after seeding
        await authService.signOut();
      }
    }
  } catch (e) {
    print("Note: Test user might already exist or there was an error: $e");

    // Continue with fallback seeding using hardcoded IDs
    await firestoreService.setUser(
      UserModel(
        id: "user1",
        email: "jose_dela_cruz@test.com",
        passwordHash: "",
        firstName: "Jose",
        lastName: "Dela Cruz",
        birthdate: DateTime(2000, 1, 1),
        gender: "Male",
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ),
    );

    await firestoreService.setDailyLog(
      DailyLog(
        id: "daily1",
        userId: "user1",
        date: DateTime.now(),
        triggers: ["Dust", "Sweat"],
        careRoutine: ["Moisturizer", "Cool shower"],
        weatherData: ["Humid", "Hot"],
      ),
    );

    await firestoreService.setOnboardingData(
      OnboardingData(
        id: "onboard1",
        userId: "user1",
        eczemaSeverity: "Moderate",
        affectedAreas: ["Arms", "Neck"],
        goals: ["Reduce itching", "Improve sleep"],
        preferredTriggers: ["Pollen"],
        answeredAt: DateTime.now(),
        diagnosedAt: "Since childhood",
      ),
    );

    await firestoreService.setFlareupLog(
      FlareupLog(
        id: "flare1",
        userId: "user1",
        date: DateTime.now(),
        symptomsAndScores: ["Itching:3", "Redness:2"],
      ),
    );

    await firestoreService.setWeeklyLog(
      WeeklyLog(
        id: "week1",
        userId: "user1",
        date: DateTime.now(),
        poScoradScore: 15,
        notes: "Mild improvement compared to last week.",
      ),
    );

    await firestoreService.setEnvironmentLog(
      EnvironmentLog(
        id: "env1",
        userId: "user1",
        date: DateTime.now(),
        temperature: 30.5,
        humidityPercent: 70.0,
        uvIndex: 5.2,
        airQualityIndex: 60,
        pollenLevel: 3,
        indoors: false,
        createdAt: DateTime.now(),
      ),
    );
  }
}
