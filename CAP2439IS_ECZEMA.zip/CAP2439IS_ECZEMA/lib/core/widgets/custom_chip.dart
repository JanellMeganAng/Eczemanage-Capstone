import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../constants/app_colors.dart';

/// CustomChip - Reusable Selectable Chip Widget
///
/// A pill-shaped button component for multi-select interfaces.
/// Provides visual feedback for selected/unselected states.
///
/// Features:
/// - Toggle selection state with tap
/// - Customizable colors for selected/unselected states
/// - Optional delete icon for removable items
/// - Consistent rounded styling
/// - Bordered design matching app theme
///
/// Use Cases:
/// - Category selection (triggers, symptoms, body areas)
/// - Tag-based filtering
/// - Multi-option forms
///
/// Usage Example:
/// ```dart
/// CustomChip(
///   label: "Food",
///   isSelected: selectedCategories.contains('Food'),
///   onTap: () => toggleCategory('Food'),
///   showDeleteIcon: true,
///   onDelete: () => removeCategory('Food'),
/// )
/// ```
class CustomChip extends StatelessWidget {
  final String label;  // Text displayed on chip
  final bool isSelected;  // Whether chip is currently selected
  final VoidCallback onTap;  // Callback when chip is tapped
  final Color? selectedColor;  // Background color when selected (defaults to primary blue)
  final Color? unselectedColor;  // Background color when unselected (defaults to white)
  final Color? selectedTextColor;  // Text color when selected (defaults to white)
  final Color? unselectedTextColor;  // Text color when unselected (defaults to primary blue)
  final bool showDeleteIcon;  // Whether to show delete/close icon
  final VoidCallback? onDelete;  // Callback when delete icon tapped

  const CustomChip({
    super.key,
    required this.label,
    required this.isSelected,
    required this.onTap,
    this.selectedColor,
    this.unselectedColor,
    this.selectedTextColor,
    this.unselectedTextColor,
    this.showDeleteIcon = false,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? (selectedColor ?? AppColors.primaryBlue)
              : (unselectedColor ?? AppColors.white),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selectedColor ?? AppColors.primaryBlue,
            width: 1.5,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              style: GoogleFonts.openSans(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: isSelected
                    ? (selectedTextColor ?? AppColors.white)
                    : (unselectedTextColor ?? AppColors.primaryBlue),
              ),
            ),
            if (showDeleteIcon && onDelete != null) ...[
              const SizedBox(width: 4),
              GestureDetector(
                onTap: onDelete,
                child: Icon(
                  Icons.close,
                  size: 16,
                  color: isSelected
                      ? (selectedTextColor ?? AppColors.white)
                      : (unselectedTextColor ?? AppColors.primaryBlue),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}