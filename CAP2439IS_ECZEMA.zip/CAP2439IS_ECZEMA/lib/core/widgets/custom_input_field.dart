import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../constants/app_colors.dart';

/// CustomInputField - Reusable Text Input Widget with Consistent Styling
///
/// A standardized text input component that maintains design consistency
/// across all forms in the application.
///
/// Features:
/// - Optional label above input field
/// - Single-line or multi-line support
/// - Custom keyboard types (text, number, email, etc.)
/// - Form validation support
/// - Suffix icon support (e.g., visibility toggle)
/// - Enable/disable state
/// - Rounded borders with app theme colors
///
/// Use Cases:
/// - Form inputs (login, registration, profile editing)
/// - Notes and descriptions (multi-line)
/// - Search fields
/// - Validated inputs (email, password)
///
/// Usage Example:
/// ```dart
/// CustomInputField(
///   label: "Email",
///   hintText: "Enter your email",
///   controller: emailController,
///   keyboardType: TextInputType.emailAddress,
///   validator: (value) => value?.isEmpty == true ? 'Required' : null,
/// )
/// ```
class CustomInputField extends StatelessWidget {
  final String? label;  // Optional label text above input
  final String? hintText;  // Placeholder text when field is empty
  final TextEditingController? controller;  // Controller for managing input text
  final int maxLines;  // Number of lines (1 for single-line, >1 for multi-line)
  final TextInputType keyboardType;  // Keyboard type (text, number, email, etc.)
  final bool enabled;  // Whether field is editable
  final Widget? suffixIcon;  // Optional icon at end of field (e.g., eye icon for password)
  final Function(String)? onChanged;  // Callback when text changes
  final String? Function(String?)? validator;  // Validation function for forms

  const CustomInputField({
    super.key,
    this.label,
    this.hintText,
    this.controller,
    this.maxLines = 1,
    this.keyboardType = TextInputType.text,
    this.enabled = true,
    this.suffixIcon,
    this.onChanged,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (label != null) ...[
          Text(
            label!,
            style: GoogleFonts.openSans(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: AppColors.darkBlue,
            ),
          ),
          const SizedBox(height: 8),
        ],
        Container(
          decoration: BoxDecoration(
            color: AppColors.lightGrey,
            borderRadius: BorderRadius.circular(12),
          ),
          child: TextFormField(
            controller: controller,
            maxLines: maxLines,
            keyboardType: keyboardType,
            enabled: enabled,
            onChanged: onChanged,
            validator: validator,
            style: GoogleFonts.openSans(
              fontSize: 16,
              color: AppColors.darkBlue,
            ),
            decoration: InputDecoration(
              hintText: hintText,
              hintStyle: GoogleFonts.openSans(
                fontSize: 16,
                color: AppColors.greyText,
              ),
              suffixIcon: suffixIcon,
              border: InputBorder.none,
              contentPadding: EdgeInsets.all(maxLines > 1 ? 16 : 16),
            ),
          ),
        ),
      ],
    );
  }
}