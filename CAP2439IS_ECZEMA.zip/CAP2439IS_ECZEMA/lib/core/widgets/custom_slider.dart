import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../constants/app_colors.dart';

/// A customizable slider widget with dynamic color coding and value display.
///
/// [CustomSlider] provides an enhanced slider experience with three distinct
/// types: severity, confidence, and generic. Each type has unique color schemes
/// and labeling to provide visual feedback based on the slider value.
///
/// Key features:
/// - Dynamic color coding based on slider type and value
/// - Large value display with contextual labels (Mild/Moderate/Severe, Low/Medium/High)
/// - Optional clear button for resetting optional values
/// - Customizable range labels and value suffixes
/// - Three slider types: severity (1-10), confidence (0-100%), and generic
///
/// Use cases:
/// - Symptom severity rating in medical applications
/// - Confidence level input for predictions
/// - General numeric input with visual feedback
/// - Any scenario requiring intuitive range selection
///
/// Example usage:
/// ```dart
/// CustomSlider(
///   value: _severityValue,
///   min: 1,
///   max: 10,
///   divisions: 9,
///   onChanged: (newValue) => setState(() => _severityValue = newValue),
///   title: 'Symptom Severity',
///   leftLabel: 'Mild',
///   rightLabel: 'Severe',
///   sliderType: CustomSliderType.severity,
/// )
/// ```
class CustomSlider extends StatelessWidget {
  /// The current value of the slider
  final double value;

  /// The minimum value the slider can be set to
  final double min;

  /// The maximum value the slider can be set to
  final double max;

  /// The number of discrete divisions for the slider (null for continuous)
  final int? divisions;

  /// Callback function invoked when the slider value changes
  final ValueChanged<double> onChanged;

  /// Optional title displayed above the slider
  final String? title;

  /// Optional label displayed on the left side below the slider
  final String? leftLabel;

  /// Optional label displayed on the right side below the slider
  final String? rightLabel;

  /// Whether to show the numeric value display (default: true)
  final bool showValueDisplay;

  /// Optional suffix appended to the displayed value (e.g., '%', 'cm')
  final String? valueDisplaySuffix;

  /// The type of slider determining color scheme and labels
  final CustomSliderType sliderType;

  /// Whether this slider input is optional and can be cleared
  final bool isOptional;

  /// Callback function invoked when the clear button is pressed
  final VoidCallback? onClear;

  const CustomSlider({
    super.key,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
    this.divisions,
    this.title,
    this.leftLabel,
    this.rightLabel,
    this.showValueDisplay = true,
    this.valueDisplaySuffix,
    this.sliderType = CustomSliderType.severity,
    this.isOptional = false,
    this.onClear,
  });

  Color _getSliderColor() {
    switch (sliderType) {
      case CustomSliderType.severity:
        if (value <= 3) {
          return const Color(0xFF4CAF50); // Green for mild
        } else if (value <= 7) {
          return AppColors.primaryBlue; // Blue for moderate
        } else {
          return const Color(0xFFFF5252); // Red for severe
        }
      case CustomSliderType.confidence:
        if (value <= 25) {
          return const Color(0xFFFF5252); // Red for low confidence
        } else if (value <= 75) {
          return AppColors.primaryBlue; // Blue for medium confidence
        } else {
          return const Color(0xFF4CAF50); // Green for high confidence
        }
      case CustomSliderType.generic:
        return AppColors.primaryBlue;
    }
  }

  String _getSliderLabel() {
    switch (sliderType) {
      case CustomSliderType.severity:
        if (value <= 3) {
          return 'Mild';
        } else if (value <= 7) {
          return 'Moderate';
        } else {
          return 'Severe';
        }
      case CustomSliderType.confidence:
        if (value <= 25) {
          return 'Low';
        } else if (value <= 75) {
          return 'Medium';
        } else {
          return 'High';
        }
      case CustomSliderType.generic:
        return '';
    }
  }

  String _getDisplayValue() {
    if (sliderType == CustomSliderType.severity) {
      return value.round().toString();
    } else if (sliderType == CustomSliderType.confidence) {
      return '${value.round()}${valueDisplaySuffix ?? '%'}';
    } else {
      return '${value.round()}${valueDisplaySuffix ?? ''}';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (title != null) ...[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title!,
                style: GoogleFonts.openSans(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppColors.darkBlue,
                ),
              ),
              if (showValueDisplay)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: _getSliderColor(),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    _getDisplayValue(),
                    style: GoogleFonts.openSans(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: AppColors.white,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
        ],
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: AppColors.lightGrey,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            children: [
              if (showValueDisplay && sliderType != CustomSliderType.generic) ...[
                Text(
                  _getDisplayValue(),
                  style: GoogleFonts.quicksand(
                    fontSize: 48,
                    fontWeight: FontWeight.bold,
                    color: _getSliderColor(),
                  ),
                ),
                const SizedBox(height: 8),
                if (_getSliderLabel().isNotEmpty)
                  Text(
                    _getSliderLabel(),
                    style: GoogleFonts.openSans(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                      color: _getSliderColor(),
                    ),
                  ),
                const SizedBox(height: 24),
              ],
              Row(
                children: [
                  Expanded(
                    child: SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        activeTrackColor: _getSliderColor(),
                        inactiveTrackColor: _getSliderColor().withValues(alpha: 0.3),
                        thumbColor: _getSliderColor(),
                        overlayColor: _getSliderColor().withValues(alpha: 0.2),
                        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 12),
                        trackHeight: 6,
                      ),
                      child: Slider(
                        value: value,
                        min: min,
                        max: max,
                        divisions: divisions,
                        onChanged: onChanged,
                      ),
                    ),
                  ),
                  if (isOptional && onClear != null) ...[
                    const SizedBox(width: 12),
                    GestureDetector(
                      onTap: onClear,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppColors.greyText.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(
                          Icons.clear,
                          size: 16,
                          color: AppColors.greyText,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              if (leftLabel != null || rightLabel != null) ...[
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    if (leftLabel != null)
                      Text(
                        leftLabel!,
                        style: GoogleFonts.openSans(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: AppColors.greyText,
                        ),
                      ),
                    if (rightLabel != null)
                      Text(
                        rightLabel!,
                        style: GoogleFonts.openSans(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: AppColors.greyText,
                        ),
                      ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

enum CustomSliderType {
  severity,
  confidence,
  generic,
}