import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../constants/app_colors.dart';

/// A compact card widget for displaying statistical information.
///
/// [CustomStatCard] presents a single metric or statistic in a clean,
/// card-based layout with an icon, value, and title. It's ideal for
/// dashboard displays and summary screens.
///
/// Key features:
/// - Icon-centric design with customizable color
/// - Prominent value display with large, bold text
/// - Descriptive title label
/// - Optional tap interaction
/// - Elevated card styling with shadow
///
/// Use cases:
/// - Dashboard statistics and metrics
/// - Summary cards (total symptoms, average severity, etc.)
/// - Quick-view analytics
/// - KPI displays in overview screens
/// - Any numeric data requiring visual emphasis
///
/// Example usage:
/// ```dart
/// CustomStatCard(
///   title: 'Total Records',
///   value: '24',
///   icon: Icons.folder,
///   iconColor: AppColors.primaryBlue,
///   onTap: () => _viewAllRecords(),
/// )
/// ```
class CustomStatCard extends StatelessWidget {
  /// The label describing the statistic being displayed
  final String title;

  /// The numeric or text value of the statistic
  final String value;

  /// The icon displayed at the top of the card
  final IconData icon;

  /// The color applied to the icon
  final Color iconColor;

  /// Optional callback invoked when the card is tapped
  final VoidCallback? onTap;

  const CustomStatCard({
    super.key,
    required this.title,
    required this.value,
    required this.icon,
    required this.iconColor,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            Icon(icon, color: iconColor, size: 24),
            const SizedBox(height: 8),
            Text(
              value,
              style: GoogleFonts.quicksand(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppColors.darkBlue,
              ),
            ),
            Text(
              title,
              style: GoogleFonts.openSans(
                fontSize: 12,
                color: AppColors.greyText,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}