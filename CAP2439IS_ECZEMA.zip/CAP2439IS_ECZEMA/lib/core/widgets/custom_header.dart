import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../constants/app_colors.dart';

/// A consistent header widget for app screens with navigation and action buttons.
///
/// [CustomHeader] provides a standardized header layout featuring a centered
/// title, optional back button, and customizable action widgets. It maintains
/// visual consistency across the application with branded styling.
///
/// Key features:
/// - Centered title with branded Quicksand font
/// - Optional back button with automatic navigation
/// - Customizable action widgets (icons, buttons, etc.)
/// - Default user profile icon when no actions specified
/// - Consistent padding and styling
///
/// Use cases:
/// - Screen headers with navigation control
/// - Pages requiring custom action buttons (save, edit, delete)
/// - Detail screens with back navigation
/// - Any screen needing consistent header styling
///
/// Example usage:
/// ```dart
/// CustomHeader(
///   title: 'Symptom Details',
///   showBackButton: true,
///   actions: [
///     IconButton(
///       icon: Icon(Icons.edit),
///       onPressed: () => _editSymptom(),
///     ),
///   ],
/// )
/// ```
class CustomHeader extends StatelessWidget {
  /// The main title text displayed in the header center
  final String title;

  /// Optional callback for custom back button behavior (defaults to Navigator.pop)
  final VoidCallback? onBackPressed;

  /// Optional list of action widgets displayed on the right side
  final List<Widget>? actions;

  /// Whether to show the back button (default: true)
  final bool showBackButton;

  const CustomHeader({
    super.key,
    required this.title,
    this.onBackPressed,
    this.actions,
    this.showBackButton = true,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 20),
      child: Row(
        children: [
          if (showBackButton) ...[
            GestureDetector(
              onTap: onBackPressed ?? () => Navigator.pop(context),
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.primaryBlue.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Padding(
                  padding: EdgeInsets.only(left: 5),
                  child: Icon(
                    Icons.arrow_back_ios,
                    color: AppColors.primaryBlue,
                    size: 20,
                  ),
                ),
              ),
            ),
          ],
          Expanded(
            child: Center(
              child: Text(
                title,
                style: GoogleFonts.quicksand(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: AppColors.primaryBlue,
                ),
              ),
            ),
          ),
          if (actions != null) ...actions!,
          if (actions == null)
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.primaryBlue.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.person,
                color: AppColors.primaryBlue,
                size: 20,
              ),
            ),
        ],
      ),
    );
  }
}