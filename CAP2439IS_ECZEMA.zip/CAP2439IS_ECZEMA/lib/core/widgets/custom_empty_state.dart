import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../constants/app_colors.dart';

/// A user-friendly empty state widget for displaying no-data scenarios.
///
/// [CustomEmptyState] provides a polished UI component for empty states,
/// featuring an icon, title, message, and optional call-to-action button.
/// It helps guide users when lists, searches, or data sets have no content.
///
/// Key features:
/// - Large icon for visual clarity
/// - Title and descriptive message text
/// - Optional action button or custom action widget
/// - Centered, responsive layout
/// - Consistent styling with app theme
///
/// Use cases:
/// - Empty search results
/// - No saved records or items
/// - First-time user experiences
/// - Cleared filters with no matches
/// - Any scenario displaying empty data sets
///
/// Example usage:
/// ```dart
/// CustomEmptyState(
///   icon: Icons.search_off,
///   title: 'No Results Found',
///   message: 'Try adjusting your search terms',
///   actionText: 'Clear Search',
///   onActionPressed: () => _clearSearch(),
/// )
/// ```
class CustomEmptyState extends StatelessWidget {
  /// The icon displayed at the top of the empty state
  final IconData icon;

  /// The main title text explaining the empty state
  final String title;

  /// The descriptive message providing additional context or guidance
  final String message;

  /// Optional text for the action button
  final String? actionText;

  /// Optional callback invoked when the action button is pressed
  final VoidCallback? onActionPressed;

  /// Optional custom widget to replace the default action button
  final Widget? customAction;

  const CustomEmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
    this.actionText,
    this.onActionPressed,
    this.customAction,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 80,
              color: AppColors.greyText.withValues(alpha: 0.5),
            ),
            const SizedBox(height: 24),
            Text(
              title,
              style: GoogleFonts.quicksand(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: AppColors.darkBlue,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              message,
              style: GoogleFonts.openSans(
                fontSize: 16,
                color: AppColors.greyText,
              ),
              textAlign: TextAlign.center,
            ),
            if (customAction != null) ...[
              const SizedBox(height: 32),
              customAction!,
            ] else if (actionText != null && onActionPressed != null) ...[
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: onActionPressed,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryBlue,
                    foregroundColor: AppColors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(26),
                    ),
                  ),
                  child: Text(
                    actionText!,
                    style: GoogleFonts.openSans(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.4,
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}