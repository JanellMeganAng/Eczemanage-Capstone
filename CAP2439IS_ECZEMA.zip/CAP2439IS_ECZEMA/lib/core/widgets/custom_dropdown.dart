import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../constants/app_colors.dart';

/// CustomDropdown - Reusable Dropdown Widget with Consistent Styling
///
/// A generic dropdown component that maintains consistent design across the app.
/// Supports any data type through generics and custom label extraction.
///
/// Features:
/// - Generic type support for flexible data handling
/// - Optional label above dropdown
/// - Custom item label extraction function
/// - Consistent styling with app theme
/// - Rounded borders and custom colors
///
/// Usage Example:
/// ```dart
/// CustomDropdown<String>(
///   label: "Select Category",
///   value: selectedCategory,
///   items: ['Food', 'Weather', 'Stress'],
///   itemLabel: (item) => item,
///   onChanged: (value) => setState(() => selectedCategory = value),
/// )
/// ```
class CustomDropdown<T> extends StatelessWidget {
  final String? label;  // Optional label text displayed above dropdown
  final T? value;  // Currently selected value
  final List<T> items;  // List of items to display in dropdown
  final String Function(T) itemLabel;  // Function to extract display text from item
  final Function(T?) onChanged;  // Callback when selection changes
  final String? hintText;  // Placeholder text when no value selected

  const CustomDropdown({
    super.key,
    this.label,
    required this.value,
    required this.items,
    required this.itemLabel,
    required this.onChanged,
    this.hintText,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (label != null) ...[
          Text(
            label!,
            style: GoogleFonts.openSans(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: AppColors.darkBlue,
            ),
          ),
          const SizedBox(height: 8),
        ],
        Container(
          decoration: BoxDecoration(
            color: AppColors.lightGrey,
            borderRadius: BorderRadius.circular(12),
          ),
          child: DropdownButtonFormField<T>(
            value: value,
            onChanged: onChanged,
            style: GoogleFonts.openSans(
              fontSize: 16,
              color: AppColors.darkBlue,
            ),
            decoration: InputDecoration(
              hintText: hintText,
              hintStyle: GoogleFonts.openSans(
                fontSize: 16,
                color: AppColors.greyText,
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(16),
            ),
            dropdownColor: AppColors.white,
            icon: const Icon(
              Icons.keyboard_arrow_down,
              color: AppColors.primaryBlue,
            ),
            items: items.map<DropdownMenuItem<T>>((T item) {
              return DropdownMenuItem<T>(
                value: item,
                child: Text(itemLabel(item)),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}