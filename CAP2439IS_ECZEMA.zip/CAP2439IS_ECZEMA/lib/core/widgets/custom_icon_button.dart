import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

/// A customizable icon button widget with flexible styling options.
///
/// [CustomIconButton] provides a versatile button component that can be styled
/// as either circular or rounded rectangular. It offers full control over size,
/// colors, and spacing while maintaining consistent visual design.
///
/// Key features:
/// - Circular or rounded rectangular shape options
/// - Customizable background and icon colors
/// - Adjustable button and icon sizes
/// - Optional margin control
/// - Default primary blue theme styling
///
/// Use cases:
/// - Action buttons in headers and toolbars
/// - Quick action buttons in lists or cards
/// - Navigation controls (back, forward, menu)
/// - Floating action buttons
/// - Any scenario requiring icon-based interaction
///
/// Example usage:
/// ```dart
/// CustomIconButton(
///   icon: Icons.delete,
///   onPressed: () => _deleteItem(),
///   backgroundColor: Colors.red.withOpacity(0.1),
///   iconColor: Colors.red,
///   isCircular: true,
/// )
/// ```
class CustomIconButton extends StatelessWidget {
  /// The icon to display in the button
  final IconData icon;

  /// Callback function invoked when the button is pressed
  final VoidCallback onPressed;

  /// Optional background color (defaults to primary blue with 10% opacity)
  final Color? backgroundColor;

  /// Optional icon color (defaults to primary blue)
  final Color? iconColor;

  /// The total size of the button container (default: 44)
  final double size;

  /// The size of the icon itself (default: 20)
  final double iconSize;

  /// Optional outer margin spacing around the button
  final EdgeInsets? margin;

  /// Whether the button should be circular instead of rounded rectangular (default: false)
  final bool isCircular;

  const CustomIconButton({
    super.key,
    required this.icon,
    required this.onPressed,
    this.backgroundColor,
    this.iconColor,
    this.size = 44,
    this.iconSize = 20,
    this.margin,
    this.isCircular = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      child: GestureDetector(
        onTap: onPressed,
        child: Container(
          width: size,
          height: size,
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: backgroundColor ?? AppColors.primaryBlue.withValues(alpha: 0.1),
            borderRadius: isCircular ? null : BorderRadius.circular(12),
            shape: isCircular ? BoxShape.circle : BoxShape.rectangle,
          ),
          child: Icon(
            icon,
            color: iconColor ?? AppColors.primaryBlue,
            size: iconSize,
          ),
        ),
      ),
    );
  }
}