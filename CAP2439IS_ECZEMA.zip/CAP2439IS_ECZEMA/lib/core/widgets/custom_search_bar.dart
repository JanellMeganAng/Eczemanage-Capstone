import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../constants/app_colors.dart';

/// A styled search bar widget with search icon and customizable appearance.
///
/// [CustomSearchBar] provides a consistent search input experience across the
/// application with a clean, modern design. It includes a search icon prefix
/// and subtle shadow effect for visual depth.
///
/// Key features:
/// - Search icon prefix for clear visual affordance
/// - Soft shadow effect for elevated appearance
/// - Customizable hint text and margins
/// - Optional external text controller for programmatic control
/// - Real-time search with onChange callback
///
/// Use cases:
/// - Filtering lists of items (symptoms, records, products)
/// - Search functionality in data-heavy screens
/// - Any scenario requiring text-based filtering
/// - Quick lookup in catalogs or databases
///
/// Example usage:
/// ```dart
/// CustomSearchBar(
///   hintText: 'Search symptoms...',
///   onChanged: (query) {
///     setState(() => _filterResults(query));
///   },
///   margin: EdgeInsets.all(16),
/// )
/// ```
class CustomSearchBar extends StatelessWidget {
  /// The placeholder text displayed when the search bar is empty
  final String hintText;

  /// Callback function invoked whenever the search text changes
  final Function(String) onChanged;

  /// Optional controller for programmatic text manipulation
  final TextEditingController? controller;

  /// The outer margin spacing around the search bar
  final EdgeInsets margin;

  const CustomSearchBar({
    super.key,
    required this.hintText,
    required this.onChanged,
    this.controller,
    this.margin = const EdgeInsets.fromLTRB(24, 0, 24, 16),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        onChanged: onChanged,
        style: GoogleFonts.openSans(
          fontSize: 16,
          color: AppColors.darkBlue,
        ),
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: GoogleFonts.openSans(
            fontSize: 16,
            color: AppColors.greyText,
          ),
          prefixIcon: const Icon(
            Icons.search,
            color: AppColors.greyText,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.all(16),
        ),
      ),
    );
  }
}