import 'package:flutter/material.dart';

/**
 * Global color constants for the EczeManage app.
 *
 * Contains all colors from the mood board and design system,
 * providing consistent theming throughout the application.
 */
class AppColors {
  /// Primary colors from mood board - main brand colors
  static const Color primaryBlue = Color(0xFF474ED8);
  static const Color lightBlue = Color(0xFF6478CE);
  static const Color darkBlue = Color(0xFF000245);

  /// Neutral colors for backgrounds and text
  static const Color backgroundGradientTop = Color(0xFFDEE4FE);
  static const Color backgroundGradientBottom = Color(0xFFF7F7F7);
  static const Color white = Colors.white;
  static const Color greyText = Color(0xFF7F7F7F);
  static const Color lightGrey = Color(0xFFDEE4FE);

  /// Background gradient used across the app
  static const LinearGradient backgroundGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [backgroundGradientTop, backgroundGradientBottom],
  );
}
