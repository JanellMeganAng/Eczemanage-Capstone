import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';

/**
 * Global text styles using Google Fonts.
 *
 * Contains consistent typography across the app with standardized
 * font sizes, weights, and colors for different UI elements.
 */
class AppTextStyles {
  /// Main heading style using Quicksand font - used for titles
  static TextStyle headingQuicksand = GoogleFonts.quicksand(
    fontSize: 32,
    fontWeight: FontWeight.bold,
    color: AppColors.darkBlue,
  );

  /// Subtitle text style using Open Sans - used for descriptions
  static TextStyle subtextOpenSans = GoogleFonts.openSans(
    fontSize: 14,
    fontWeight: FontWeight.w500,
    fontStyle: FontStyle.italic,
    color: AppColors.primaryBlue,
  );

  /// Primary button text style using Open Sans - white text for filled buttons
  static TextStyle buttonText = GoogleFonts.openSans(
    fontSize: 16,
    fontWeight: FontWeight.bold,
    color: AppColors.white,
  );

  /// Secondary button text style using Open Sans - colored text for outline buttons
  static TextStyle secondaryButtonText = GoogleFonts.openSans(
    fontSize: 16,
    fontWeight: FontWeight.bold,
    color: AppColors.primaryBlue,
  );
}
