import 'package:flutter/material.dart';
import 'app_colors.dart';
import 'app_text_styles.dart';

/**
 * Global button styles for consistent UI across the app.
 *
 * Contains reusable button configurations including primary,
 * secondary, text, and small button styles with consistent styling.
 */
class AppButtonStyles {
  /// Primary filled button style - used for main actions like "GET STARTED"
  static ButtonStyle primaryButton = ElevatedButton.styleFrom(
    backgroundColor: AppColors.primaryBlue,
    foregroundColor: AppColors.white,
    elevation: 0,
    padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 32),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
    textStyle: AppTextStyles.buttonText,
  );

  /// Secondary outlined button style - used for secondary actions like "I HAVE AN ACCOUNT"
  static ButtonStyle secondaryButton = OutlinedButton.styleFrom(
    foregroundColor: AppColors.primaryBlue,
    side: const BorderSide(color: AppColors.primaryBlue, width: 2),
    elevation: 0,
    padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 32),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
    textStyle: AppTextStyles.secondaryButtonText,
  );

  /// Text button style - used for minimal actions
  static ButtonStyle textButton = TextButton.styleFrom(
    foregroundColor: AppColors.primaryBlue,
    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
    textStyle: AppTextStyles.secondaryButtonText,
  );

  /// Small button style - used for compact UI elements
  static ButtonStyle smallButton = ElevatedButton.styleFrom(
    backgroundColor: AppColors.primaryBlue,
    foregroundColor: AppColors.white,
    elevation: 0,
    padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
  );
}
