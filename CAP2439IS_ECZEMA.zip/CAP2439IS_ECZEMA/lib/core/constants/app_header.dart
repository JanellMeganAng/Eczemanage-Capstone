import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../screens/dashboard/weather_page.dart';

class AppHeader extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final bool showMenu;
  final bool showSync;
  final VoidCallback? onMenuPressed;
  final VoidCallback? onSyncPressed;

  const AppHeader({
    Key? key,
    required this.title,
    this.showMenu = true,
    this.showSync = true,
    this.onMenuPressed,
    this.onSyncPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          showMenu
              ? IconButton(
            icon: const Icon(Icons.menu, color: AppColors.primaryBlue),
            onPressed: onMenuPressed ?? () {
              // Default menu action
              Scaffold.of(context).openDrawer();
            },
          )
              : const SizedBox(width: 48), // Placeholder for alignment
          Text(
            title,
            style: GoogleFonts.quicksand(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
            ),
          ),
          showSync
              ? IconButton(
            icon: const Icon(Icons.cloud_outlined, color: AppColors.primaryBlue),
            onPressed: onSyncPressed ?? () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const WeatherPage(),
                ),
              );
            },
          )
              : const SizedBox(width: 48), // Placeholder for alignment
        ],
      ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(70);
}