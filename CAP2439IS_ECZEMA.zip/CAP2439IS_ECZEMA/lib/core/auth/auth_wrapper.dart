import 'package:flutter/material.dart';
import '../../services/session_service.dart';
import '../../services/auth_service.dart';
import '../../screens/welcome/welcome_screen.dart';
import '../../screens/dashboard/dashboard_screen.dart';

/// AuthWrapper - Authentication Entry Point
///
/// This acts as a security checkpoint when the app launches.
/// It determines the initial screen based on authentication state:
/// 1. Checks if user has a valid "Remember Me" session saved
/// 2. Validates session hasn't expired (14-day limit)
/// 3. If valid → Auto-login and navigate to Dashboard
/// 4. If invalid/expired → Navigate to Welcome Screen
///
/// Implementation Details:
/// - First widget loaded when app starts (referenced in main.dart)
/// - Retrieves saved credentials from local storage via SessionService
/// - Automatically restores user session without re-login
/// - Enables persistent authentication across app restarts
class AuthWrapper extends StatefulWidget {
  const AuthWrapper({super.key});

  @override
  State<AuthWrapper> createState() => _AuthWrapperState();
}

/// Private state class that manages the authentication checking logic
class _AuthWrapperState extends State<AuthWrapper> {
  // SessionService: Handles saving/loading "Remember Me" data from phone storage
  final _sessionService = SessionService();

  // AuthService: Handles user login/logout and authentication status
  final _authService = AuthService();

  // Flag to show loading spinner while checking credentials
  bool _isChecking = true;

  @override
  void initState() {
    super.initState();
    // Start checking for saved session as soon as the widget loads
    _checkSession();
  }

  /// Checks if user has a valid saved session from previous login
  Future<void> _checkSession() async {
    // Ask SessionService: "Do we have saved login info?"
    final hasSession = await _sessionService.hasValidSession();

    if (hasSession) {
      // Get the saved user credentials (email and user ID)
      final credentials = await _sessionService.getSavedCredentials();
      if (credentials != null) {
        // Automatically log the user in without requiring password again
        _authService.setMockUser(
          DynamicMockUser(
            credentials['userId']!,
            credentials['email']!,
          )
        );
      }
    }

    // Stop showing loading spinner, show the appropriate screen
    if (mounted) {
      setState(() {
        _isChecking = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Show loading spinner while checking credentials
    if (_isChecking) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    // Check if user is logged in
    final isAuthenticated = _authService.isAuthenticated;

    // Route to appropriate screen:
    // - If authenticated → Dashboard (user is logged in)
    // - If not authenticated → Welcome Screen (user needs to log in)
    return isAuthenticated ? const DashboardScreen() : const WelcomeScreen();
  }
}
