import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/trigger_model.dart';

class TriggerStorage {
  static const String _storageKey = 'triggers';

  static Future<List<TriggerModel>> getAllTriggers() async {
    final prefs = await SharedPreferences.getInstance();
    final triggersJson = prefs.getStringList(_storageKey) ?? [];

    return triggersJson.map((json) {
      final map = Map<String, dynamic>.from(jsonDecode(json));
      return TriggerModel.fromMap(map);
    }).toList();
  }

  static Future<void> saveTrigger(TriggerModel trigger) async {
    final prefs = await SharedPreferences.getInstance();
    final triggers = await getAllTriggers();

    // Create new trigger with ID and timestamp
    final newTrigger = trigger.copyWith(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      createdAt: DateTime.now(),
    );

    triggers.add(newTrigger);

    final triggersJson = triggers.map((trigger) => jsonEncode(trigger.toMap())).toList();
    await prefs.setStringList(_storageKey, triggersJson);
  }

  static Future<void> updateTrigger(String id, TriggerModel updatedTrigger) async {
    final prefs = await SharedPreferences.getInstance();
    final triggers = await getAllTriggers();

    final index = triggers.indexWhere((trigger) => trigger.id == id);
    if (index != -1) {
      // Update existing trigger while preserving original creation date
      final originalTrigger = triggers[index];
      final updated = updatedTrigger.copyWith(
        id: id,
        createdAt: originalTrigger.createdAt,
      );

      triggers[index] = updated;

      final triggersJson = triggers.map((trigger) => jsonEncode(trigger.toMap())).toList();
      await prefs.setStringList(_storageKey, triggersJson);
    }
  }

  static Future<void> deleteTrigger(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final triggers = await getAllTriggers();

    triggers.removeWhere((trigger) => trigger.id == id);

    final triggersJson = triggers.map((trigger) => jsonEncode(trigger.toMap())).toList();
    await prefs.setStringList(_storageKey, triggersJson);
  }

  static Future<TriggerModel?> getTriggerById(String id) async {
    final triggers = await getAllTriggers();
    try {
      return triggers.firstWhere((trigger) => trigger.id == id);
    } catch (e) {
      return null;
    }
  }

  static Future<List<TriggerModel>> getTriggersByCategory(String category) async {
    final triggers = await getAllTriggers();
    return triggers.where((trigger) => trigger.triggerCategory == category).toList();
  }

  static Future<void> clearAllTriggers() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_storageKey);
  }

  static Future<int> getTriggersCount() async {
    final triggers = await getAllTriggers();
    return triggers.length;
  }

  static Future<List<TriggerModel>> getRecentTriggers({int limit = 5}) async {
    final triggers = await getAllTriggers();

    // Sort by creation date (newest first)
    triggers.sort((a, b) => b.createdAt.compareTo(a.createdAt));

    return triggers.take(limit).toList();
  }
}