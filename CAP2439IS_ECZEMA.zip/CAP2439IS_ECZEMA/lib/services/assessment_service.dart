// For production, replace static storage with SharedPreferences
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class AssessmentService {
  static const String _assessmentKey = 'poem_assessments';

  // In a real app, you'd use SharedPreferences. For demo, using static storage
  static List<Map<String, dynamic>> _assessments = [];

  static Future<List<Map<String, dynamic>>> getAssessmentHistory() async {
    // In production: return await SharedPreferences.getInstance()...
    return List.from(_assessments);
  }

  static Future<void> saveAssessment({
    required int totalScore,
    required List<int?> answers,
    required String severityLevel,
  }) async {
    final assessment = {
      'id': DateTime.now().millisecondsSinceEpoch.toString(),
      'date': DateTime.now().toIso8601String(),
      'totalScore': totalScore,
      'answers': answers,
      'severityLevel': severityLevel,
    };

    _assessments.insert(0, assessment); // Most recent first
    // In production: save to SharedPreferences
  }

  static Future<Map<String, dynamic>?> getLatestAssessment() async {
    if (_assessments.isEmpty) return null;
    return _assessments.first;
  }

  static Future<bool> canTakeAssessment() async {
    final latest = await getLatestAssessment();
    if (latest == null) return true;

    final lastDate = DateTime.parse(latest['date']);
    final daysDiff = DateTime.now().difference(lastDate).inDays;
    return daysDiff >= 7; // Can take once per week
  }

  static Future<DateTime?> getNextAvailableDate() async {
    final latest = await getLatestAssessment();
    if (latest == null) return null;

    final lastDate = DateTime.parse(latest['date']);
    return lastDate.add(Duration(days: 7));
  }
}