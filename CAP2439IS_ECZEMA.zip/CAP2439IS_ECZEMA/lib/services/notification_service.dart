import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz_data;

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    tz_data.initializeTimeZones();

    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const DarwinInitializationSettings initializationSettingsIOS =
        DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const InitializationSettings initializationSettings =
        InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
    );

    await _flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) async {
        // Handle notification tap
        print('Notification tapped: ${response.payload}');
      },
    );

    // Create notification channel for Android
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'care_routine_channel', // Channel ID
      'Care Routine Reminders', // Channel name
      description: 'Notifications for care routine reminders',
      importance: Importance.high,
      playSound: true,
      enableVibration: true,
    );

    await _flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    // Request permissions for Android 13+
    final androidPlugin = _flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

    if (androidPlugin != null) {
      await androidPlugin.requestNotificationsPermission();
      await androidPlugin.requestExactAlarmsPermission();
    }

    print('Notification service initialized successfully');
  }

  Future<void> scheduleRepeatingNotification({
    required int id,
    required String title,
    required String body,
    required String interval,
    required List<String> timeOfDay,
    String? payload,
  }) async {
    try {
      // Cancel existing notification with same ID
      await _flutterLocalNotificationsPlugin.cancel(id);

      const AndroidNotificationDetails androidNotificationDetails =
          AndroidNotificationDetails(
        'care_routine_channel',
        'Care Routine Reminders',
        channelDescription: 'Notifications for care routine reminders',
        importance: Importance.high,
        priority: Priority.high,
        showWhen: true,
      );

      const DarwinNotificationDetails iosNotificationDetails =
          DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      );

      const NotificationDetails notificationDetails = NotificationDetails(
        android: androidNotificationDetails,
        iOS: iosNotificationDetails,
      );

      // Parse interval and schedule accordingly
      print('Scheduling notification with interval: "$interval"');

      if (interval.toLowerCase().contains('hour') || interval.toLowerCase().contains('h')) {
        await _scheduleHourlyNotification(
          id: id,
          title: title,
          body: body,
          interval: interval,
          notificationDetails: notificationDetails,
          payload: payload,
        );
      } else if (interval.toLowerCase().contains('min')) {
        await _scheduleMinutelyNotification(
          id: id,
          title: title,
          body: body,
          interval: interval,
          notificationDetails: notificationDetails,
          payload: payload,
        );
      } else if (interval.toLowerCase().contains('daily')) {
        await _scheduleDailyNotification(
          id: id,
          title: title,
          body: body,
          timeOfDay: timeOfDay,
          notificationDetails: notificationDetails,
          payload: payload,
        );
      } else {
        // Fallback: treat as hourly if we can't parse
        print('Unknown interval format: $interval, defaulting to hourly');
        await _scheduleHourlyNotification(
          id: id,
          title: title,
          body: body,
          interval: 'Every 1 hour',
          notificationDetails: notificationDetails,
          payload: payload,
        );
      }

      print('Notification scheduled successfully: $title');
      print('Interval: $interval');
      print('Time of day: $timeOfDay');
    } catch (e) {
      print('Error scheduling notification: $e');
    }
  }

  Future<void> _scheduleHourlyNotification({
    required int id,
    required String title,
    required String body,
    required String interval,
    required NotificationDetails notificationDetails,
    String? payload,
  }) async {
    // Extract hours and minutes from interval
    // Handles: "Every 2 hours", "Every 2h", "Every 2h 30m"

    int totalMinutes = 0;

    // Extract hours
    final RegExp hourRegex = RegExp(r'(\d+)\s*h(?:our)?s?');
    final hourMatch = hourRegex.firstMatch(interval);
    if (hourMatch != null) {
      final hours = int.tryParse(hourMatch.group(1)!) ?? 0;
      totalMinutes += hours * 60;
    }

    // Extract additional minutes
    final RegExp minuteRegex = RegExp(r'(\d+)\s*m(?:in)?s?');
    final minuteMatch = minuteRegex.firstMatch(interval);
    if (minuteMatch != null) {
      final minutes = int.tryParse(minuteMatch.group(1)!) ?? 0;
      totalMinutes += minutes;
    }

    // If no time found, default to 1 hour
    if (totalMinutes == 0) {
      totalMinutes = 60;
    }

    print('Parsed interval "$interval" as $totalMinutes minutes');

    final now = DateTime.now();
    final scheduledDate = now.add(Duration(minutes: totalMinutes));

    await _flutterLocalNotificationsPlugin.zonedSchedule(
      id,
      title,
      body,
      tz.TZDateTime.from(scheduledDate, tz.local),
      notificationDetails,
      payload: payload,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  Future<void> _scheduleMinutelyNotification({
    required int id,
    required String title,
    required String body,
    required String interval,
    required NotificationDetails notificationDetails,
    String? payload,
  }) async {
    // Extract minutes from interval (e.g., "Every 30 mins" -> 30)
    final RegExp minuteRegex = RegExp(r'(\d+)\s*min');
    final match = minuteRegex.firstMatch(interval);
    final minutes = match != null ? int.tryParse(match.group(1)!) ?? 1 : 1;

    print('Scheduling minute-based notification every $minutes minutes');

    // For minute-based intervals, schedule multiple notifications in advance
    // Schedule notifications for the next 24 hours (enough for testing)
    final now = DateTime.now();
    final endTime = now.add(const Duration(hours: 24));
    int notificationCount = 0;

    DateTime nextScheduledTime = now.add(Duration(minutes: minutes));

    while (nextScheduledTime.isBefore(endTime) && notificationCount < 100) {
      await _flutterLocalNotificationsPlugin.zonedSchedule(
        id + notificationCount, // Unique ID for each notification
        title,
        body,
        tz.TZDateTime.from(nextScheduledTime, tz.local),
        notificationDetails,
        payload: payload,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
      );

      nextScheduledTime = nextScheduledTime.add(Duration(minutes: minutes));
      notificationCount++;
    }

    print('Scheduled $notificationCount notifications over the next 24 hours');
  }

  Future<void> _scheduleDailyNotification({
    required int id,
    required String title,
    required String body,
    required List<String> timeOfDay,
    required NotificationDetails notificationDetails,
    String? payload,
  }) async {
    // Schedule for each selected time of day
    for (int i = 0; i < timeOfDay.length; i++) {
      final time = _getTimeFromPeriod(timeOfDay[i]);
      final now = DateTime.now();
      var scheduledDate = DateTime(
        now.year,
        now.month,
        now.day,
        time.hour,
        time.minute,
      );

      // If the time has passed today, schedule for tomorrow
      if (scheduledDate.isBefore(now)) {
        scheduledDate = scheduledDate.add(const Duration(days: 1));
      }

      await _flutterLocalNotificationsPlugin.zonedSchedule(
        id + i, // Different ID for each time
        title,
        body,
        tz.TZDateTime.from(scheduledDate, tz.local),
        notificationDetails,
        payload: payload,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time,
      );
    }
  }

  TimeOfDay _getTimeFromPeriod(String period) {
    switch (period.toLowerCase()) {
      case 'morning':
        return const TimeOfDay(hour: 8, minute: 0);
      case 'afternoon':
        return const TimeOfDay(hour: 14, minute: 0);
      case 'evening':
        return const TimeOfDay(hour: 18, minute: 0);
      case 'night':
        return const TimeOfDay(hour: 21, minute: 0);
      default:
        return const TimeOfDay(hour: 9, minute: 0);
    }
  }

  Future<void> cancelNotification(int id) async {
    // Cancel the main notification
    await _flutterLocalNotificationsPlugin.cancel(id);

    // Cancel any minute-based notifications (up to 100 notifications)
    for (int i = 0; i < 100; i++) {
      await _flutterLocalNotificationsPlugin.cancel(id + i);
    }
  }

  Future<void> cancelAllNotifications() async {
    await _flutterLocalNotificationsPlugin.cancelAll();
  }

  Future<List<PendingNotificationRequest>> getPendingNotifications() async {
    return await _flutterLocalNotificationsPlugin.pendingNotificationRequests();
  }

  /// Show an immediate notification for testing
  Future<void> showImmediateNotification({
    required int id,
    required String title,
    required String body,
    String? payload,
  }) async {
    const AndroidNotificationDetails androidNotificationDetails =
        AndroidNotificationDetails(
      'care_routine_channel',
      'Care Routine Reminders',
      channelDescription: 'Notifications for care routine reminders',
      importance: Importance.high,
      priority: Priority.high,
      showWhen: true,
      playSound: true,
      enableVibration: true,
    );

    const DarwinNotificationDetails iosNotificationDetails =
        DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const NotificationDetails notificationDetails = NotificationDetails(
      android: androidNotificationDetails,
      iOS: iosNotificationDetails,
    );

    await _flutterLocalNotificationsPlugin.show(
      id,
      title,
      body,
      notificationDetails,
      payload: payload,
    );

    print('Immediate notification shown: $title - $body');
  }
}