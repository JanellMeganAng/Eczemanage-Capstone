import 'package:cloud_firestore/cloud_firestore.dart';

// Import models
import '../models/user_model.dart';
import '../models/daily_log_model.dart';
import '../models/onboarding_data_model.dart';
import '../models/flareup_log_model.dart';
import '../models/weekly_log_model.dart';
import '../models/environment_log_model.dart';

/**
 * Firestore service for managing database operations.
 *
 * Provides CRUD operations for all data models including users,
 * daily logs, weekly logs, flare-up logs, environment logs, and onboarding data.
 * Uses Firebase Cloud Firestore as the backend database.
 */
class FirestoreService {
  /// Firebase Firestore database instance
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // -------------------------
  // Users
  // -------------------------

  /// Creates or updates a user document in Firestore
  ///
  /// [user] The user model to save
  Future<void> setUser(UserModel user) {
    return _db.collection('users').doc(user.id).set(user.toMap());
  }

  /// Retrieves a user by ID from Firestore
  ///
  /// [id] The user ID to retrieve
  /// Returns the user model or null if not found
  Future<UserModel?> getUser(String id) async {
    final doc = await _db.collection('users').doc(id).get();
    if (!doc.exists) return null;
    return UserModel.fromMap(doc.id, doc.data()!);
  }

  /// Gets a user by email from Firestore
  ///
  /// [email] The user email to search for
  /// Returns the user model or null if not found
  Future<UserModel?> getUserByEmail(String email) async {
    final querySnapshot = await _db
        .collection('users')
        .where('email', isEqualTo: email)
        .limit(1)
        .get();

    if (querySnapshot.docs.isEmpty) return null;

    final doc = querySnapshot.docs.first;
    return UserModel.fromMap(doc.id, doc.data());
  }

  /// Streams all users from Firestore in real-time
  ///
  /// Returns a stream of user models
  Stream<List<UserModel>> streamUsers() {
    return _db
        .collection('users')
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => UserModel.fromMap(doc.id, doc.data()))
              .toList(),
        );
  }

  /// Deletes a user document from Firestore
  ///
  /// [id] The user ID to delete
  Future<void> deleteUser(String id) {
    return _db.collection('users').doc(id).delete();
  }

  // -------------------------
  // Daily Logs
  // -------------------------

  /// Creates or updates a daily log document in Firestore
  ///
  /// [log] The daily log model to save
  Future<void> setDailyLog(DailyLog log) {
    return _db.collection('dailyLogs').doc(log.id).set(log.toMap());
  }

  /// Streams daily logs for a specific user from Firestore in real-time
  ///
  /// [userId] The user ID to filter daily logs by
  /// Returns a stream of daily log models
  Stream<List<DailyLog>> streamDailyLogs(String userId) {
    return _db
        .collection('dailyLogs')
        .where('userId', isEqualTo: userId)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => DailyLog.fromMap(doc.id, doc.data()))
              .toList(),
        );
  }

  /// Deletes a daily log document from Firestore
  ///
  /// [id] The daily log ID to delete
  Future<void> deleteDailyLog(String id) {
    return _db.collection('dailyLogs').doc(id).delete();
  }

  // -------------------------
  // Onboarding Data
  // -------------------------

  /// Creates or updates onboarding data in Firestore
  ///
  /// [data] The onboarding data model to save
  Future<void> setOnboardingData(OnboardingData data) {
    return _db.collection('onboardingData').doc(data.id).set(data.toMap());
  }

  /// Retrieves onboarding data by ID from Firestore
  ///
  /// [id] The onboarding data ID to retrieve
  /// Returns the onboarding data model or null if not found
  Future<OnboardingData?> getOnboardingData(String id) async {
    final doc = await _db.collection('onboardingData').doc(id).get();
    if (!doc.exists) return null;
    return OnboardingData.fromMap(doc.id, doc.data()!);
  }

  // -------------------------
  // Flareup Logs
  // -------------------------

  /// Creates or updates a flare-up log document in Firestore
  ///
  /// [log] The flare-up log model to save
  Future<void> setFlareupLog(FlareupLog log) {
    return _db.collection('flareupLogs').doc(log.id).set(log.toMap());
  }

  /// Streams flare-up logs for a specific user from Firestore in real-time
  ///
  /// [userId] The user ID to filter flare-up logs by
  /// Returns a stream of flare-up log models
  Stream<List<FlareupLog>> streamFlareupLogs(String userId) {
    return _db
        .collection('flareupLogs')
        .where('userId', isEqualTo: userId)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => FlareupLog.fromMap(doc.id, doc.data()))
              .toList(),
        );
  }

  /// Deletes a flare-up log document from Firestore
  ///
  /// [id] The flare-up log ID to delete
  Future<void> deleteFlareupLog(String id) {
    return _db.collection('flareupLogs').doc(id).delete();
  }

  // -------------------------
  // Weekly Logs
  // -------------------------

  /// Creates or updates a weekly log document in Firestore
  ///
  /// [log] The weekly log model to save
  Future<void> setWeeklyLog(WeeklyLog log) {
    return _db.collection('weeklyLogs').doc(log.id).set(log.toMap());
  }

  /// Streams weekly logs for a specific user from Firestore in real-time
  ///
  /// [userId] The user ID to filter weekly logs by
  /// Returns a stream of weekly log models
  Stream<List<WeeklyLog>> streamWeeklyLogs(String userId) {
    return _db
        .collection('weeklyLogs')
        .where('userId', isEqualTo: userId)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => WeeklyLog.fromMap(doc.id, doc.data()))
              .toList(),
        );
  }

  /// Deletes a weekly log document from Firestore
  ///
  /// [id] The weekly log ID to delete
  Future<void> deleteWeeklyLog(String id) {
    return _db.collection('weeklyLogs').doc(id).delete();
  }

  // -------------------------
  // Environment Logs
  // -------------------------

  /// Creates or updates an environment log document in Firestore
  ///
  /// [log] The environment log model to save
  Future<void> setEnvironmentLog(EnvironmentLog log) {
    return _db.collection('environmentLogs').doc(log.id).set(log.toMap());
  }

  /// Streams environment logs for a specific user from Firestore in real-time
  ///
  /// [userId] The user ID to filter environment logs by
  /// Returns a stream of environment log models
  Stream<List<EnvironmentLog>> streamEnvironmentLogs(String userId) {
    return _db
        .collection('environmentLogs')
        .where('userId', isEqualTo: userId)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => EnvironmentLog.fromMap(doc.id, doc.data()))
              .toList(),
        );
  }

  /// Deletes an environment log document from Firestore
  ///
  /// [id] The environment log ID to delete
  Future<void> deleteEnvironmentLog(String id) {
    return _db.collection('environmentLogs').doc(id).delete();
  }
}
