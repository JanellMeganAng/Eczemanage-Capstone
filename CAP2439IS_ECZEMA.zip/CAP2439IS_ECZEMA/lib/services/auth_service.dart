import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';
import 'firestore_services.dart';
import 'dart:convert';
import 'package:crypto/crypto.dart';

/// MockUser - Static Test User Object
///
/// Provides a predefined test user for development.
/// Implements Firebase User interface without requiring full auth setup.
/// Default credentials: jose_dela_cruz@test.com (user1)
class MockUser implements User {
  @override
  String get uid => "user1"; // Use the hardcoded user ID from seed data

  @override
  String? get email => "jose_dela_cruz@test.com";

  @override
  String? get displayName => "Jose Dela Cruz";

  @override
  bool get emailVerified => true;

  @override
  bool get isAnonymous => false;

  @override
  UserMetadata get metadata => throw UnimplementedError();

  @override
  String? get phoneNumber => null;

  @override
  String? get photoURL => null;

  @override
  List<UserInfo> get providerData => [];

  @override
  String? get refreshToken => null;

  @override
  String? get tenantId => null;

  @override
  Future<void> delete() => throw UnimplementedError();

  @override
  Future<String> getIdToken([bool forceRefresh = false]) =>
      throw UnimplementedError();

  @override
  Future<IdTokenResult> getIdTokenResult([bool forceRefresh = false]) =>
      throw UnimplementedError();

  @override
  Future<UserCredential> linkWithCredential(AuthCredential credential) =>
      throw UnimplementedError();

  @override
  Future<ConfirmationResult> linkWithPhoneNumber(
    String phoneNumber, [
    RecaptchaVerifier? verifier,
  ]) => throw UnimplementedError();

  @override
  Future<UserCredential> linkWithPopup(AuthProvider provider) =>
      throw UnimplementedError();

  @override
  Future<void> linkWithRedirect(AuthProvider provider) =>
      throw UnimplementedError();

  @override
  MultiFactor get multiFactor => throw UnimplementedError();

  @override
  Future<UserCredential> reauthenticateWithCredential(
    AuthCredential credential,
  ) => throw UnimplementedError();

  @override
  Future<UserCredential> reauthenticateWithPopup(AuthProvider provider) =>
      throw UnimplementedError();

  @override
  Future<void> reauthenticateWithRedirect(AuthProvider provider) =>
      throw UnimplementedError();

  @override
  Future<void> reload() => throw UnimplementedError();

  @override
  Future<void> sendEmailVerification([
    ActionCodeSettings? actionCodeSettings,
  ]) => throw UnimplementedError();

  @override
  Future<User> unlink(String providerId) => throw UnimplementedError();

  @override
  Future<void> updateDisplayName(String? displayName) =>
      throw UnimplementedError();

  @override
  Future<void> updateEmail(String newEmail) => throw UnimplementedError();

  @override
  Future<void> updatePassword(String newPassword) => throw UnimplementedError();

  @override
  Future<void> updatePhoneNumber(PhoneAuthCredential phoneCredential) =>
      throw UnimplementedError();

  @override
  Future<void> updatePhotoURL(String? photoURL) => throw UnimplementedError();

  @override
  Future<void> updateProfile({String? displayName, String? photoURL}) =>
      throw UnimplementedError();

  @override
  Future<void> verifyBeforeUpdateEmail(
    String newEmail, [
    ActionCodeSettings? actionCodeSettings,
  ]) => throw UnimplementedError();

  @override
  Future<UserCredential> linkWithProvider(AuthProvider provider) =>
      throw UnimplementedError();

  @override
  Future<UserCredential> reauthenticateWithProvider(AuthProvider provider) =>
      throw UnimplementedError();
}

/// DynamicMockUser - Configurable Test User Object
///
/// Creates mock user instances with custom credentials.
/// Used for "Remember Me" auto-login and post-registration sessions.
/// Accepts any user ID and email unlike the static MockUser.
class DynamicMockUser implements User {
  final String _uid;
  final String _email;
  final String? _displayName;

  DynamicMockUser(this._uid, this._email, [this._displayName]);

  @override
  String get uid => _uid;

  @override
  String? get email => _email;

  @override
  String? get displayName => _displayName ?? _email.split('@')[0];

  @override
  bool get emailVerified => true;

  @override
  bool get isAnonymous => false;

  @override
  UserMetadata get metadata => throw UnimplementedError();

  @override
  String? get phoneNumber => null;

  @override
  String? get photoURL => null;

  @override
  List<UserInfo> get providerData => [];

  @override
  String? get refreshToken => null;

  @override
  String? get tenantId => null;

  @override
  Future<void> delete() => throw UnimplementedError();

  @override
  Future<String> getIdToken([bool forceRefresh = false]) =>
      throw UnimplementedError();

  @override
  Future<IdTokenResult> getIdTokenResult([bool forceRefresh = false]) =>
      throw UnimplementedError();

  @override
  Future<UserCredential> linkWithCredential(AuthCredential credential) =>
      throw UnimplementedError();

  @override
  Future<ConfirmationResult> linkWithPhoneNumber(
    String phoneNumber, [
    RecaptchaVerifier? verifier,
  ]) => throw UnimplementedError();

  @override
  Future<UserCredential> linkWithPopup(AuthProvider provider) =>
      throw UnimplementedError();

  @override
  Future<void> linkWithRedirect(AuthProvider provider) =>
      throw UnimplementedError();

  @override
  MultiFactor get multiFactor => throw UnimplementedError();

  @override
  Future<UserCredential> reauthenticateWithCredential(
    AuthCredential credential,
  ) => throw UnimplementedError();

  @override
  Future<UserCredential> reauthenticateWithPopup(AuthProvider provider) =>
      throw UnimplementedError();

  @override
  Future<void> reauthenticateWithRedirect(AuthProvider provider) =>
      throw UnimplementedError();

  @override
  Future<void> reload() => throw UnimplementedError();

  @override
  Future<void> sendEmailVerification([
    ActionCodeSettings? actionCodeSettings,
  ]) => throw UnimplementedError();

  @override
  Future<User> unlink(String providerId) => throw UnimplementedError();

  @override
  Future<void> updateDisplayName(String? displayName) =>
      throw UnimplementedError();

  @override
  Future<void> updateEmail(String newEmail) => throw UnimplementedError();

  @override
  Future<void> updatePassword(String newPassword) => throw UnimplementedError();

  @override
  Future<void> updatePhoneNumber(PhoneAuthCredential phoneCredential) =>
      throw UnimplementedError();

  @override
  Future<void> updatePhotoURL(String? photoURL) => throw UnimplementedError();

  @override
  Future<void> updateProfile({String? displayName, String? photoURL}) =>
      throw UnimplementedError();

  @override
  Future<void> verifyBeforeUpdateEmail(
    String newEmail, [
    ActionCodeSettings? actionCodeSettings,
  ]) => throw UnimplementedError();

  @override
  Future<UserCredential> linkWithProvider(AuthProvider provider) =>
      throw UnimplementedError();

  @override
  Future<UserCredential> reauthenticateWithProvider(AuthProvider provider) =>
      throw UnimplementedError();
}

/// AuthService - Central Authentication Manager
///
/// Handles all authentication operations for the application.
///
/// Core Responsibilities:
/// 1. User Registration - Creates accounts and stores data in Firestore
/// 2. User Login - Validates credentials against database
/// 3. User Logout - Terminates session and clears authentication state
/// 4. Session Management - Tracks currently authenticated user
///
/// Implementation:
/// - Integrates with Firebase Authentication and Firestore
/// - Saves user profile data to Firestore on registration
/// - Validates login credentials via testCredentials collection
/// - Uses mock user objects for development/testing
/// - Singleton pattern ensures single instance app-wide
class AuthService {
  // Singleton pattern
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  /// Firebase Authentication instance
  final FirebaseAuth _auth = FirebaseAuth.instance;

  /// Firestore service for user data management
  final FirestoreService _firestoreService = FirestoreService();

  /// Mock current user for testing (simulates a logged-in user)
  User? _mockCurrentUser;

  /// Get current authenticated user (including mock user for testing)
  User? get currentUser => _mockCurrentUser ?? _auth.currentUser;

  /// Stream of authentication state changes
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  /// Check if user is currently authenticated
  bool get isAuthenticated => currentUser != null;

  /// Register new user with email and password
  ///
  /// [userModel] Complete user data including personal information
  /// Returns the created user or throws an exception
  Future<User?> registerWithEmailAndPassword(UserModel userModel) async {
    try {
      // Create Firebase Auth user
      final UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: userModel.email,
        password: userModel
            .passwordHash, // This should be the plain password for registration
      );

      final User? user = result.user;
      if (user != null) {
        // Update the user model with the Firebase Auth UID
        final updatedUserModel = UserModel(
          id: user.uid, // Use Firebase Auth UID as user ID
          email: userModel.email,
          passwordHash: "", // Don't store password hash in Firestore
          firstName: userModel.firstName,
          lastName: userModel.lastName,
          birthdate: userModel.birthdate,
          gender: userModel.gender,
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        );

        // Save user data to Firestore
        await _firestoreService.setUser(updatedUserModel);

        return user;
      }
      return null;
    } catch (e) {
      throw Exception('Registration failed: ${e.toString()}');
    }
  }

  /// Sign in existing user with email and password
  ///
  /// [email] User's email address
  /// [password] User's password
  /// Returns the authenticated user or throws an exception
  Future<User?> signInWithEmailAndPassword(
    String email,
    String password,
  ) async {
    try {
      // For development/testing: Check if this is our test user
      if (email == "jose_dela_cruz@test.com" && password == "password123") {
        // Mock successful authentication for test user
        final mockUser = MockUser();
        setMockUser(mockUser);
        return mockUser;
      }

      // Check test credentials collection for new registered users
      final testCredential = await checkTestCredentials(email, password);
      if (testCredential != null) {
        final mockUser = DynamicMockUser(
          testCredential['userId'],
          email,
          testCredential['displayName'],
        );
        setMockUser(mockUser);
        return mockUser;
      }

      final UserCredential result = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return result.user;
    } catch (e) {
      // For development: Allow test user login even if Firebase Auth fails
      if (email == "jose_dela_cruz@test.com" && password == "password123") {
        final mockUser = MockUser();
        setMockUser(mockUser);
        return mockUser;
      }

      // Check test credentials as fallback
      final testCredential = await checkTestCredentials(email, password);
      if (testCredential != null) {
        final mockUser = DynamicMockUser(
          testCredential['userId'],
          email,
          testCredential['displayName'],
        );
        setMockUser(mockUser);
        return mockUser;
      }

      throw Exception('Login failed: ${e.toString()}');
    }
  }

  /// Check test credentials for development login (public for forgot password)
  Future<Map<String, dynamic>?> checkTestCredentials(
    String email,
    String password,
  ) async {
    try {
      final doc = await FirebaseFirestore.instance
          .collection('testCredentials')
          .doc(email)
          .get();

      if (doc.exists) {
        final data = doc.data()!;
        // If password is empty string, just check if email exists
        if (password.isEmpty) {
          return {'emailExists': true};
        }
        // Otherwise validate password (hash input and compare to stored hash)
        String? storedHash = data['passwordHash'] ?? data['password'];
        if (storedHash != null) {
          final inputHash = sha256.convert(utf8.encode(password)).toString();
          if (inputHash == storedHash) {
            // Find the user in users collection by email
            final userQuery = await FirebaseFirestore.instance
                .collection('users')
                .where('email', isEqualTo: email)
                .get();

            if (userQuery.docs.isNotEmpty) {
              final userData = userQuery.docs.first.data();
              return {
                'userId': userQuery.docs.first.id,
                'email': email,
                'displayName':
                    '${userData['firstName'] ?? ''} ${userData['lastName'] ?? ''}'
                        .trim(),
              };
            }
          }
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  /// Get user data from Firestore for current authenticated user
  ///
  /// Returns UserModel or null if not found
  Future<UserModel?> getCurrentUserData() async {
    if (currentUser != null) {
      return await _firestoreService.getUser(currentUser!.uid);
    }
    return null;
  }

  /// Set mock user for testing
  void setMockUser(User user) {
    _mockCurrentUser = user;
  }

  /// Clear mock user
  void clearMockUser() {
    _mockCurrentUser = null;
  }

  /// Sign out current user
  Future<void> signOut() async {
    try {
      clearMockUser(); // Clear mock user first
      await _auth.signOut();
    } catch (e) {
      clearMockUser(); // Clear mock user even if sign out fails
      throw Exception('Sign out failed: ${e.toString()}');
    }
  }

  /// Send password reset email
  ///
  /// [email] User's email address
  Future<void> resetPassword(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } catch (e) {
      throw Exception('Password reset failed: ${e.toString()}');
    }
  }

  /// Check if email is already registered
  ///
  /// [email] Email to check
  /// Returns true if email exists, false otherwise
  Future<bool> isEmailRegistered(String email) async {
    try {
      final methods = await _auth.fetchSignInMethodsForEmail(email);
      return methods.isNotEmpty;
    } catch (e) {
      return false;
    }
  }

  /// Update password for test credentials
  Future<void> updatePassword(String email, String newPassword) async {
    try {
      await FirebaseFirestore.instance
          .collection('testCredentials')
          .doc(email)
          .update({'password': newPassword});
    } catch (e) {
      throw Exception('Failed to update password: ${e.toString()}');
    }
  }
}
