import 'package:shared_preferences/shared_preferences.dart';

/// SessionService - Persistent Session Manager
///
/// Manages user session persistence for "Remember Me" functionality.
/// Stores and validates user credentials in local device storage.
///
/// Stored Data:
/// - User email address
/// - User ID
/// - Login timestamp
///
/// Session Validation:
/// - Checks if saved credentials exist
/// - Validates session age (expires after 14 days)
/// - Returns credentials for auto-login if valid
///
/// Technical Implementation:
/// - Uses SharedPreferences for local data persistence
/// - Data survives app closure and device restarts
/// - 14-day expiration follows industry security standards
/// - All data cleared on logout for security
class SessionService {
  // Singleton pattern
  static final SessionService _instance = SessionService._internal();
  factory SessionService() => _instance;
  SessionService._internal();

  // Storage keys
  static const String _keyRememberMe = 'remember_me';
  static const String _keyUserId = 'user_id';
  static const String _keyUserEmail = 'user_email';
  static const String _keyLoginTimestamp = 'login_timestamp';

  // Session duration: 14 days (industry standard)
  static const int sessionDurationDays = 14;

  /// Save remember me session
  Future<void> saveRememberMeSession({
    required String userId,
    required String email,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyRememberMe, true);
    await prefs.setString(_keyUserId, userId);
    await prefs.setString(_keyUserEmail, email);
    await prefs.setInt(_keyLoginTimestamp, DateTime.now().millisecondsSinceEpoch);
  }

  /// Check if user has valid remember me session
  Future<bool> hasValidSession() async {
    final prefs = await SharedPreferences.getInstance();
    final rememberMe = prefs.getBool(_keyRememberMe) ?? false;

    if (!rememberMe) return false;

    final timestamp = prefs.getInt(_keyLoginTimestamp);
    if (timestamp == null) return false;

    final loginDate = DateTime.fromMillisecondsSinceEpoch(timestamp);
    final now = DateTime.now();
    final difference = now.difference(loginDate).inDays;

    // Session expired after 14 days
    if (difference >= sessionDurationDays) {
      await clearSession();
      return false;
    }

    return true;
  }

  /// Get saved user credentials
  Future<Map<String, String>?> getSavedCredentials() async {
    final prefs = await SharedPreferences.getInstance();
    final hasValid = await hasValidSession();

    if (!hasValid) return null;

    final userId = prefs.getString(_keyUserId);
    final email = prefs.getString(_keyUserEmail);

    if (userId != null && email != null) {
      return {
        'userId': userId,
        'email': email,
      };
    }

    return null;
  }

  /// Clear session (used on logout)
  Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyRememberMe);
    await prefs.remove(_keyUserId);
    await prefs.remove(_keyUserEmail);
    await prefs.remove(_keyLoginTimestamp);
  }

  /// Update session timestamp (refresh session)
  Future<void> updateSessionTimestamp() async {
    final prefs = await SharedPreferences.getInstance();
    final rememberMe = prefs.getBool(_keyRememberMe) ?? false;

    if (rememberMe) {
      await prefs.setInt(_keyLoginTimestamp, DateTime.now().millisecondsSinceEpoch);
    }
  }
}
