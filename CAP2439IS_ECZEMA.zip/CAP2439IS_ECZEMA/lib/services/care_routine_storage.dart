import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class CareRoutineStorage {
  static const String _storageKey = 'care_routines';

  static Future<List<Map<String, dynamic>>> getAllRoutines() async {
    final prefs = await SharedPreferences.getInstance();
    final routinesJson = prefs.getStringList(_storageKey) ?? [];

    return routinesJson.map((json) =>
      Map<String, dynamic>.from(jsonDecode(json))
    ).toList();
  }

  static Future<void> saveRoutine(Map<String, dynamic> routine) async {
    final prefs = await SharedPreferences.getInstance();
    final routines = await getAllRoutines();

    // Add unique ID and timestamp
    routine['id'] = DateTime.now().millisecondsSinceEpoch.toString();
    routine['createdAt'] = DateTime.now().toIso8601String();
    routine['lastModified'] = DateTime.now().toIso8601String();

    routines.add(routine);

    final routinesJson = routines.map((routine) => jsonEncode(routine)).toList();
    await prefs.setStringList(_storageKey, routinesJson);
  }

  static Future<void> updateRoutine(String id, Map<String, dynamic> updatedRoutine) async {
    final prefs = await SharedPreferences.getInstance();
    final routines = await getAllRoutines();

    final index = routines.indexWhere((routine) => routine['id'] == id);
    if (index != -1) {
      updatedRoutine['id'] = id;
      updatedRoutine['lastModified'] = DateTime.now().toIso8601String();
      routines[index] = updatedRoutine;

      final routinesJson = routines.map((routine) => jsonEncode(routine)).toList();
      await prefs.setStringList(_storageKey, routinesJson);
    }
  }

  static Future<void> deleteRoutine(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final routines = await getAllRoutines();

    routines.removeWhere((routine) => routine['id'] == id);

    final routinesJson = routines.map((routine) => jsonEncode(routine)).toList();
    await prefs.setStringList(_storageKey, routinesJson);
  }

  static Future<Map<String, dynamic>?> getRoutineById(String id) async {
    final routines = await getAllRoutines();
    try {
      return routines.firstWhere((routine) => routine['id'] == id);
    } catch (e) {
      return null;
    }
  }

  static Future<int> getRoutineCount() async {
    final routines = await getAllRoutines();
    return routines.length;
  }
}