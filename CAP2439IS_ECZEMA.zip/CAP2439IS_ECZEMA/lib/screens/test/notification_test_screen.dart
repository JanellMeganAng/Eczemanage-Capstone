import 'package:flutter/material.dart';
import '../../services/notification_service.dart';

class NotificationTestScreen extends StatefulWidget {
  const NotificationTestScreen({super.key});

  @override
  State<NotificationTestScreen> createState() => _NotificationTestScreenState();
}

class _NotificationTestScreenState extends State<NotificationTestScreen> {
  final NotificationService _notificationService = NotificationService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notification Test'),
        backgroundColor: const Color(0xFF2E5BFF),
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Test Notifications',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color(0xFF2E5BFF),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Use these buttons to test if notifications are working:',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 30),

            ElevatedButton(
              onPressed: () => _testImmediateNotification(),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2E5BFF),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.all(16),
              ),
              child: const Text('Test Immediate Notification (Now!)'),
            ),

            const SizedBox(height: 15),

            ElevatedButton(
              onPressed: () => _testMinutelyNotification(),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF4CAF50),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.all(16),
              ),
              child: const Text('Test Every 1 Minute'),
            ),

            const SizedBox(height: 15),

            ElevatedButton(
              onPressed: () => _testHourlyNotification(),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF9800),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.all(16),
              ),
              child: const Text('Test Every 1 Hour'),
            ),

            const SizedBox(height: 15),

            ElevatedButton(
              onPressed: () => _testDailyNotification(),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF9C27B0),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.all(16),
              ),
              child: const Text('Test Daily at Morning'),
            ),

            const SizedBox(height: 30),

            ElevatedButton(
              onPressed: () => _showPendingNotifications(),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF607D8B),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.all(16),
              ),
              child: const Text('Show Pending Notifications'),
            ),

            const SizedBox(height: 15),

            ElevatedButton(
              onPressed: () => _cancelAllNotifications(),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.all(16),
              ),
              child: const Text('Cancel All Notifications'),
            ),
          ],
        ),
      ),
    );
  }

  void _testImmediateNotification() async {
    try {
      await _notificationService.showImmediateNotification(
        id: 999,
        title: '🧴 Test Notification',
        body: 'This notification should appear immediately!',
        payload: 'test_immediate',
      );

      _showSnackBar('Immediate notification sent! Check your notification panel.', Colors.green);
    } catch (e) {
      _showSnackBar('Error: $e', Colors.red);
    }
  }

  void _testMinutelyNotification() async {
    try {
      await _notificationService.scheduleRepeatingNotification(
        id: 2,
        title: 'Minutely Test',
        body: 'This notification repeats every minute',
        interval: 'Every 1 mins',
        timeOfDay: ['morning'],
        payload: 'test_minutely',
      );

      _showSnackBar('Minutely notification scheduled!', Colors.green);
    } catch (e) {
      _showSnackBar('Error: $e', Colors.red);
    }
  }

  void _testHourlyNotification() async {
    try {
      await _notificationService.scheduleRepeatingNotification(
        id: 3,
        title: 'Hourly Test',
        body: 'This notification repeats every hour',
        interval: 'Every 1 hour',
        timeOfDay: ['morning'],
        payload: 'test_hourly',
      );

      _showSnackBar('Hourly notification scheduled!', Colors.green);
    } catch (e) {
      _showSnackBar('Error: $e', Colors.red);
    }
  }

  void _testDailyNotification() async {
    try {
      await _notificationService.scheduleRepeatingNotification(
        id: 4,
        title: 'Daily Test',
        body: 'This notification appears daily in the morning',
        interval: 'daily',
        timeOfDay: ['morning'],
        payload: 'test_daily',
      );

      _showSnackBar('Daily notification scheduled for 8:00 AM!', Colors.green);
    } catch (e) {
      _showSnackBar('Error: $e', Colors.red);
    }
  }

  void _showPendingNotifications() async {
    try {
      final pending = await _notificationService.getPendingNotifications();

      if (pending.isEmpty) {
        _showSnackBar('No pending notifications', Colors.orange);
      } else {
        String message = 'Pending notifications: ${pending.length}\\n';
        for (var notification in pending) {
          message += '- ID: ${notification.id}, Title: ${notification.title}\\n';
        }

        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Pending Notifications'),
            content: SingleChildScrollView(
              child: Text(message),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('OK'),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      _showSnackBar('Error getting notifications: $e', Colors.red);
    }
  }

  void _cancelAllNotifications() async {
    try {
      await _notificationService.cancelAllNotifications();
      _showSnackBar('All notifications cancelled!', Colors.orange);
    } catch (e) {
      _showSnackBar('Error cancelling notifications: $e', Colors.red);
    }
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
        duration: const Duration(seconds: 3),
      ),
    );
  }
}