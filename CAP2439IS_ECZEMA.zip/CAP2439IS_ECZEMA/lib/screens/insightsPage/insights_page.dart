import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_styles.dart';
import '../../core/widgets/index.dart';

/// InsightsPage - AI-generated insights and pattern analysis for eczema management
///
/// This screen displays data-driven insights derived from user's logged data,
/// helping users understand patterns and correlations in their eczema triggers,
/// symptoms, and treatment effectiveness.
///
/// Key Features:
/// - Displays categorized insights (weather, care routine, triggers, symptoms)
/// - Filterable insights by date range, category, and severity
/// - Actionable recommendations for each insight
/// - User feedback mechanism (helpful/not relevant)
/// - Export functionality (PDF, CSV, share with doctor)
/// - Visual severity indicators with color coding
/// - Empty state when no insights match filters
///
/// User Interactions:
/// - Filter insights by date range (last week, month, 3 months, custom)
/// - Toggle insight categories on/off
/// - Adjust severity threshold filter
/// - Provide feedback on insight relevance
/// - Export insights in various formats
///
/// Data Flow:
/// - Reads: Mock insight data (will be replaced with AI-generated insights)
/// - Filters: Applies user-selected filters to insight list
/// - Exports: Generates reports in selected format
/// - Feedback: Stores user ratings for insight improvement
///
/// Insight Categories:
/// - Weather trends: Environmental factor correlations
/// - Care routine effectiveness: Treatment success patterns
/// - Trigger patterns: Common trigger identification
/// - Symptom correlations: Symptom relationship analysis
class InsightsPage extends StatefulWidget {
  const InsightsPage({super.key});

  @override
  State<InsightsPage> createState() => _InsightsPageState();
}

class _InsightsPageState extends State<InsightsPage> {
  // Filter state variables
  String selectedDateRange = 'Last week';  // Current date range filter
  Map<String, bool> insightCategories = {  // Category toggle states
    'Weather trends': true,
    'Care routine effectiveness': true,
    'Trigger patterns': false,
    'Symptom correlations': true,
  };
  double severityFilter = 5.0;  // Minimum severity threshold (0-10)
  String selectedExportOption = 'PDF';  // Selected export format

  final List<String> dateRangeOptions = [
    'Last week',
    'Last month',
    'Last 3 months',
    'Custom'
  ];

  final List<String> exportOptions = ['PDF', 'CSV', 'Share with doctor'];

  final List<InsightData> mockInsights = [
    InsightData(
      title: 'Weather Impact Pattern',
      description: 'High humidity days (>70%) correlate with 65% increase in flare-ups',
      category: 'Weather trends',
      actionableChange: 'Consider using a dehumidifier when humidity exceeds 70%',
      severity: 7,
    ),
    InsightData(
      title: 'Care Routine Effectiveness',
      description: 'Moisturizer application within 3 minutes of showering reduces symptoms by 40%',
      category: 'Care routine effectiveness',
      actionableChange: 'Apply moisturizer immediately after bathing for optimal results',
      severity: 4,
    ),
    InsightData(
      title: 'Symptom Correlation',
      description: 'Sleep quality below 6/10 precedes flare-ups by 2-3 days in 80% of cases',
      category: 'Symptom correlations',
      actionableChange: 'Focus on improving sleep hygiene during stressful periods',
      severity: 8,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      _buildFiltersSection(),
                      const SizedBox(height: 24),
                      _buildInsightsList(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.white.withValues(alpha: 0.9),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primaryBlue.withValues(alpha: 0.1),
                    blurRadius: 10,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: const Icon(
                Icons.arrow_back,
                color: AppColors.primaryBlue,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              'Insights',
              style: AppTextStyles.headingQuicksand.copyWith(fontSize: 24),
            ),
          ),
          _buildExportButton(),
        ],
      ),
    );
  }

  Widget _buildExportButton() {
    return PopupMenuButton<String>(
      icon: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: AppColors.primaryBlue,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: AppColors.primaryBlue.withValues(alpha: 0.3),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: const Icon(
          Icons.share,
          color: AppColors.white,
          size: 20,
        ),
      ),
      onSelected: (String value) {
        setState(() {
          selectedExportOption = value;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Exporting as $value')),
        );
      },
      itemBuilder: (BuildContext context) => exportOptions.map((option) {
        return PopupMenuItem<String>(
          value: option,
          child: Row(
            children: [
              Icon(
                option == 'PDF'
                    ? Icons.picture_as_pdf
                    : option == 'CSV'
                        ? Icons.table_chart
                        : Icons.medical_services,
                color: AppColors.primaryBlue,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                option,
                style: GoogleFonts.openSans(
                  color: AppColors.darkBlue,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildFiltersSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryBlue.withValues(alpha: 0.1),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Filters',
            style: GoogleFonts.quicksand(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
            ),
          ),
          const SizedBox(height: 20),
          _buildDateRangeFilter(),
          const SizedBox(height: 20),
          _buildInsightCategoriesFilter(),
          const SizedBox(height: 20),
          _buildSeverityFilter(),
        ],
      ),
    );
  }

  Widget _buildDateRangeFilter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Date Range',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 8),
        CustomDropdown<String>(
          value: selectedDateRange,
          items: dateRangeOptions,
          itemLabel: (item) => item,
          onChanged: (value) {
            if (value != null) {
              setState(() {
                selectedDateRange = value;
              });
            }
          },
          hintText: 'Select date range',
        ),
      ],
    );
  }

  Widget _buildInsightCategoriesFilter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Insight Categories',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 12),
        ...insightCategories.entries.map((entry) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(
              children: [
                Switch(
                  value: entry.value,
                  onChanged: (value) {
                    setState(() {
                      insightCategories[entry.key] = value;
                    });
                  },
                  activeColor: AppColors.primaryBlue,
                  inactiveThumbColor: AppColors.greyText,
                  inactiveTrackColor: AppColors.lightGrey,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    entry.key,
                    style: GoogleFonts.openSans(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: entry.value ? AppColors.darkBlue : AppColors.greyText,
                    ),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ],
    );
  }

  Widget _buildSeverityFilter() {
    return CustomSlider(
      title: 'Severity Filter',
      value: severityFilter,
      min: 0,
      max: 10,
      divisions: 10,
      onChanged: (value) {
        setState(() {
          severityFilter = value;
        });
      },
      leftLabel: 'Mild',
      rightLabel: 'Severe',
      sliderType: CustomSliderType.severity,
      showValueDisplay: false,
    );
  }

  Widget _buildInsightsList() {
    final filteredInsights = mockInsights.where((insight) {
      final categoryEnabled = insightCategories[insight.category] ?? false;
      final severityMatch = insight.severity >= severityFilter;
      return categoryEnabled && severityMatch;
    }).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Your Insights',
              style: GoogleFonts.quicksand(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppColors.darkBlue,
              ),
            ),
            Text(
              '${filteredInsights.length} insights',
              style: GoogleFonts.openSans(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: AppColors.greyText,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        if (filteredInsights.isEmpty)
          _buildEmptyState()
        else
          ...filteredInsights.map((insight) => _buildInsightCard(insight)),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: AppColors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppColors.lightGrey,
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Icon(
            Icons.insights,
            size: 64,
            color: AppColors.greyText.withValues(alpha: 0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'No insights found',
            style: GoogleFonts.quicksand(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: AppColors.greyText,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Adjust your filters or check back later for new insights',
            textAlign: TextAlign.center,
            style: GoogleFonts.openSans(
              fontSize: 14,
              color: AppColors.greyText,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInsightCard(InsightData insight) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryBlue.withValues(alpha: 0.1),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      insight.title,
                      style: GoogleFonts.quicksand(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: AppColors.darkBlue,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      insight.category,
                      style: GoogleFonts.openSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: AppColors.primaryBlue,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _getSeverityColor(insight.severity),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _getSeverityLabel(insight.severity),
                  style: GoogleFonts.openSans(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: AppColors.white,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            insight.description,
            style: GoogleFonts.openSans(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: AppColors.darkBlue,
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.lightGrey,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.lightbulb_outline,
                      size: 16,
                      color: AppColors.primaryBlue,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Actionable Change',
                      style: GoogleFonts.openSans(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: AppColors.primaryBlue,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  insight.actionableChange,
                  style: GoogleFonts.openSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: AppColors.darkBlue,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _buildFeedbackButtons(),
        ],
      ),
    );
  }

  Widget _buildFeedbackButtons() {
    return Row(
      children: [
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Marked as helpful!')),
              );
            },
            icon: const Icon(Icons.thumb_up, size: 16),
            label: const Text('Helpful'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryBlue,
              foregroundColor: AppColors.white,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Marked as not relevant')),
              );
            },
            icon: const Icon(Icons.thumb_down, size: 16),
            label: const Text('Not Relevant'),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.greyText,
              side: BorderSide(color: AppColors.greyText, width: 1),
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Color _getSeverityColor(int severity) {
    if (severity <= 3) {
      return const Color(0xFF4CAF50);
    } else if (severity <= 7) {
      return AppColors.primaryBlue;
    } else {
      return const Color(0xFFFF5252);
    }
  }

  String _getSeverityLabel(int severity) {
    if (severity <= 3) {
      return 'Mild';
    } else if (severity <= 7) {
      return 'Moderate';
    } else {
      return 'Severe';
    }
  }
}

class InsightData {
  final String title;
  final String description;
  final String category;
  final String actionableChange;
  final int severity;

  InsightData({
    required this.title,
    required this.description,
    required this.category,
    required this.actionableChange,
    required this.severity,
  });
}