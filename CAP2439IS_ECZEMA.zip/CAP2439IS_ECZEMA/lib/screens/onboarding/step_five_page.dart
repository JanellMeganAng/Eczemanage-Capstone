import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';

/**
 * StepFiveWidget - Management goals selection (Step 5 of onboarding)
 *
 * This widget allows users to set their eczema management goals by selecting
 * from predefined goals or creating custom goals. Users can select multiple
 * goals that align with their treatment objectives.
 *
 * Key Features:
 * - Predefined goal options for common eczema management objectives
 * - Custom goal creation with text input
 * - Multiple goal selection support
 * - Visual distinction between preset and custom goals
 * - Ability to remove selected goals
 * - Back and Next navigation buttons
 *
 * User Interactions:
 * - Tap preset goals to select/deselect them
 * - Add custom goals through dropdown menu
 * - Enter custom goal text in input field
 * - Remove custom goals individually
 * - Navigate back to previous step or forward to next step
 *
 * Data Flow:
 * - Reads: userGoals (List of String) - currently selected goals
 * - Writes: onGoalsChanged callback with updated goals list
 * - Validates: At least one goal must be selected to proceed
 *
 * Navigation:
 * - Back: Returns to Step 4 (trigger identification)
 * - Next: Proceeds to Step 6 (account creation) if at least one goal is selected
 */
class StepFiveWidget extends StatefulWidget {
  final VoidCallback onNext;
  final VoidCallback onPrevious;
  final List<String> userGoals;
  final ValueChanged<List<String>> onGoalsChanged;

  const StepFiveWidget({
    super.key,
    required this.onNext,
    required this.onPrevious,
    required this.userGoals,
    required this.onGoalsChanged,
  });

  @override
  State<StepFiveWidget> createState() => _StepFiveWidgetState();
}

class _StepFiveWidgetState extends State<StepFiveWidget> {
  Set<String> selectedPresetGoals = <String>{};
  bool isDropdownOpen = false;

  final List<String> presetGoals = [
    'Reduce Itchiness (pruritus)',
    'Reduce Redness/inflammation',
    'Reduce Dryness ',
    'Reduce Flare-up frequency/severity ',
    'Improve Sleep quality',
  ];

  void _toggleGoalSelection(String goal) {
    setState(() {
      if (selectedPresetGoals.contains(goal)) {
        selectedPresetGoals.remove(goal);
      } else {
        selectedPresetGoals.add(goal);
      }
    });
  }

  void _addSelectedGoals() {
    if (selectedPresetGoals.isNotEmpty) {
      List<String> newGoals = List.from(widget.userGoals);
      for (String goal in selectedPresetGoals) {
        if (!newGoals.contains(goal)) {
          newGoals.add(goal);
        }
      }
      widget.onGoalsChanged(newGoals);
      setState(() {
        selectedPresetGoals.clear();
      });
    }
  }

  void _removeGoal(int index) {
    List<String> newGoals = List.from(widget.userGoals);
    newGoals.removeAt(index);
    widget.onGoalsChanged(newGoals);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(33, 24, 32, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(),
          const SizedBox(height: 16),
          _buildQuestionText(),
          const SizedBox(height: 24),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  _buildGoalInput(),
                  const SizedBox(height: 20),
                  _buildGoalsList(),
                  const SizedBox(height: 20),
                  _buildNavigationButtons(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader() {
    return Text(
      'Personal Information:',
      style: GoogleFonts.quicksand(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: AppColors.darkBlue,
        height: 1.3,
      ),
    );
  }

  Widget _buildQuestionText() {
    return Text(
      'Goals. What are your main goals for managing your eczema?',
      style: GoogleFonts.openSans(
        fontSize: 16,
        fontWeight: FontWeight.w400,
        color: AppColors.darkBlue,
        height: 1.4,
      ),
    );
  }

  Widget _buildGoalInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Toggle button for multi-select
        GestureDetector(
          onTap: () {
            setState(() {
              isDropdownOpen = !isDropdownOpen;
            });
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: AppColors.lightGrey,
              borderRadius: BorderRadius.circular(12),
              border: isDropdownOpen
                ? Border.all(color: AppColors.primaryBlue, width: 2)
                : null,
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    selectedPresetGoals.isEmpty
                      ? 'Select goals...'
                      : '${selectedPresetGoals.length} goal${selectedPresetGoals.length == 1 ? '' : 's'} selected',
                    style: GoogleFonts.openSans(
                      fontSize: 16,
                      color: selectedPresetGoals.isEmpty
                        ? AppColors.greyText
                        : AppColors.darkBlue,
                      fontWeight: selectedPresetGoals.isEmpty
                        ? FontWeight.normal
                        : FontWeight.w500,
                    ),
                  ),
                ),
                Icon(
                  isDropdownOpen ? Icons.expand_less : Icons.expand_more,
                  color: AppColors.primaryBlue,
                ),
              ],
            ),
          ),
        ),

        // Multi-select dropdown content
        if (isDropdownOpen) ...[
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.lightGrey),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              children: [
                // Available goals list
                ...presetGoals.where((goal) => !widget.userGoals.contains(goal)).map((goal) {
                  final isSelected = selectedPresetGoals.contains(goal);
                  return InkWell(
                    onTap: () => _toggleGoalSelection(goal),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: isSelected ? AppColors.primaryBlue.withValues(alpha: 0.1) : Colors.transparent,
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 20,
                            height: 20,
                            decoration: BoxDecoration(
                              color: isSelected ? AppColors.primaryBlue : Colors.transparent,
                              border: Border.all(
                                color: AppColors.primaryBlue,
                                width: 2,
                              ),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: isSelected
                              ? const Icon(
                                  Icons.check,
                                  size: 14,
                                  color: Colors.white,
                                )
                              : null,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              goal,
                              style: GoogleFonts.openSans(
                                fontSize: 14,
                                color: AppColors.darkBlue,
                                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),

                // Add button
                if (selectedPresetGoals.isNotEmpty) ...[
                  const Divider(height: 1),
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _addSelectedGoals,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primaryBlue,
                          foregroundColor: AppColors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        child: Text(
                          'Add ${selectedPresetGoals.length} Goal${selectedPresetGoals.length == 1 ? '' : 's'}',
                          style: GoogleFonts.openSans(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildGoalsList() {
    if (widget.userGoals.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppColors.lightGrey,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Text(
            'No goals added yet. Add your first goal above!',
            style: GoogleFonts.openSans(
              fontSize: 14,
              color: AppColors.greyText,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.lightGrey),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Icon(
                  Icons.flag,
                  color: AppColors.primaryBlue,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Text(
                  'Your Goals (${widget.userGoals.length})',
                  style: GoogleFonts.quicksand(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: AppColors.darkBlue,
                  ),
                ),
              ],
            ),
          ),
          ...widget.userGoals.asMap().entries.map((entry) {
            final index = entry.key;
            final goal = entry.value;
            return Container(
              margin: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 4,
              ),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.lightGrey,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      goal,
                      style: GoogleFonts.openSans(
                        fontSize: 14,
                        color: AppColors.darkBlue,
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () => _removeGoal(index),
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Colors.red.shade50,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Icon(
                        Icons.delete_outline,
                        size: 16,
                        color: Colors.red.shade600,
                      ),
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildNavigationButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          width: 120,
          height: 52,
          child: ElevatedButton(
            onPressed: widget.onPrevious,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.lightGrey,
              foregroundColor: AppColors.primaryBlue,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(26),
              ),
              elevation: 0,
              shadowColor: Colors.transparent,
            ),
            child: Text(
              'Back',
              style: GoogleFonts.openSans(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.4,
              ),
            ),
          ),
        ),
        SizedBox(
          width: 120,
          height: 52,
          child: ElevatedButton(
            onPressed: widget.userGoals.isNotEmpty ? widget.onNext : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryBlue,
              foregroundColor: AppColors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(26),
              ),
              elevation: 2,
              shadowColor: AppColors.primaryBlue.withValues(alpha: 0.3),
              disabledBackgroundColor: AppColors.lightGrey,
              disabledForegroundColor: AppColors.greyText,
            ),
            child: Text(
              'Next',
              style: GoogleFonts.openSans(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.4,
              ),
            ),
          ),
        ),
      ],
    );
  }
}