import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../core/constants/app_colors.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_services.dart';
import '../../models/user_model.dart';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import '../../models/onboarding_data_model.dart';
import 'step_one_page.dart';
import 'step_two_page.dart';
import 'step_three_page.dart';
import 'step_four_page.dart';
import 'step_five_page.dart';
import 'step_six_page.dart';
import '../dashboard/dashboard_screen.dart';

/// OnboardingFlow - Multi-step registration and profile setup wizard
///
/// This screen manages the complete user onboarding process, guiding new users
/// through account creation and eczema profile setup in a series of 6 steps.
/// Uses PageView for smooth horizontal transitions and maintains shared state
/// across all onboarding steps.
///
/// Onboarding Steps:
/// 1. StepOne: Eczema history selection (diagnosed/suspected/family member)
/// 2. StepTwo: Severity assessment with visual slider (0-10 scale)
/// 3. StepThree: Body area selection using interactive map
/// 4. StepFour: Common trigger identification
/// 5. StepFive: Goal setting for eczema management
/// 6. StepSix: Account creation (email, password, personal details)
///
/// Key Features:
/// - 6-step wizard with progress indicator (animated dots)
/// - Smooth page transitions with PageView and animations
/// - Shared state management across all steps
/// - Forward/backward navigation with validation
/// - Asymmetric card design with branded gradient background
/// - Data persistence on completion
/// - Firebase Auth integration with fallback to mock user
/// - Timeout protection for network operations
///
/// User Interactions:
/// - Navigate forward through steps (Next button)
/// - Navigate backward to previous steps (Back button)
/// - Complete onboarding and create account (final step)
/// - Input data specific to each step
/// - View progress through visual indicator
///
/// Data Flow:
/// - Collects: User profile information across 6 steps
/// - Validates: All required fields before allowing progression
/// - Writes: User account to Firebase Auth
/// - Writes: User profile to Firestore
/// - Writes: Onboarding answers to Firestore
/// - Writes: Test credentials to Firestore (development only)
/// - Navigates: To DashboardScreen on successful completion
///
/// State Management:
/// - Maintains step index for navigation and progress
/// - Stores collected data in state variables
/// - Passes callbacks to child widgets for state updates
/// - Uses AnimationController for progress transitions
///
/// Error Handling:
/// - Network timeout protection (5 seconds)
/// - Fallback to mock user if Firebase Auth fails
/// - Background data save to prevent UI blocking
/// - Validation error messages via SnackBar
///
/// Technical Details:
/// - Uses TickerProviderStateMixin for animations
/// - PageView with NeverScrollableScrollPhysics (button-controlled navigation)
/// - Asynchronous data saving with microtask for non-blocking operations
/// - Firebase Auth and Firestore integration
class OnboardingFlow extends StatefulWidget {
  const OnboardingFlow({super.key});

  @override
  State<OnboardingFlow> createState() => _OnboardingFlowState();
}

class _OnboardingFlowState extends State<OnboardingFlow>
    with TickerProviderStateMixin {
  // Navigation and animation controllers
  late PageController _pageController; // Controls PageView navigation
  int _currentStep = 0; // Current step index (0-5)
  late AnimationController
  _progressAnimationController; // Progress dot animation
  late Animation<double> _progressAnimation; // Progress animation curve

  // Service instances for backend operations
  final AuthService _authService = AuthService();
  final FirestoreService _firestoreService = FirestoreService();

  // Shared state collected across all onboarding steps
  String? selectedEczemaOption; // Step 1: Eczema relationship
  double severitySliderValue = 5.0; // Step 2: Severity rating
  Set<String> selectedAreas = <String>{}; // Step 3: Affected body areas
  Set<String> selectedTriggers = <String>{}; // Step 4: Known triggers
  List<String> userGoals = <String>[]; // Step 5: Management goals
  Map<String, String> userInfo = {}; // Step 6: Account credentials and details

  // UI state for preventing duplicate submissions
  bool _isCompleting = false;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _progressAnimationController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _progressAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _progressAnimationController,
        curve: Curves.easeInOut,
      ),
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    _progressAnimationController.dispose();
    super.dispose();
  }

  /// Navigate to the next onboarding step with animation
  ///
  /// Increments step counter, animates progress indicator, and slides to next page.
  /// Maximum step is 5 (index 5 = step 6, the final step).
  void _nextStep() {
    if (_currentStep < 5) {
      setState(() {
        _currentStep++;
      });
      _progressAnimationController.forward();
      _pageController.nextPage(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOut,
      );
    }
  }

  /// Navigate to the previous onboarding step with animation
  ///
  /// Decrements step counter, reverses progress animation, and slides to previous page.
  /// Minimum step is 0 (first step).
  void _previousStep() {
    if (_currentStep > 0) {
      setState(() {
        _currentStep--;
      });
      _progressAnimationController.reverse();
      _pageController.previousPage(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOut,
      );
    }
  }

  /// Complete onboarding by registering user and saving all collected data
  ///
  /// This method handles the final step of onboarding:
  /// 1. Validates all required fields are collected
  /// 2. Attempts Firebase Auth registration with timeout
  /// 3. Falls back to mock user if auth fails
  /// 4. Saves user profile and onboarding data in background
  /// 5. Navigates to dashboard immediately (non-blocking)
  ///
  /// Error Handling:
  /// - Prevents duplicate submissions with _isCompleting flag
  /// - Validates all required fields before proceeding
  /// - Uses 5-second timeout for auth operations
  /// - Creates fallback user if Firebase is unavailable
  /// - Saves data asynchronously to avoid UI blocking
  Future<void> _completeOnboarding() async {
    // Prevent duplicate submissions
    if (_isCompleting) return;

    setState(() {
      _isCompleting = true;
    });

    try {
      // Validate all required data has been collected across steps
      if (userInfo['email'] == null ||
          userInfo['password'] == null ||
          userInfo['firstName'] == null ||
          userInfo['lastName'] == null ||
          userInfo['gender'] == null ||
          selectedEczemaOption == null) {
        _showErrorSnackBar('Please complete all required fields');
        setState(() {
          _isCompleting = false;
        });
        return;
      }

      // Generate unique user ID for development (since Firebase Auth may fail)
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final userId = 'user_$timestamp';

      // Hash the password before saving
      final plainPassword = userInfo['password']!;
      final hashedPassword = sha256
          .convert(utf8.encode(plainPassword))
          .toString();

      // Create user model with hashed password
      final userModel = UserModel(
        id: userId,
        email: userInfo['email']!,
        passwordHash: hashedPassword,
        firstName: userInfo['firstName']!,
        lastName: userInfo['lastName']!,
        birthdate: DateTime.now().subtract(
          const Duration(days: 365 * 25),
        ), // Default age
        gender: userInfo['gender']!,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      String finalUserId = userId;
      bool authSuccess = false;

      try {
        // Try Firebase Auth registration with timeout
        final user = await _authService
            .registerWithEmailAndPassword(userModel)
            .timeout(const Duration(seconds: 5), onTimeout: () => null);

        if (user != null) {
          finalUserId = user.uid;
          authSuccess = true;

          // Save data asynchronously in background (don't await)
          _saveUserDataInBackground(user.uid, userModel);
          debugPrint('Firebase Auth successful for user: ${user.uid}');
        }
      } catch (e) {
        debugPrint('Firebase Auth failed, using fallback: $e');
      }

      if (!authSuccess) {
        // Fallback: Create mock user immediately, save data in background
        final fullName = '${userInfo['firstName']} ${userInfo['lastName']}';
        final mockUser = DynamicMockUser(userId, userInfo['email']!, fullName);
        _authService.setMockUser(mockUser);
        debugPrint(
          'Mock user created: $userId, ${userInfo['email']}, $fullName',
        );

        // Save data in background (don't block navigation)
        _saveUserDataInBackground(userId, userModel);
      }

      // Navigate to dashboard immediately without waiting for Firestore
      if (mounted) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => const DashboardScreen()),
          (route) => false,
        );
      }
    } catch (e) {
      if (mounted) {
        _showErrorSnackBar('Registration failed: ${e.toString()}');
      }
    } finally {
      if (mounted) {
        setState(() {
          _isCompleting = false;
        });
      }
    }
  }

  /// Save user data in background without blocking UI navigation
  ///
  /// This method runs asynchronously after navigation to dashboard,
  /// preventing slow network operations from blocking the user experience.
  ///
  /// Saves three types of data:
  /// 1. User profile to Firestore users collection
  /// 2. Test credentials (development only, not for production)
  /// 3. Onboarding answers to onboardingData collection
  ///
  /// Uses Future.microtask to ensure non-blocking execution.
  /// Errors are logged but don't interrupt the user flow.
  void _saveUserDataInBackground(String userId, UserModel userModel) {
    // Run in background using microtask (non-blocking)
    Future.microtask(() async {
      try {
        // Create updated user model with final userId
        final updatedUserModel = UserModel(
          id: userId,
          email: userModel.email,
          passwordHash: userModel.passwordHash,
          firstName: userModel.firstName,
          lastName: userModel.lastName,
          birthdate: userModel.birthdate,
          gender: userModel.gender,
          createdAt: userModel.createdAt,
          updatedAt: userModel.updatedAt,
        );

        // Save all data to Firestore
        await _firestoreService.setUser(updatedUserModel);
        await _saveCredentialsForTesting(
          userInfo['email']!,
          updatedUserModel.passwordHash,
        );
        await _saveOnboardingData(userId);

        debugPrint('User data saved successfully in background');
      } catch (e) {
        debugPrint('Error saving user data in background: $e');
        // Errors are logged but don't interrupt user flow
      }
    });
  }

  /// Save onboarding questionnaire data to Firestore
  ///
  /// Converts all collected onboarding answers into OnboardingData model
  /// and persists to Firestore for future reference and analytics.
  ///
  /// Stored data includes:
  /// - Eczema severity category (from slider value)
  /// - Selected affected body areas
  /// - User's management goals
  /// - Identified trigger preferences
  /// - Timestamp of completion
  Future<void> _saveOnboardingData(String userId) async {
    final onboardingData = OnboardingData(
      id: '${userId}_onboarding',
      userId: userId,
      eczemaSeverity: _getSeverityFromSlider(severitySliderValue),
      affectedAreas: selectedAreas.toList(),
      goals: userGoals,
      preferredTriggers: selectedTriggers.toList(),
      answeredAt: DateTime.now(),
      diagnosedAt:
          selectedEczemaOption ?? 'Not diagnosed yet', // Ensure non-null String
    );

    await _firestoreService.setOnboardingData(onboardingData);
  }

  /// Save credentials for testing (development only)
  Future<void> _saveCredentialsForTesting(String email, String password) async {
    // Create a simple collection to store test credentials
    // This is for development only - never do this in production!
    await FirebaseFirestore.instance
        .collection('testCredentials')
        .doc(email)
        .set({
          'email': email,
          'passwordHash': password, // This is now the hashed password
          'createdAt': DateTime.now().toIso8601String(),
        });
  }

  /// Convert numerical slider value (0-10) to severity category
  ///
  /// Maps the severity slider value to clinical severity categories:
  /// - 0-3: Mild
  /// - 4-7: Moderate
  /// - 8-10: Severe
  String _getSeverityFromSlider(double value) {
    if (value <= 3) return 'Mild';
    if (value <= 7) return 'Moderate';
    return 'Severe';
  }

  /// Show error message
  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red.shade400,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  /// Show success message
  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green.shade400,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(color: AppColors.primaryBlue),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 40),
              _buildPageTitle(),
              const SizedBox(height: 40),
              Expanded(
                child: Stack(
                  children: [
                    Positioned(
                      top: 0,
                      bottom: 0,
                      right: 0,
                      width: MediaQuery.of(context).size.width * 0.93,
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 40),
                        decoration: BoxDecoration(
                          color: AppColors.white,
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(32),
                            bottomLeft: Radius.circular(32),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.08),
                              blurRadius: 24,
                              offset: const Offset(-4, 8),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            _buildProgressIndicator(),
                            Expanded(
                              child: PageView(
                                controller: _pageController,
                                physics: const NeverScrollableScrollPhysics(),
                                children: [
                                  StepOneWidget(
                                    onNext: _nextStep,
                                    onBack: () {
                                      Navigator.pop(context);
                                    },
                                    selectedOption: selectedEczemaOption,
                                    onOptionChanged: (option) {
                                      setState(() {
                                        selectedEczemaOption = option;
                                      });
                                    },
                                  ),
                                  StepTwoWidget(
                                    onNext: _nextStep,
                                    onPrevious: _previousStep,
                                    sliderValue: severitySliderValue,
                                    onSliderChanged: (value) {
                                      setState(() {
                                        severitySliderValue = value;
                                      });
                                    },
                                  ),
                                  StepThreeWidget(
                                    onNext: _nextStep,
                                    onPrevious: _previousStep,
                                    selectedAreas: selectedAreas,
                                    onAreasChanged: (areas) {
                                      setState(() {
                                        selectedAreas = areas;
                                      });
                                    },
                                  ),
                                  StepFourWidget(
                                    onNext: _nextStep,
                                    onPrevious: _previousStep,
                                    selectedTriggers: selectedTriggers,
                                    onTriggersChanged: (triggers) {
                                      setState(() {
                                        selectedTriggers = triggers;
                                      });
                                    },
                                  ),
                                  StepFiveWidget(
                                    onNext: _nextStep,
                                    onPrevious: _previousStep,
                                    userGoals: userGoals,
                                    onGoalsChanged: (goals) {
                                      setState(() {
                                        userGoals = goals;
                                      });
                                    },
                                  ),
                                  StepSixWidget(
                                    onPrevious: _previousStep,
                                    onComplete: _completeOnboarding,
                                    userInfo: userInfo,
                                    onUserInfoChanged: (info) {
                                      setState(() {
                                        userInfo = info;
                                      });
                                    },
                                    isLoading: _isCompleting,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPageTitle() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24.0),
      child: SizedBox(
        width: double.infinity,
        child: Text(
          'Sign-Up',
          style: GoogleFonts.quicksand(
            fontSize: 35,
            fontWeight: FontWeight.bold,
            color: AppColors.white,
            height: 1.2,
          ),
        ),
      ),
    );
  }

  Widget _buildProgressIndicator() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 24.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(6, (index) {
          return AnimatedContainer(
            duration: const Duration(milliseconds: 400),
            curve: Curves.easeInOut,
            width: 12,
            height: 12,
            margin: const EdgeInsets.symmetric(horizontal: 4),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: index <= _currentStep
                  ? AppColors.primaryBlue
                  : AppColors.lightGrey,
            ),
          );
        }),
      ),
    );
  }
}
