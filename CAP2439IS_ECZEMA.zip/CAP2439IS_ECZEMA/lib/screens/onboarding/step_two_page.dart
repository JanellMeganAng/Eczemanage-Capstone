import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../core/widgets/custom_slider.dart';

/// StepTwoWidget - Eczema severity assessment (Step 2 of onboarding)
///
/// This widget allows users to rate their current eczema severity using a
/// visual slider interface. The severity is rated on a scale from 1 to 10,
/// where 1 represents mild and 10 represents severe.
///
/// Key Features:
/// - Interactive slider with visual feedback
/// - Scale from 1 (Mild) to 10 (Severe)
/// - Custom slider component with value display
/// - Back and Next navigation buttons
///
/// User Interactions:
/// - Drag slider to adjust severity rating
/// - View current severity value in real-time
/// - Navigate back to Step 1 or forward to Step 3
///
/// Data Flow:
/// - Reads: sliderValue (double) - current severity rating (1-10)
/// - Writes: onSliderChanged callback with updated severity value
/// - No validation required (default value of 5.0 always valid)
///
/// Navigation:
/// - Back: Returns to Step 1 (diagnosis timeline)
/// - Next: Proceeds to Step 3 (affected body areas)
class StepTwoWidget extends StatefulWidget {
  final VoidCallback onNext;
  final VoidCallback onPrevious;
  final double sliderValue;
  final ValueChanged<double> onSliderChanged;

  const StepTwoWidget({
    super.key,
    required this.onNext,
    required this.onPrevious,
    required this.sliderValue,
    required this.onSliderChanged,
  });

  @override
  State<StepTwoWidget> createState() => _StepTwoWidgetState();
}

class _StepTwoWidgetState extends State<StepTwoWidget> {

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(40, 24, 32, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(),
          const SizedBox(height: 16),
          _buildQuestionText(),
          const SizedBox(height: 32),
          Expanded(
            child: Column(
              children: [
                _buildSliderSection(),
                const SizedBox(height: 40),
                _buildNavigationButtons(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader() {
    return Text(
      'Personal Information:',
      style: GoogleFonts.quicksand(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: AppColors.darkBlue,
        height: 1.3,
      ),
    );
  }

  Widget _buildQuestionText() {
    return Text(
      'Current severity. How would you rate your eczema severity today?',
      style: GoogleFonts.openSans(
        fontSize: 16,
        fontWeight: FontWeight.w400,
        color: AppColors.darkBlue,
        height: 1.4,
      ),
    );
  }

  Widget _buildSliderSection() {
    return CustomSlider(
      value: widget.sliderValue,
      min: 1.0,
      max: 10.0,
      divisions: 9,
      leftLabel: 'Mild',
      rightLabel: 'Severe',
      sliderType: CustomSliderType.severity,
      showValueDisplay: true,
      onChanged: widget.onSliderChanged,
    );
  }

  Widget _buildNavigationButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _buildBackButton(),
        _buildNextButton(),
      ],
    );
  }

  Widget _buildBackButton() {
    return SizedBox(
      width: 120,
      height: 52,
      child: ElevatedButton(
        onPressed: widget.onPrevious,
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.lightGrey,
          foregroundColor: AppColors.primaryBlue,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(26),
          ),
          elevation: 0,
          shadowColor: Colors.transparent,
        ),
        child: Text(
          'Back',
          style: GoogleFonts.openSans(
            fontSize: 15,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.4,
          ),
        ),
      ),
    );
  }

  Widget _buildNextButton() {
    return SizedBox(
      width: 120,
      height: 52,
      child: ElevatedButton(
        onPressed: widget.onNext,
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryBlue,
          foregroundColor: AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(26),
          ),
          elevation: 2,
          shadowColor: AppColors.primaryBlue.withValues(alpha: 0.3),
        ),
        child: Text(
          'Next',
          style: GoogleFonts.openSans(
            fontSize: 15,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.4,
          ),
        ),
      ),
    );
  }
}