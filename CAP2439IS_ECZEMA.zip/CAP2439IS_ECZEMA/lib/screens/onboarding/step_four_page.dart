import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';

/// StepFourWidget - Common triggers selection screen (Step 4 of onboarding)
///
/// This widget allows users to identify common triggers that cause their eczema
/// flare-ups. Triggers are organized into four predefined categories for easy
/// selection and browsing.
///
/// Key Features:
/// - Four predefined trigger categories: Environmental, Food & Diet, Personal Care, Lifestyle & Health
/// - Expandable/collapsible category sections for better organization
/// - Search functionality to quickly find specific triggers
/// - Selected triggers preview with expandable detail view
/// - Multiple trigger selection support
/// - Progress counter showing selected vs total triggers per category
///
/// User Interactions:
/// - Tap categories to expand/collapse trigger lists
/// - Tap individual triggers to select/deselect them
/// - Use search bar to filter triggers across all categories
/// - View selected triggers in collapsible header section
/// - Remove selected triggers by tapping in expanded selected section
/// - Navigate back to previous step or forward to next step
///
/// Data Flow:
/// - Reads: selectedTriggers (Set of String) - currently selected triggers
/// - Writes: onTriggersChanged callback with updated trigger selection
/// - Validates: At least one trigger must be selected to proceed
///
/// Navigation:
/// - Back: Returns to Step 3 (body area selection)
/// - Next: Proceeds to Step 5 (goal setting) if at least one trigger is selected
class StepFourWidget extends StatefulWidget {
  final VoidCallback onNext;
  final VoidCallback onPrevious;
  final Set<String> selectedTriggers;
  final ValueChanged<Set<String>> onTriggersChanged;

  const StepFourWidget({
    super.key,
    required this.onNext,
    required this.onPrevious,
    required this.selectedTriggers,
    required this.onTriggersChanged,
  });

  @override
  State<StepFourWidget> createState() => _StepFourWidgetState();
}

class _StepFourWidgetState extends State<StepFourWidget> {
  final TextEditingController searchController = TextEditingController();
  final Map<String, bool> expandedCategories = {};
  bool isSearching = false;
  bool isSelectedTriggersExpanded = false;
  List<String> searchResults = [];

  final Map<String, List<String>> triggerCategories = {
    'Environmental': [
      'Dust mites',
      'Pollen',
      'Pet dander',
      'Mold',
      'Cigarette smoke',
      'Air pollution',
      'Weather changes',
      'Humidity',
      'Cold air',
      'Heat',
    ],
    'Food & Diet': [
      'Dairy products',
      'Eggs',
      'Nuts',
      'Soy',
      'Wheat/Gluten',
      'Citrus fruits',
      'Spicy foods',
      'Food additives',
      'Caffeine',
      'Alcohol',
    ],
    'Personal Care': [
      'Fragrances',
      'Harsh soaps',
      'Detergents',
      'Fabric softeners',
      'Shampoos',
      'Cosmetics',
      'Perfumes',
      'Cleaning products',
      'Wool clothing',
      'Synthetic fabrics',
    ],
    'Lifestyle & Health': [
      'Stress',
      'Lack of sleep',
      'Hormonal changes',
      'Infections',
      'Sweating',
      'Hot showers',
      'Scratching',
      'Certain medications',
      'Exercise',
      'Fatigue',
    ],
  };

  List<String> get allTriggers {
    return triggerCategories.values.expand((triggers) => triggers).toList();
  }

  @override
  void initState() {
    super.initState();
    // Initialize all categories as collapsed
    for (String category in triggerCategories.keys) {
      expandedCategories[category] = false;
    }
    searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    setState(() {
      if (searchController.text.isEmpty) {
        isSearching = false;
        searchResults = [];
      } else {
        isSearching = true;
        searchResults = allTriggers
            .where(
              (trigger) => trigger.toLowerCase().contains(
                searchController.text.toLowerCase(),
              ),
            )
            .toList();
      }
    });
  }

  void _updateSelectedTriggers(String trigger) {
    Set<String> newSelectedTriggers = Set.from(widget.selectedTriggers);
    if (newSelectedTriggers.contains(trigger)) {
      newSelectedTriggers.remove(trigger);
    } else {
      newSelectedTriggers.add(trigger);
    }
    widget.onTriggersChanged(newSelectedTriggers);
  }


  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(33, 24, 32, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(),
          const SizedBox(height: 16),
          _buildQuestionText(),
          const SizedBox(height: 24),
          Expanded(
            child: Column(
              children: [
                Expanded(child: _buildTriggersSection()),
                const SizedBox(height: 20),
                _buildNavigationButtons(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader() {
    return Text(
      'Personal Information:',
      style: GoogleFonts.quicksand(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: AppColors.darkBlue,
        height: 1.3,
      ),
    );
  }

  Widget _buildQuestionText() {
    return Text(
      'Common Triggers. What typically triggers your flare-ups?',
      style: GoogleFonts.openSans(
        fontSize: 16,
        fontWeight: FontWeight.w400,
        color: AppColors.darkBlue,
        height: 1.4,
      ),
    );
  }

  Widget _buildTriggersSection() {
    return Column(
      children: [
        _buildSearchBar(),
        const SizedBox(height: 16),
        if (widget.selectedTriggers.isNotEmpty) ...[
          _buildSelectedTriggersHeader(),
          const SizedBox(height: 12),
        ],
        Expanded(child: _buildTriggersList()),
      ],
    );
  }

  Widget _buildSelectedTriggersHeader() {
    final selectedCount = widget.selectedTriggers.length;
    final previewTriggers = widget.selectedTriggers.take(3).toList();
    final hasMore = selectedCount > 3;

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: AppColors.primaryBlue.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppColors.primaryBlue.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          // Compact Header
          GestureDetector(
            onTap: () {
              setState(() {
                isSelectedTriggersExpanded = !isSelectedTriggersExpanded;
              });
            },
            child: Container(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.primaryBlue,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      selectedCount.toString(),
                      style: GoogleFonts.openSans(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Selected Triggers',
                          style: GoogleFonts.openSans(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: AppColors.darkBlue,
                          ),
                        ),
                        if (!isSelectedTriggersExpanded &&
                            selectedCount > 0) ...[
                          const SizedBox(height: 4),
                          Text(
                            hasMore
                                ? '${previewTriggers.join(', ')}${hasMore ? ' +${selectedCount - 3} more' : ''}'
                                : previewTriggers.join(', '),
                            style: GoogleFonts.openSans(
                              fontSize: 12,
                              color: AppColors.greyText,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(
                    isSelectedTriggersExpanded
                        ? Icons.expand_less
                        : Icons.expand_more,
                    color: AppColors.primaryBlue,
                    size: 24,
                  ),
                ],
              ),
            ),
          ),
          // Expanded Content
          if (isSelectedTriggersExpanded) ...[
            const Divider(
              color: AppColors.primaryBlue,
              height: 1,
              thickness: 0.5,
            ),
            Container(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Tap to remove:',
                    style: GoogleFonts.openSans(
                      fontSize: 12,
                      color: AppColors.greyText,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: widget.selectedTriggers
                        .map((trigger) => _buildTriggerChip(trigger))
                        .toList(),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildTriggerChip(String trigger) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.primaryBlue,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            trigger,
            style: GoogleFonts.openSans(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: AppColors.white,
            ),
          ),
          const SizedBox(width: 4),
          GestureDetector(
            onTap: () {
              _updateSelectedTriggers(trigger);
            },
            child: const Icon(Icons.close, size: 16, color: AppColors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.lightGrey,
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextField(
        controller: searchController,
        style: GoogleFonts.openSans(fontSize: 16, color: AppColors.darkBlue),
        decoration: InputDecoration(
          hintText: 'Search triggers...',
          hintStyle: GoogleFonts.openSans(
            fontSize: 16,
            color: AppColors.greyText,
          ),
          prefixIcon: const Icon(Icons.search, color: AppColors.greyText),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 14,
          ),
        ),
      ),
    );
  }

  Widget _buildTriggersList() {
    if (isSearching) {
      return _buildSearchResults();
    }

    final categories = triggerCategories.keys.toList();

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.lightGrey, width: 1),
      ),
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: categories.length,
        separatorBuilder: (context, index) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final category = categories[index];
          final triggers = triggerCategories[category]!;
          final isExpanded = expandedCategories[category] ?? false;

          return _buildCategory(category, triggers, isExpanded);
        },
      ),
    );
  }


  Widget _buildCategory(String category, List<String> triggers, bool isExpanded) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.lightGrey,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          // Category Header
          GestureDetector(
            onTap: () {
              setState(() {
                expandedCategories[category] = !isExpanded;
              });
            },
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: isExpanded
                    ? AppColors.primaryBlue.withValues(alpha: 0.1)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  _buildCategoryIcon(category),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      category,
                      style: GoogleFonts.quicksand(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.darkBlue,
                      ),
                    ),
                  ),
                  Text(
                    '${triggers.where((trigger) => widget.selectedTriggers.contains(trigger)).length}/${triggers.length}',
                    style: GoogleFonts.openSans(
                      fontSize: 12,
                      color: AppColors.greyText,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(
                    isExpanded ? Icons.expand_less : Icons.expand_more,
                    color: AppColors.primaryBlue,
                  ),
                ],
              ),
            ),
          ),
          // Category Items
          if (isExpanded) ...[
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: triggers.map((trigger) {
                  final isSelected = widget.selectedTriggers.contains(trigger);
                  return GestureDetector(
                    onTap: () {
                      _updateSelectedTriggers(trigger);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? AppColors.primaryBlue
                            : Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: AppColors.primaryBlue,
                          width: 1.5,
                        ),
                      ),
                      child: Text(
                        trigger,
                        style: GoogleFonts.openSans(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: isSelected
                              ? Colors.white
                              : AppColors.primaryBlue,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ],
      ),
    );
  }

  Widget _buildSearchResults() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.lightGrey,
        borderRadius: BorderRadius.circular(16),
      ),
      child: searchResults.isEmpty
          ? _buildNoResultsMessage()
          : Padding(
              padding: const EdgeInsets.all(16),
              child: GridView.builder(
                itemCount: searchResults.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 3.5,
                ),
                itemBuilder: (context, index) {
                  final trigger = searchResults[index];
                  final isSelected = widget.selectedTriggers.contains(trigger);

                  return GestureDetector(
                    onTap: () {
                      _updateSelectedTriggers(trigger);
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: isSelected
                            ? AppColors.primaryBlue
                            : AppColors.white,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: AppColors.primaryBlue,
                          width: 1.5,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.05),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Center(
                        child: Text(
                          trigger,
                          style: GoogleFonts.openSans(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: isSelected
                                ? AppColors.white
                                : AppColors.primaryBlue,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
    );
  }

  Widget _buildCategoryIcon(String category) {
    return Icon(
      _getCategoryIcon(category),
      color: AppColors.primaryBlue,
      size: 24,
    );
  }

  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Environmental':
        return Icons.eco;
      case 'Food & Diet':
        return Icons.restaurant;
      case 'Personal Care':
        return Icons.soap;
      case 'Lifestyle & Health':
        return Icons.favorite;
      default:
        return Icons.radio_button_unchecked;
    }
  }

  Widget _buildNoResultsMessage() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search_off,
              size: 64,
              color: AppColors.greyText.withValues(alpha: 0.5),
            ),
            const SizedBox(height: 16),
            Text(
              'No triggers found',
              style: GoogleFonts.openSans(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: AppColors.greyText,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Try a different search term',
              style: GoogleFonts.openSans(
                fontSize: 14,
                color: AppColors.greyText,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavigationButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          width: 120,
          height: 52,
          child: ElevatedButton(
            onPressed: widget.onPrevious,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.lightGrey,
              foregroundColor: AppColors.primaryBlue,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(26),
              ),
              elevation: 0,
              shadowColor: Colors.transparent,
            ),
            child: Text(
              'Back',
              style: GoogleFonts.openSans(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.4,
              ),
            ),
          ),
        ),
        SizedBox(
          width: 120,
          height: 52,
          child: ElevatedButton(
            onPressed: widget.selectedTriggers.isNotEmpty ? widget.onNext : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryBlue,
              foregroundColor: AppColors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(26),
              ),
              elevation: 2,
              shadowColor: AppColors.primaryBlue.withValues(alpha: 0.3),
              disabledBackgroundColor: AppColors.lightGrey,
              disabledForegroundColor: AppColors.greyText,
            ),
            child: Text(
              'Next',
              style: GoogleFonts.openSans(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.4,
              ),
            ),
          ),
        ),
      ],
    );
  }
}