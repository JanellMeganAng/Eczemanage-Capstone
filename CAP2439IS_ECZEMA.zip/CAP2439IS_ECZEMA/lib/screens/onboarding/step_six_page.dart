import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';

/// StepSixWidget - Account creation (Step 6 of onboarding - Final step)
///
/// This widget is the final step of the onboarding process where users create
/// their account by providing personal information and credentials. Upon
/// completion, the user account is created and they are navigated to the
/// dashboard.
///
/// Key Features:
/// - Personal information form (first name, last name, gender, birthday)
/// - Account credentials form (email, password)
/// - Birthday date picker with formatted display
/// - Gender selection dropdown (Male, Female, Other)
/// - Form validation for all required fields
/// - Loading state during account creation
/// - Password visibility toggle
///
/// User Interactions:
/// - Enter first name and last name in text fields
/// - Select birthday using date picker
/// - Select gender from dropdown menu
/// - Enter email address
/// - Enter password with visibility toggle
/// - Navigate back to previous step or complete onboarding
///
/// Data Flow:
/// - Reads: userInfo (Map of String to String) - user account information
/// - Reads: isLoading (bool) - account creation in progress state
/// - Writes: onUserInfoChanged callback with updated user information
/// - Validates: All fields must be filled to enable Complete button
///
/// Navigation:
/// - Back: Returns to Step 5 (goal selection)
/// - Complete: Creates account and navigates to Dashboard (onComplete callback)
class StepSixWidget extends StatefulWidget {
  final VoidCallback onPrevious;
  final VoidCallback onComplete;
  final Map<String, String> userInfo;
  final ValueChanged<Map<String, String>> onUserInfoChanged;
  final bool isLoading;

  const StepSixWidget({
    super.key,
    required this.onPrevious,
    required this.onComplete,
    required this.userInfo,
    required this.onUserInfoChanged,
    this.isLoading = false,
  });

  @override
  State<StepSixWidget> createState() => _StepSixWidgetState();
}

class _StepSixWidgetState extends State<StepSixWidget> {
  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  String selectedGender = '';
  DateTime? selectedBirthdate;
  bool isPasswordVisible = false;
  bool isGenderDropdownOpen = false;

  final List<String> genderOptions = ['Male', 'Female', 'Prefer not to say'];

  @override
  void initState() {
    super.initState();
    // Initialize controllers with existing data
    firstNameController.text = widget.userInfo['firstName'] ?? '';
    lastNameController.text = widget.userInfo['lastName'] ?? '';
    emailController.text = widget.userInfo['email'] ?? '';
    passwordController.text = widget.userInfo['password'] ?? '';
    selectedGender = widget.userInfo['gender'] ?? '';

    // Initialize birthdate if exists
    if (widget.userInfo['birthdate'] != null && widget.userInfo['birthdate']!.isNotEmpty) {
      selectedBirthdate = DateTime.tryParse(widget.userInfo['birthdate']!);
    }
  }

  @override
  void dispose() {
    firstNameController.dispose();
    lastNameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  bool get isFormValid {
    return firstNameController.text.trim().isNotEmpty &&
        lastNameController.text.trim().isNotEmpty &&
        selectedGender.isNotEmpty &&
        selectedBirthdate != null &&
        emailController.text.trim().isNotEmpty &&
        passwordController.text.trim().isNotEmpty;
  }

  void _updateUserInfo() {
    Map<String, String> newUserInfo = {
      'firstName': firstNameController.text.trim(),
      'lastName': lastNameController.text.trim(),
      'gender': selectedGender,
      'birthdate': selectedBirthdate?.toIso8601String() ?? '',
      'email': emailController.text.trim(),
      'password': passwordController.text.trim(),
    };
    widget.onUserInfoChanged(newUserInfo);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(33, 24, 32, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(),
          const SizedBox(height: 16),
          _buildQuestionText(),
          const SizedBox(height: 24),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  _buildUserDetailsForm(),
                  const SizedBox(height: 20),
                  _buildNavigationButtons(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader() {
    return Text(
      'Personal Information:',
      style: GoogleFonts.quicksand(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: AppColors.darkBlue,
        height: 1.3,
      ),
    );
  }

  Widget _buildQuestionText() {
    return Text(
      'Account Details. Please provide your account information.',
      style: GoogleFonts.openSans(
        fontSize: 16,
        fontWeight: FontWeight.w400,
        color: AppColors.darkBlue,
        height: 1.4,
      ),
    );
  }

  Widget _buildUserDetailsForm() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _buildTextField(
                controller: firstNameController,
                hintText: 'First Name',
                onChanged: (_) => _updateUserInfo(),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildTextField(
                controller: lastNameController,
                hintText: 'Last Name',
                onChanged: (_) => _updateUserInfo(),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        _buildGenderDropdown(),
        const SizedBox(height: 16),
        _buildBirthdateField(),
        const SizedBox(height: 16),
        _buildTextField(
          controller: emailController,
          hintText: 'Email Address',
          keyboardType: TextInputType.emailAddress,
          onChanged: (_) => _updateUserInfo(),
        ),
        const SizedBox(height: 16),
        _buildPasswordField(),
      ],
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    TextInputType? keyboardType,
    ValueChanged<String>? onChanged,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.lightGrey,
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        onChanged: onChanged,
        style: GoogleFonts.openSans(
          fontSize: 16,
          color: AppColors.darkBlue,
        ),
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: GoogleFonts.openSans(
            fontSize: 16,
            color: AppColors.greyText,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 14,
          ),
        ),
      ),
    );
  }

  Widget _buildGenderDropdown() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.lightGrey,
        borderRadius: BorderRadius.circular(12),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: selectedGender.isEmpty ? null : selectedGender,
          hint: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 14,
            ),
            child: Text(
              'Select Gender',
              style: GoogleFonts.openSans(
                fontSize: 16,
                color: AppColors.greyText,
              ),
            ),
          ),
          isExpanded: true,
          items: genderOptions.map((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  value,
                  style: GoogleFonts.openSans(
                    fontSize: 16,
                    color: AppColors.darkBlue,
                  ),
                ),
              ),
            );
          }).toList(),
          onChanged: (String? value) {
            setState(() {
              selectedGender = value ?? '';
            });
            _updateUserInfo();
          },
        ),
      ),
    );
  }

  Widget _buildBirthdateField() {
    return InkWell(
      onTap: () async {
        final picked = await showDatePicker(
          context: context,
          initialDate: selectedBirthdate ?? DateTime.now().subtract(Duration(days: 365 * 20)),
          firstDate: DateTime(1900),
          lastDate: DateTime.now(),
          builder: (context, child) {
            return Theme(
              data: Theme.of(context).copyWith(
                colorScheme: ColorScheme.light(
                  primary: AppColors.primaryBlue,
                  onPrimary: Colors.white,
                  surface: Colors.white,
                  onSurface: AppColors.darkBlue,
                ),
                dialogBackgroundColor: Colors.white,
              ),
              child: child!,
            );
          },
        );
        if (picked != null) {
          setState(() {
            selectedBirthdate = picked;
          });
          _updateUserInfo();
        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.lightGrey,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              selectedBirthdate != null
                  ? '${selectedBirthdate!.month.toString().padLeft(2, '0')}/${selectedBirthdate!.day.toString().padLeft(2, '0')}/${selectedBirthdate!.year}'
                  : 'Birthdate',
              style: GoogleFonts.openSans(
                fontSize: 16,
                color: selectedBirthdate != null ? AppColors.darkBlue : AppColors.greyText,
              ),
            ),
            Icon(
              Icons.calendar_today,
              color: AppColors.greyText,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPasswordField() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.lightGrey,
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextField(
        controller: passwordController,
        obscureText: !isPasswordVisible,
        onChanged: (_) => _updateUserInfo(),
        style: GoogleFonts.openSans(
          fontSize: 16,
          color: AppColors.darkBlue,
        ),
        decoration: InputDecoration(
          hintText: 'Password',
          hintStyle: GoogleFonts.openSans(
            fontSize: 16,
            color: AppColors.greyText,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.only(
            left: 16,
            right: 8,
            top: 14,
            bottom: 14,
          ),
          suffixIcon: IconButton(
            icon: Icon(
              isPasswordVisible
                  ? Icons.visibility_outlined
                  : Icons.visibility_off_outlined,
              color: AppColors.greyText,
              size: 20,
            ),
            onPressed: () {
              setState(() {
                isPasswordVisible = !isPasswordVisible;
              });
            },
          ),
        ),
      ),
    );
  }

  Widget _buildNavigationButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          width: 120,
          height: 52,
          child: ElevatedButton(
            onPressed: widget.onPrevious,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.lightGrey,
              foregroundColor: AppColors.primaryBlue,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(26),
              ),
              elevation: 0,
              shadowColor: Colors.transparent,
            ),
            child: Text(
              'Back',
              style: GoogleFonts.openSans(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.4,
              ),
            ),
          ),
        ),
        SizedBox(
          width: 124,
          height: 52,
          child: ElevatedButton(
            onPressed: (isFormValid && !widget.isLoading) ? widget.onComplete : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryBlue,
              foregroundColor: AppColors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(26),
              ),
              elevation: 2,
              shadowColor: AppColors.primaryBlue.withValues(alpha: 0.3),
              disabledBackgroundColor: AppColors.lightGrey,
              disabledForegroundColor: AppColors.greyText,
            ),
            child: widget.isLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  )
                : Text(
                    'Complete',
                    style: GoogleFonts.openSans(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.4,
                    ),
                  ),
          ),
        ),
      ],
    );
  }
}