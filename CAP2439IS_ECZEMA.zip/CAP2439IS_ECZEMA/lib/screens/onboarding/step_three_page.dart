import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';

/// StepThreeWidget - Affected body areas selection (Step 3 of onboarding)
///
/// This widget allows users to identify which body areas are affected by their
/// eczema. Body areas are organized into categories for easy selection and
/// browsing.
///
/// Key Features:
/// - Multiple body area categories (Head & Face, Upper Body, Lower Body, Hands & Feet)
/// - Expandable/collapsible category sections
/// - Search functionality to quickly find specific body areas
/// - Selected areas preview with expandable detail view
/// - Multiple area selection support
/// - Progress counter showing selected vs total areas per category
///
/// User Interactions:
/// - Tap categories to expand/collapse body area lists
/// - Tap individual areas to select/deselect them
/// - Use search bar to filter body areas across all categories
/// - View selected areas in collapsible header section
/// - Remove selected areas by tapping in expanded selected section
/// - Navigate back to previous step or forward to next step
///
/// Data Flow:
/// - Reads: selectedAreas (Set of String) - currently selected body areas
/// - Writes: onAreasChanged callback with updated area selection
/// - Validates: At least one area must be selected to proceed
///
/// Navigation:
/// - Back: Returns to Step 2 (severity assessment)
/// - Next: Proceeds to Step 4 (trigger identification) if at least one area is selected
class StepThreeWidget extends StatefulWidget {
  final VoidCallback onNext;
  final VoidCallback onPrevious;
  final Set<String> selectedAreas;
  final ValueChanged<Set<String>> onAreasChanged;

  const StepThreeWidget({
    super.key,
    required this.onNext,
    required this.onPrevious,
    required this.selectedAreas,
    required this.onAreasChanged,
  });

  @override
  State<StepThreeWidget> createState() => _StepThreeWidgetState();
}

class _StepThreeWidgetState extends State<StepThreeWidget> {
  final TextEditingController searchController = TextEditingController();
  final Map<String, bool> expandedCategories = {};
  bool isSearching = false;
  bool isSelectedAreasExpanded = false;
  List<String> searchResults = [];

  final Map<String, List<String>> bodyPartCategories = {
    'Head & Face': [
      'Head',
      'Forehead',
      'Left Cheek',
      'Right Cheek',
      'Nose',
      'Lips',
      'Chin',
    ],
    'Neck & Shoulders': ['Neck', 'Left Shoulder', 'Right Shoulder'],
    'Arms & Hands': [
      'Left Arm',
      'Right Arm',
      'Left Elbow',
      'Right Elbow',
      'Left Forearm',
      'Right Forearm',
      'Left Hand',
      'Right Hand',
      'Left Wrist',
      'Right Wrist',
      'Fingers',
    ],
    'Torso': [
      'Chest',
      'Back',
      'Upper Back',
      'Lower Back',
      'Abdomen',
      'Stomach',
      'Waist',
    ],
    'Hips & Groin': ['Left Hip', 'Right Hip', 'Groin'],
    'Legs & Feet': [
      'Left Thigh',
      'Right Thigh',
      'Left Knee',
      'Right Knee',
      'Left Shin',
      'Right Shin',
      'Left Calf',
      'Right Calf',
      'Left Ankle',
      'Right Ankle',
      'Left Foot',
      'Right Foot',
      'Toes',
    ],
  };

  List<String> get allBodyParts {
    return bodyPartCategories.values.expand((parts) => parts).toList();
  }

  @override
  void initState() {
    super.initState();
    // Initialize all categories as collapsed
    for (String category in bodyPartCategories.keys) {
      expandedCategories[category] = false;
    }
    searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    setState(() {
      if (searchController.text.isEmpty) {
        isSearching = false;
        searchResults = [];
      } else {
        isSearching = true;
        searchResults = allBodyParts
            .where(
              (part) => part.toLowerCase().contains(
                searchController.text.toLowerCase(),
              ),
            )
            .toList();
      }
    });
  }

  void _updateSelectedAreas(String area) {
    Set<String> newSelectedAreas = Set.from(widget.selectedAreas);
    if (newSelectedAreas.contains(area)) {
      newSelectedAreas.remove(area);
    } else {
      newSelectedAreas.add(area);
    }
    widget.onAreasChanged(newSelectedAreas);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(33, 24, 32, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(),
          const SizedBox(height: 16),
          _buildQuestionText(),
          const SizedBox(height: 24),
          Expanded(
            child: Column(
              children: [
                Expanded(child: _buildBodyMapSection()),
                const SizedBox(height: 20),
                _buildNavigationButtons(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader() {
    return Text(
      'Personal Information:',
      style: GoogleFonts.quicksand(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: AppColors.darkBlue,
        height: 1.3,
      ),
    );
  }

  Widget _buildQuestionText() {
    return Text(
      'Body Area Selection. Select all areas where you experience eczema.',
      style: GoogleFonts.openSans(
        fontSize: 16,
        fontWeight: FontWeight.w400,
        color: AppColors.darkBlue,
        height: 1.4,
      ),
    );
  }

  Widget _buildBodyMapSection() {
    return Column(
      children: [
        _buildSearchBar(),
        const SizedBox(height: 16),
        if (widget.selectedAreas.isNotEmpty) ...[
          _buildSelectedAreasHeader(),
          const SizedBox(height: 12),
        ],
        Expanded(child: _buildBodyPartsList()),
      ],
    );
  }

  Widget _buildSelectedAreasHeader() {
    final selectedCount = widget.selectedAreas.length;
    final previewAreas = widget.selectedAreas.take(3).toList();
    final hasMore = selectedCount > 3;

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: AppColors.primaryBlue.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppColors.primaryBlue.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          // Compact Header
          GestureDetector(
            onTap: () {
              setState(() {
                isSelectedAreasExpanded = !isSelectedAreasExpanded;
              });
            },
            child: Container(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.primaryBlue,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      selectedCount.toString(),
                      style: GoogleFonts.openSans(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Selected Areas',
                          style: GoogleFonts.openSans(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: AppColors.darkBlue,
                          ),
                        ),
                        if (!isSelectedAreasExpanded && selectedCount > 0) ...[
                          const SizedBox(height: 4),
                          Text(
                            hasMore
                                ? '${previewAreas.join(', ')}${hasMore ? ' +${selectedCount - 3} more' : ''}'
                                : previewAreas.join(', '),
                            style: GoogleFonts.openSans(
                              fontSize: 12,
                              color: AppColors.greyText,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(
                    isSelectedAreasExpanded
                        ? Icons.expand_less
                        : Icons.expand_more,
                    color: AppColors.primaryBlue,
                    size: 24,
                  ),
                ],
              ),
            ),
          ),
          // Expanded Content
          if (isSelectedAreasExpanded) ...[
            const Divider(
              color: AppColors.primaryBlue,
              height: 1,
              thickness: 0.5,
            ),
            Container(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Tap to remove:',
                    style: GoogleFonts.openSans(
                      fontSize: 12,
                      color: AppColors.greyText,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: widget.selectedAreas
                        .map((area) => _buildAreaChip(area))
                        .toList(),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildAreaChip(String area) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.primaryBlue,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            area,
            style: GoogleFonts.openSans(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: AppColors.white,
            ),
          ),
          const SizedBox(width: 4),
          GestureDetector(
            onTap: () {
              _updateSelectedAreas(area);
            },
            child: const Icon(Icons.close, size: 16, color: AppColors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.lightGrey,
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextField(
        controller: searchController,
        style: GoogleFonts.openSans(fontSize: 16, color: AppColors.darkBlue),
        decoration: InputDecoration(
          hintText: 'Search body parts...',
          hintStyle: GoogleFonts.openSans(
            fontSize: 16,
            color: AppColors.greyText,
          ),
          prefixIcon: const Icon(Icons.search, color: AppColors.greyText),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 14,
          ),
        ),
      ),
    );
  }

  Widget _buildBodyPartsList() {
    if (isSearching) {
      return _buildSearchResults();
    }

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.lightGrey, width: 1),
      ),
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: bodyPartCategories.length,
        separatorBuilder: (context, index) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final category = bodyPartCategories.keys.elementAt(index);
          final parts = bodyPartCategories[category]!;
          final isExpanded = expandedCategories[category] ?? false;

          return Container(
            decoration: BoxDecoration(
              color: AppColors.lightGrey,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                // Category Header
                GestureDetector(
                  onTap: () {
                    setState(() {
                      expandedCategories[category] = !isExpanded;
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isExpanded
                          ? AppColors.primaryBlue.withValues(alpha: 0.1)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: [
                        _buildCategoryIcon(category),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            category,
                            style: GoogleFonts.quicksand(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: AppColors.darkBlue,
                            ),
                          ),
                        ),
                        Text(
                          '${parts.where((part) => widget.selectedAreas.contains(part)).length}/${parts.length}',
                          style: GoogleFonts.openSans(
                            fontSize: 12,
                            color: AppColors.greyText,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Icon(
                          isExpanded ? Icons.expand_less : Icons.expand_more,
                          color: AppColors.primaryBlue,
                        ),
                      ],
                    ),
                  ),
                ),
                // Category Items
                if (isExpanded) ...[
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: parts.map((part) {
                        final isSelected = widget.selectedAreas.contains(part);
                        return GestureDetector(
                          onTap: () {
                            _updateSelectedAreas(part);
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 8,
                            ),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? AppColors.primaryBlue
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: AppColors.primaryBlue,
                                width: 1.5,
                              ),
                            ),
                            child: Text(
                              part,
                              style: GoogleFonts.openSans(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: isSelected
                                    ? Colors.white
                                    : AppColors.primaryBlue,
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildSearchResults() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.lightGrey,
        borderRadius: BorderRadius.circular(16),
      ),
      child: searchResults.isEmpty
          ? _buildNoResultsMessage()
          : Padding(
              padding: const EdgeInsets.all(16),
              child: GridView.builder(
                itemCount: searchResults.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 3.5,
                ),
                itemBuilder: (context, index) {
                  final bodyPart = searchResults[index];
                  final isSelected = widget.selectedAreas.contains(bodyPart);

                  return GestureDetector(
                    onTap: () {
                      _updateSelectedAreas(bodyPart);
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: isSelected
                            ? AppColors.primaryBlue
                            : AppColors.white,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: AppColors.primaryBlue,
                          width: 1.5,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.05),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Center(
                        child: Text(
                          bodyPart,
                          style: GoogleFonts.openSans(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: isSelected
                                ? AppColors.white
                                : AppColors.primaryBlue,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
    );
  }

  Widget _buildCategoryIcon(String category) {
    String? iconPath = _getCustomIconPath(category);

    if (iconPath != null) {
      return Container(
        width: 24,
        height: 24,
        child: Image.asset(
          iconPath,
          width: 24,
          height: 24,
          color: AppColors.primaryBlue,
          fit: BoxFit.contain,
        ),
      );
    }

    return Icon(
      _getCategoryIcon(category),
      color: AppColors.primaryBlue,
      size: 24,
    );
  }

  String? _getCustomIconPath(String category) {
    switch (category) {
      case 'Head & Face':
        return 'assets/icons/head.png';
      case 'Neck & Shoulders':
        return 'assets/icons/neckandshoulders.png';
      case 'Arms & Hands':
        return 'assets/icons/hands.png';
      case 'Torso':
        return 'assets/icons/torso.png';
      case 'Hips & Groin':
        return 'assets/icons/hips.png';
      case 'Legs & Feet':
        return 'assets/icons/legs.png';
      default:
        return null;
    }
  }

  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Head & Face':
        return Icons.face_rounded;
      case 'Neck & Shoulders':
        return Icons.accessibility;
      case 'Arms & Hands':
        return Icons.front_hand;
      case 'Torso':
        return Icons.radio_button_unchecked;
      case 'Hips & Groin':
        return Icons.crop_landscape;
      case 'Legs & Feet':
        return Icons.nordic_walking;
      default:
        return Icons.radio_button_unchecked;
    }
  }

  Widget _buildNoResultsMessage() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search_off,
              size: 64,
              color: AppColors.greyText.withValues(alpha: 0.5),
            ),
            const SizedBox(height: 16),
            Text(
              'No body parts found',
              style: GoogleFonts.openSans(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: AppColors.greyText,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Try a different search term',
              style: GoogleFonts.openSans(
                fontSize: 14,
                color: AppColors.greyText,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavigationButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          width: 120,
          height: 52,
          child: ElevatedButton(
            onPressed: widget.onPrevious,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.lightGrey,
              foregroundColor: AppColors.primaryBlue,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(26),
              ),
              elevation: 0,
              shadowColor: Colors.transparent,
            ),
            child: Text(
              'Back',
              style: GoogleFonts.openSans(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.4,
              ),
            ),
          ),
        ),
        SizedBox(
          width: 120,
          height: 52,
          child: ElevatedButton(
            onPressed: widget.selectedAreas.isNotEmpty ? widget.onNext : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryBlue,
              foregroundColor: AppColors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(26),
              ),
              elevation: 2,
              shadowColor: AppColors.primaryBlue.withValues(alpha: 0.3),
              disabledBackgroundColor: AppColors.lightGrey,
              disabledForegroundColor: AppColors.greyText,
            ),
            child: Text(
              'Next',
              style: GoogleFonts.openSans(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.4,
              ),
            ),
          ),
        ),
      ],
    );
  }
}