import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';

/// StepOneWidget - Eczema diagnosis timeline selection (Step 1 of onboarding)
///
/// This widget collects information about when the user was first diagnosed with
/// eczema. It is the first step in the onboarding process and includes a back
/// button to return to the welcome screen.
///
/// Key Features:
/// - Six predefined timeline options from recent to childhood diagnosis
/// - Single selection from predefined options
/// - Visual feedback for selected option
/// - Back button to return to welcome screen
/// - Next button enabled only when an option is selected
///
/// User Interactions:
/// - Tap any option to select it
/// - Only one option can be selected at a time
/// - Tap Back to return to welcome screen
/// - Tap Next to proceed to Step 2 (only enabled when option selected)
///
/// Data Flow:
/// - Reads: selectedOption (String) - currently selected diagnosis timeline
/// - Writes: onOptionChanged callback with selected option
/// - Validates: An option must be selected to enable Next button
///
/// Navigation:
/// - Back: Returns to Welcome Screen
/// - Next: Proceeds to Step 2 (severity assessment) when option is selected
class StepOneWidget extends StatefulWidget {
  final VoidCallback onNext;
  final VoidCallback? onBack;
  final String? selectedOption;
  final ValueChanged<String?> onOptionChanged;

  const StepOneWidget({
    super.key,
    required this.onNext,
    this.onBack,
    this.selectedOption,
    required this.onOptionChanged,
  });

  @override
  State<StepOneWidget> createState() => _StepOneWidgetState();
}

class _StepOneWidgetState extends State<StepOneWidget> {
  final List<String> options = [
    'Less than a month',
    '6 months',
    '1-5 years',
    'More than 5 years',
    'Since childhood',
    'Not diagnosed yet',
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(40, 24, 32, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(),
          const SizedBox(height: 16),
          _buildQuestionText(),
          const SizedBox(height: 24),
          Expanded(
            child: Column(
              children: [
                ..._buildOptions(),
                const SizedBox(height: 20),
                _buildNextButton(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader() {
    return Text(
      'Personal Information:',
      style: GoogleFonts.quicksand(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: AppColors.darkBlue,
        height: 1.3,
      ),
    );
  }

  Widget _buildQuestionText() {
    return Text(
      'When were you first diagnosed with eczema?',
      style: GoogleFonts.openSans(
        fontSize: 16,
        fontWeight: FontWeight.w400,
        color: AppColors.darkBlue,
        height: 1.4,
      ),
    );
  }

  List<Widget> _buildOptions() {
    return options.map((option) {
      final isSelected = widget.selectedOption == option;

      return Container(
        margin: const EdgeInsets.only(bottom: 12),
        child: SizedBox(
          width: double.infinity,
          height: 52,
          child: ElevatedButton(
            onPressed: () {
              widget.onOptionChanged(option);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: isSelected
                  ? AppColors.primaryBlue
                  : AppColors.lightGrey,
              foregroundColor: isSelected
                  ? AppColors.white
                  : AppColors.primaryBlue,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(26),
              ),
              elevation: 0,
              shadowColor: Colors.transparent,
            ),
            child: Text(
              option,
              style: GoogleFonts.openSans(
                fontSize: 15,
                fontWeight: FontWeight.w500,
                color: isSelected ? AppColors.white : AppColors.primaryBlue,
              ),
            ),
          ),
        ),
      );
    }).toList();
  }

  Widget _buildNextButton() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        if (widget.onBack != null)
          SizedBox(
            width: 120,
            height: 52,
            child: ElevatedButton(
              onPressed: widget.onBack,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.lightGrey,
                foregroundColor: AppColors.primaryBlue,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(26),
                ),
                elevation: 0,
                shadowColor: Colors.transparent,
              ),
              child: Text(
                'Back',
                style: GoogleFonts.openSans(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.4,
                ),
              ),
            ),
          ),
        if (widget.onBack == null) const Spacer(),
        SizedBox(
          width: 120,
          height: 52,
          child: ElevatedButton(
            onPressed: widget.selectedOption != null ? widget.onNext : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryBlue,
              foregroundColor: AppColors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(26),
              ),
              elevation: 2,
              shadowColor: AppColors.primaryBlue.withValues(alpha: 0.3),
              disabledBackgroundColor: AppColors.lightGrey,
              disabledForegroundColor: AppColors.greyText,
            ),
            child: Text(
              'Next',
              style: GoogleFonts.openSans(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.4,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
