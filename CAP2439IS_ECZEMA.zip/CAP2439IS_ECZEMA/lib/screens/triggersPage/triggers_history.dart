import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../core/widgets/index.dart';
import '../../models/trigger_model.dart';
import '../../services/trigger_storage.dart';
import 'triggers_page.dart';

/// TriggersHistory - View, search, and manage saved eczema triggers
///
/// This screen displays a comprehensive history of all logged eczema triggers,
/// allowing users to review past entries, identify patterns over time, and
/// manage their trigger database through search, edit, and delete operations.
///
/// Key Features:
/// - Chronological list of all saved triggers (newest first)
/// - Real-time search functionality across trigger names, categories, and notes
/// - Statistical summary cards (total triggers, categories, this month)
/// - Visual severity indicators with color coding
/// - Trigger category badges for quick identification
/// - Edit existing triggers (navigates to TriggersPage)
/// - Delete triggers with confirmation dialog
/// - Empty state with call-to-action for first trigger
/// - Floating action button for quick trigger addition
///
/// User Interactions:
/// - Search triggers by name, category, or notes
/// - View detailed trigger information in card format
/// - Edit trigger (opens TriggersPage in edit mode)
/// - Delete trigger (shows confirmation dialog)
/// - Add new trigger via floating button or empty state
/// - Navigate back to previous screen
///
/// Data Flow:
/// - Reads: All triggers from TriggerStorage on init
/// - Filters: Applies search query to trigger list
/// - Updates: Reloads list after edit/delete operations
/// - Deletes: Removes triggers from storage with confirmation
///
/// Display Information per Trigger:
/// - Category badge with color
/// - Trigger name/title
/// - Severity rating (visual indicator)
/// - Reaction time
/// - Number of affected areas
/// - Identification date
/// - Symptoms (up to 3 shown as chips)
/// - Notes preview (if available)
class TriggersHistory extends StatefulWidget {
  const TriggersHistory({super.key});

  @override
  State<TriggersHistory> createState() => _TriggersHistoryState();
}

class _TriggersHistoryState extends State<TriggersHistory> {
  // State variables for trigger data and UI state
  List<TriggerModel> triggers = [];  // All loaded triggers
  bool isLoading = true;  // Loading state for initial fetch
  String searchQuery = '';  // Current search filter text

  @override
  void initState() {
    super.initState();
    _loadTriggers();
  }

  Future<void> _loadTriggers() async {
    setState(() => isLoading = true);
    final loadedTriggers = await TriggerStorage.getAllTriggers();

    // Sort by creation date (newest first)
    loadedTriggers.sort((a, b) => b.createdAt.compareTo(a.createdAt));

    setState(() {
      triggers = loadedTriggers;
      isLoading = false;
    });
  }

  List<TriggerModel> get filteredTriggers {
    if (searchQuery.isEmpty) return triggers;

    return triggers.where((trigger) {
      final specificTrigger = trigger.specificTrigger.toLowerCase();
      final category = trigger.triggerCategory.toLowerCase();
      final notes = trigger.notes.toLowerCase();
      final query = searchQuery.toLowerCase();

      return specificTrigger.contains(query) ||
          category.contains(query) ||
          notes.contains(query);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      body: Container(
        color: const Color(0xFFF7F7F7),
        child: SafeArea(
          child: Column(
            children: [
              CustomHeader(title: 'Triggers History'),
              if (isLoading)
                const Expanded(
                  child: Center(child: CircularProgressIndicator()),
                )
              else
                Expanded(
                  child: triggers.isEmpty
                      ? CustomEmptyState(
                          icon: Icons.warning_amber_rounded,
                          title: 'No Triggers Added',
                          message: 'Start tracking your eczema triggers to identify patterns and manage your condition better.',
                          actionText: 'Add Your First Trigger',
                          onActionPressed: _addNewTrigger,
                        )
                      : Column(
                          children: [
                            CustomSearchBar(
                              hintText: 'Search triggers...',
                              onChanged: (value) {
                                setState(() {
                                  searchQuery = value;
                                });
                              },
                            ),
                            _buildStatsRow(),
                            Expanded(child: _buildTriggersList()),
                          ],
                        ),
                ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNewTrigger,
        backgroundColor: AppColors.primaryBlue,
        foregroundColor: AppColors.white,
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 20),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.primaryBlue.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Padding(
                padding: EdgeInsets.only(left: 5),
                child: Icon(
                  Icons.arrow_back_ios,
                  color: AppColors.primaryBlue,
                  size: 20,
                ),
              ),
            ),
          ),
          Expanded(
            child: Center(
              child: Text(
                'Triggers History',
                style: GoogleFonts.quicksand(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: AppColors.primaryBlue,
                ),
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.primaryBlue.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.person,
              color: AppColors.primaryBlue,
              size: 20,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(24, 0, 24, 16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TextField(
        onChanged: (value) {
          setState(() {
            searchQuery = value;
          });
        },
        style: GoogleFonts.openSans(
          fontSize: 16,
          color: AppColors.darkBlue,
        ),
        decoration: InputDecoration(
          hintText: 'Search triggers...',
          hintStyle: GoogleFonts.openSans(
            fontSize: 16,
            color: AppColors.greyText,
          ),
          prefixIcon: const Icon(
            Icons.search,
            color: AppColors.greyText,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.all(16),
        ),
      ),
    );
  }

  Widget _buildStatsRow() {
    final categories = triggers.map((t) => t.triggerCategory).toSet().length;
    final thisMonth = triggers.where((t) {
      final now = DateTime.now();
      return t.createdAt.year == now.year && t.createdAt.month == now.month;
    }).length;

    return Container(
      margin: const EdgeInsets.fromLTRB(24, 0, 24, 16),
      child: Row(
        children: [
          Expanded(
            child: CustomStatCard(
              title: 'Total Triggers',
              value: triggers.length.toString(),
              icon: Icons.warning_amber_rounded,
              iconColor: AppColors.primaryBlue,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: CustomStatCard(
              title: 'Categories',
              value: categories.toString(),
              icon: Icons.category,
              iconColor: const Color(0xFF4CAF50),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: CustomStatCard(
              title: 'This Month',
              value: thisMonth.toString(),
              icon: Icons.calendar_today,
              iconColor: const Color(0xFFFF9800),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 8),
          Text(
            value,
            style: GoogleFonts.quicksand(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
            ),
          ),
          Text(
            title,
            style: GoogleFonts.openSans(
              fontSize: 12,
              color: AppColors.greyText,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.warning_amber_rounded,
              size: 80,
              color: AppColors.greyText.withValues(alpha: 0.5),
            ),
            const SizedBox(height: 24),
            Text(
              'No Triggers Added',
              style: GoogleFonts.quicksand(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: AppColors.darkBlue,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Start tracking your eczema triggers to identify patterns and manage your condition better.',
              style: GoogleFonts.openSans(
                fontSize: 16,
                color: AppColors.greyText,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _addNewTrigger,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryBlue,
                  foregroundColor: AppColors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(26),
                  ),
                ),
                child: Text(
                  'Add Your First Trigger',
                  style: GoogleFonts.openSans(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.4,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTriggersList() {
    final displayTriggers = filteredTriggers;

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 100),
      itemCount: displayTriggers.length,
      itemBuilder: (context, index) {
        final trigger = displayTriggers[index];
        return _buildTriggerCard(trigger);
      },
    );
  }

  Widget _buildTriggerCard(TriggerModel trigger) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppColors.primaryBlue,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        trigger.triggerCategory,
                        style: GoogleFonts.openSans(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: AppColors.white,
                        ),
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: _getSeverityColor(trigger.severityImpact),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        '${trigger.severityImpact.round()}/10',
                        style: GoogleFonts.openSans(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: AppColors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  trigger.specificTrigger,
                  style: GoogleFonts.quicksand(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: AppColors.darkBlue,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(
                      Icons.schedule,
                      size: 16,
                      color: AppColors.greyText,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      trigger.reactionTime,
                      style: GoogleFonts.openSans(
                        fontSize: 14,
                        color: AppColors.greyText,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Icon(
                      Icons.location_on,
                      size: 16,
                      color: AppColors.greyText,
                    ),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        '${trigger.affectedAreas.length} area${trigger.affectedAreas.length != 1 ? 's' : ''}',
                        style: GoogleFonts.openSans(
                          fontSize: 14,
                          color: AppColors.greyText,
                        ),
                      ),
                    ),
                    Icon(
                      Icons.date_range,
                      size: 16,
                      color: AppColors.greyText,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '${trigger.dateIdentified.day}/${trigger.dateIdentified.month}/${trigger.dateIdentified.year}',
                      style: GoogleFonts.openSans(
                        fontSize: 14,
                        color: AppColors.greyText,
                      ),
                    ),
                  ],
                ),
                if (trigger.notes.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(
                    trigger.notes,
                    style: GoogleFonts.openSans(
                      fontSize: 14,
                      color: AppColors.greyText,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
                if (trigger.symptomsTriggered.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 4,
                    runSpacing: 4,
                    children: trigger.symptomsTriggered.take(3).map((symptom) {
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.lightGrey,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          symptom,
                          style: GoogleFonts.openSans(
                            fontSize: 11,
                            color: AppColors.primaryBlue,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: AppColors.lightGrey.withValues(alpha: 0.5),
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(16),
                bottomRight: Radius.circular(16),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextButton.icon(
                    onPressed: () => _editTrigger(trigger),
                    icon: const Icon(Icons.edit, size: 18),
                    label: Text(
                      'Edit',
                      style: GoogleFonts.openSans(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    style: TextButton.styleFrom(
                      foregroundColor: AppColors.primaryBlue,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                  ),
                ),
                Container(
                  width: 1,
                  height: 20,
                  color: AppColors.greyText.withValues(alpha: 0.3),
                ),
                Expanded(
                  child: TextButton.icon(
                    onPressed: () => _deleteTrigger(trigger),
                    icon: const Icon(Icons.delete, size: 18),
                    label: Text(
                      'Delete',
                      style: GoogleFonts.openSans(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.red,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getSeverityColor(double severity) {
    if (severity <= 3) {
      return const Color(0xFF4CAF50);
    } else if (severity <= 6) {
      return const Color(0xFFFF9800);
    } else {
      return const Color(0xFFFF5252);
    }
  }

  void _addNewTrigger() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const TriggersPage(),
      ),
    );

    if (result != null && result is TriggerModel) {
      await TriggerStorage.saveTrigger(result);
      _loadTriggers();
    }
  }

  void _editTrigger(TriggerModel trigger) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TriggersPage(editingTrigger: trigger),
      ),
    );

    if (result != null && result is TriggerModel) {
      await TriggerStorage.updateTrigger(trigger.id!, result);
      _loadTriggers();
    }
  }

  void _deleteTrigger(TriggerModel trigger) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: Text(
            'Delete Trigger',
            style: GoogleFonts.quicksand(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
            ),
          ),
          content: Text(
            'Are you sure you want to delete "${trigger.specificTrigger}"? This action cannot be undone.',
            style: GoogleFonts.openSans(
              fontSize: 14,
              color: AppColors.greyText,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'Cancel',
                style: GoogleFonts.openSans(
                  color: AppColors.greyText,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () async {
                await TriggerStorage.deleteTrigger(trigger.id!);
                Navigator.pop(context);
                _loadTriggers();

                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'Trigger deleted successfully',
                        style: GoogleFonts.openSans(),
                      ),
                      backgroundColor: Colors.red,
                      duration: const Duration(seconds: 2),
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: AppColors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(
                'Delete',
                style: GoogleFonts.openSans(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}