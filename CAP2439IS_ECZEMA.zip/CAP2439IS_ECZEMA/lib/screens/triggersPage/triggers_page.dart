import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_button_styles.dart';
import '../../core/widgets/custom_slider.dart';
import '../../models/trigger_model.dart';
import '../../services/trigger_storage.dart';
import '../careRoutinePage/body_map_selector.dart';
import 'triggers_history.dart';

/// TriggersPage - Log and track eczema triggers with detailed information
///
/// This screen enables users to document potential eczema triggers they've identified,
/// including detailed information about the trigger type, severity impact, affected areas,
/// and observed symptoms. Helps users build a comprehensive trigger database for
/// pattern identification and avoidance strategies.
///
/// Key Features:
/// - Categorized trigger selection (Environmental, Food, Stress, Weather, Products, Others)
/// - Category-specific suggestions for quick entry
/// - Interactive body map for marking affected areas
/// - Multiple symptom selection from common eczema symptoms
/// - Severity impact rating (1-10 scale)
/// - Reaction time tracking (Immediate, Within hours, Within days, Variable)
/// - Confidence level rating (optional 0-100% scale)
/// - Date identification for temporal tracking
/// - Notes field for additional context
///
/// User Interactions:
/// - Select trigger category from horizontal scrollable list
/// - Choose from suggestions or enter custom trigger
/// - Rate severity impact using visual slider
/// - Select reaction time from dropdown
/// - Mark affected body areas on interactive map
/// - Toggle symptoms from comprehensive symptom list
/// - Pick identification date from calendar
/// - Optionally set confidence level
/// - Save trigger with validation
/// - Navigate to triggers history
///
/// Data Flow:
/// - Reads: Existing trigger data if editing (passed via constructor)
/// - Writes: Saves new triggers to TriggerStorage (local)
/// - Updates: Modifies existing trigger entries
/// - Returns: Saved/updated trigger model on successful save
///
/// Validation:
/// - Specific trigger name is required
/// - At least one affected area must be selected
/// - At least one symptom must be selected
class TriggersPage extends StatefulWidget {
  final TriggerModel? editingTrigger;  // Optional trigger data for editing mode

  const TriggersPage({super.key, this.editingTrigger});

  @override
  State<TriggersPage> createState() => _TriggersPageState();
}

class _TriggersPageState extends State<TriggersPage> {
  // Text controllers for user input fields
  final TextEditingController specificTriggerController = TextEditingController();
  final TextEditingController notesController = TextEditingController();

  String selectedTriggerCategory = 'Environmental';
  double severityImpact = 5.0;
  String selectedReactionTime = 'Immediate';
  Set<String> selectedAffectedAreas = <String>{};
  Set<String> selectedSymptoms = <String>{};
  DateTime selectedDate = DateTime.now();
  double? confidenceLevel = 75.0;

  final List<String> triggerCategories = [
    'Environmental',
    'Food',
    'Stress',
    'Weather',
    'Products',
    'Others',
  ];

  final Map<String, List<String>> triggerSuggestions = {
    'Environmental': [
      'Dust mites',
      'Pet dander',
      'Pollen',
      'Mold',
      'Air pollution',
      'Smoke',
      'Chemical fumes',
      'Cleaning products',
    ],
    'Food': [
      'Dairy products',
      'Eggs',
      'Nuts',
      'Seafood',
      'Citrus fruits',
      'Chocolate',
      'Spicy foods',
      'Food additives',
    ],
    'Stress': [
      'Work pressure',
      'Relationship issues',
      'Financial stress',
      'Lack of sleep',
      'Emotional stress',
      'Physical stress',
      'Life changes',
      'Anxiety',
    ],
    'Weather': [
      'Hot weather',
      'Cold weather',
      'High humidity',
      'Low humidity',
      'Wind',
      'Sun exposure',
      'Temperature changes',
      'Dry air',
    ],
    'Products': [
      'Soap',
      'Shampoo',
      'Laundry detergent',
      'Fabric softener',
      'Perfume',
      'Cosmetics',
      'Sunscreen',
      'Wool clothing',
      'Synthetic fabrics',
    ],
    'Others': [
      'Hormonal changes',
      'Illness',
      'Medications',
      'Physical activity',
      'Scratching',
      'Hot baths',
      'Contact with allergens',
    ],
  };

  final List<String> reactionTimes = [
    'Immediate',
    'Within hours',
    'Within days',
    'Variable',
  ];

  final List<String> commonSymptoms = [
    'Itching',
    'Redness',
    'Swelling',
    'Dryness',
    'Pain',
    'Burning sensation',
    'Scaling',
    'Cracking',
    'Blisters',
    'Oozing',
    'Thickened skin',
    'Discoloration',
  ];

  @override
  void initState() {
    super.initState();
    _initializeForEditing();
  }

  void _initializeForEditing() {
    if (widget.editingTrigger != null) {
      final trigger = widget.editingTrigger!;
      specificTriggerController.text = trigger.specificTrigger;
      notesController.text = trigger.notes;
      selectedTriggerCategory = trigger.triggerCategory;
      severityImpact = trigger.severityImpact;
      selectedReactionTime = trigger.reactionTime;
      selectedAffectedAreas = Set<String>.from(trigger.affectedAreas);
      selectedSymptoms = Set<String>.from(trigger.symptomsTriggered);
      selectedDate = trigger.dateIdentified;
      confidenceLevel = trigger.confidenceLevel;
    }
  }

  @override
  void dispose() {
    specificTriggerController.dispose();
    notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      body: Container(
        color: const Color(0xFFF7F7F7),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 24),
                      _buildTriggerCategorySection(),
                      const SizedBox(height: 20),
                      _buildSpecificTriggerField(),
                      const SizedBox(height: 20),
                      _buildSeverityImpactSection(),
                      const SizedBox(height: 20),
                      _buildReactionTimeSection(),
                      const SizedBox(height: 20),
                      _buildAffectedAreasSection(),
                      const SizedBox(height: 20),
                      _buildSymptomsTriggeredSection(),
                      const SizedBox(height: 20),
                      _buildDateIdentifiedSection(),
                      const SizedBox(height: 20),
                      _buildConfidenceLevelSection(),
                      const SizedBox(height: 20),
                      _buildNotesField(),
                      const SizedBox(height: 32),
                      _buildSaveButton(),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 20),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.primaryBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Padding(
                padding: EdgeInsets.only(left: 5),
                child: Icon(
                  Icons.arrow_back_ios,
                  color: AppColors.primaryBlue,
                  size: 20,
                ),
              ),
            ),
          ),
          Expanded(
            child: Center(
              child: Text(
                widget.editingTrigger != null ? 'Edit Trigger' : 'Add Trigger',
                style: GoogleFonts.quicksand(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: AppColors.primaryBlue,
                ),
              ),
            ),
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const TriggersHistory()),
              );
            },
            child: Container(
              padding: const EdgeInsets.all(8),
              margin: const EdgeInsets.only(right: 8),
              decoration: BoxDecoration(
                color: AppColors.primaryBlue.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.history,
                color: AppColors.primaryBlue,
                size: 20,
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.primaryBlue.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.person,
              color: AppColors.primaryBlue,
              size: 20,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTriggerCategorySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Trigger Category',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(
            color: AppColors.lightGrey,
            borderRadius: BorderRadius.circular(12),
          ),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.all(8),
            child: Row(
              children: triggerCategories.map((category) {
                final isSelected = selectedTriggerCategory == category;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        selectedTriggerCategory = category;
                        specificTriggerController.clear();
                      });
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: isSelected ? AppColors.primaryBlue : AppColors.white,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: AppColors.primaryBlue,
                          width: 1.5,
                        ),
                      ),
                      child: Text(
                        category,
                        style: GoogleFonts.openSans(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: isSelected ? AppColors.white : AppColors.primaryBlue,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSpecificTriggerField() {
    final suggestions = triggerSuggestions[selectedTriggerCategory] ?? [];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Specific Trigger',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppColors.lightGrey,
            borderRadius: BorderRadius.circular(12),
          ),
          child: TextField(
            controller: specificTriggerController,
            style: GoogleFonts.openSans(
              fontSize: 16,
              color: AppColors.darkBlue,
            ),
            decoration: InputDecoration(
              hintText: 'Enter specific trigger name',
              hintStyle: GoogleFonts.openSans(
                fontSize: 16,
                color: AppColors.greyText,
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(16),
            ),
          ),
        ),
        if (suggestions.isNotEmpty) ...[
          const SizedBox(height: 12),
          Text(
            'Suggestions',
            style: GoogleFonts.openSans(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: AppColors.greyText,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.lightGrey, width: 1),
            ),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: suggestions.map((suggestion) {
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      specificTriggerController.text = suggestion;
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppColors.primaryBlue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: AppColors.primaryBlue.withOpacity(0.3),
                        width: 1,
                      ),
                    ),
                    child: Text(
                      suggestion,
                      style: GoogleFonts.openSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: AppColors.primaryBlue,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildSeverityImpactSection() {
    return CustomSlider(
      title: 'Severity Impact',
      value: severityImpact,
      min: 1,
      max: 10,
      divisions: 9,
      leftLabel: 'Mild',
      rightLabel: 'Severe',
      sliderType: CustomSliderType.severity,
      onChanged: (value) {
        setState(() {
          severityImpact = value;
        });
      },
    );
  }

  Widget _buildReactionTimeSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Reaction Time',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppColors.lightGrey,
            borderRadius: BorderRadius.circular(12),
          ),
          child: DropdownButtonFormField<String>(
            value: selectedReactionTime,
            onChanged: (String? newValue) {
              if (newValue != null) {
                setState(() {
                  selectedReactionTime = newValue;
                });
              }
            },
            style: GoogleFonts.openSans(
              fontSize: 16,
              color: AppColors.darkBlue,
            ),
            decoration: const InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.all(16),
            ),
            dropdownColor: AppColors.white,
            icon: const Icon(
              Icons.keyboard_arrow_down,
              color: AppColors.primaryBlue,
            ),
            items: reactionTimes.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildAffectedAreasSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Affected Areas',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 12),
        if (selectedAffectedAreas.isNotEmpty) ...[
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.primaryBlue.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppColors.primaryBlue.withOpacity(0.3),
                width: 1,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Selected Areas (${selectedAffectedAreas.length})',
                  style: GoogleFonts.openSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppColors.darkBlue,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: selectedAffectedAreas.map((area) {
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppColors.primaryBlue,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            area,
                            style: GoogleFonts.openSans(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: AppColors.white,
                            ),
                          ),
                          const SizedBox(width: 4),
                          GestureDetector(
                            onTap: () {
                              setState(() {
                                selectedAffectedAreas.remove(area);
                              });
                            },
                            child: const Icon(Icons.close, size: 16, color: AppColors.white),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
        ],
        Container(
          height: 400,
          decoration: BoxDecoration(
            color: AppColors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.lightGrey, width: 1),
          ),
          child: BodyMapSelector(
            selectedAreas: selectedAffectedAreas,
            onAreasChanged: (Set<String> areas) {
              setState(() {
                selectedAffectedAreas = areas;
              });
            },
            showSearchBar: false,
            showSelectedAreasHeader: false,
            height: 400,
          ),
        ),
      ],
    );
  }

  Widget _buildSymptomsTriggeredSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Symptoms Triggered',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.lightGrey,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: commonSymptoms.map((symptom) {
              final isSelected = selectedSymptoms.contains(symptom);
              return GestureDetector(
                onTap: () {
                  setState(() {
                    if (isSelected) {
                      selectedSymptoms.remove(symptom);
                    } else {
                      selectedSymptoms.add(symptom);
                    }
                  });
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: isSelected ? AppColors.primaryBlue : AppColors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: AppColors.primaryBlue,
                      width: 1.5,
                    ),
                  ),
                  child: Text(
                    symptom,
                    style: GoogleFonts.openSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: isSelected ? AppColors.white : AppColors.primaryBlue,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildDateIdentifiedSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Date Identified',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 8),
        GestureDetector(
          onTap: () => _selectDate(context),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.lightGrey,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.calendar_today,
                  color: AppColors.primaryBlue,
                  size: 20,
                ),
                const SizedBox(width: 12),
                Text(
                  '${selectedDate.day}/${selectedDate.month}/${selectedDate.year}',
                  style: GoogleFonts.openSans(
                    fontSize: 16,
                    color: AppColors.darkBlue,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: AppColors.primaryBlue,
              onPrimary: AppColors.white,
              surface: AppColors.white,
              onSurface: AppColors.darkBlue,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  Widget _buildConfidenceLevelSection() {
    if (confidenceLevel == null) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Confidence Level (Optional)',
            style: GoogleFonts.openSans(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: AppColors.darkBlue,
            ),
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppColors.lightGrey,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppColors.primaryBlue.withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: Column(
              children: [
                Icon(
                  Icons.help_outline,
                  size: 48,
                  color: AppColors.greyText.withValues(alpha: 0.5),
                ),
                const SizedBox(height: 12),
                Text(
                  'Tap to set confidence level',
                  style: GoogleFonts.openSans(
                    fontSize: 14,
                    color: AppColors.greyText,
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() {
                        confidenceLevel = 50.0;
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryBlue,
                      foregroundColor: AppColors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: Text(
                      'Add Confidence Level',
                      style: GoogleFonts.openSans(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      );
    }

    return CustomSlider(
      title: 'Confidence Level (Optional)',
      value: confidenceLevel!,
      min: 0,
      max: 100,
      divisions: 20,
      leftLabel: 'Not Sure',
      rightLabel: 'Very Confident',
      sliderType: CustomSliderType.confidence,
      isOptional: true,
      onChanged: (value) {
        setState(() {
          confidenceLevel = value;
        });
      },
      onClear: () {
        setState(() {
          confidenceLevel = null;
        });
      },
    );
  }

  Widget _buildNotesField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Notes',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppColors.lightGrey,
            borderRadius: BorderRadius.circular(12),
          ),
          child: TextField(
            controller: notesController,
            maxLines: 4,
            style: GoogleFonts.openSans(
              fontSize: 16,
              color: AppColors.darkBlue,
            ),
            decoration: InputDecoration(
              hintText: 'Add any extra context or observations...',
              hintStyle: GoogleFonts.openSans(
                fontSize: 16,
                color: AppColors.greyText,
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(16),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSaveButton() {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton(
        onPressed: _saveTrigger,
        style: AppButtonStyles.primaryButton,
        child: Text(
          widget.editingTrigger != null ? 'Update Trigger' : 'Save Trigger',
          style: GoogleFonts.openSans(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.4,
          ),
        ),
      ),
    );
  }

  void _saveTrigger() async {
    if (specificTriggerController.text.isEmpty) {
      _showValidationError('Please enter a specific trigger');
      return;
    }

    if (selectedAffectedAreas.isEmpty) {
      _showValidationError('Please select at least one affected area');
      return;
    }

    if (selectedSymptoms.isEmpty) {
      _showValidationError('Please select at least one symptom');
      return;
    }

    try {
      final triggerData = TriggerModel(
        id: widget.editingTrigger?.id,
        triggerCategory: selectedTriggerCategory,
        specificTrigger: specificTriggerController.text,
        severityImpact: severityImpact,
        reactionTime: selectedReactionTime,
        affectedAreas: selectedAffectedAreas.toList(),
        symptomsTriggered: selectedSymptoms.toList(),
        dateIdentified: selectedDate,
        confidenceLevel: confidenceLevel,
        notes: notesController.text,
        createdAt: widget.editingTrigger?.createdAt ?? DateTime.now(),
      );

      if (widget.editingTrigger != null) {
        // Update existing trigger
        await TriggerStorage.updateTrigger(widget.editingTrigger!.id!, triggerData);
      } else {
        // Save new trigger
        await TriggerStorage.saveTrigger(triggerData);
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              widget.editingTrigger != null
                  ? 'Trigger updated successfully!'
                  : 'Trigger saved successfully!',
              style: GoogleFonts.openSans(),
            ),
            backgroundColor: AppColors.primaryBlue,
            duration: const Duration(seconds: 2),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
        );

        Navigator.pop(context, triggerData);
      }
    } catch (e) {
      if (mounted) {
        _showValidationError('Error saving trigger: $e');
      }
    }
  }

  void _showValidationError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: GoogleFonts.openSans(),
        ),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 3),
      ),
    );
  }
}