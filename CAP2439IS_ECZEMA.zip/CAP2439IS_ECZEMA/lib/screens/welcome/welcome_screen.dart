import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_styles.dart';
import '../consent/consent_page.dart';
import '../login/login_page.dart';

/// WelcomeScreen - Initial landing page for the EczeManage application
///
/// This screen serves as the entry point for the application, presenting users with
/// the app's branding and primary navigation options. It is the first screen displayed
/// when the application launches.
///
/// Key Features:
/// - Displays app logo and branding elements with visual effects
/// - Provides two main call-to-action buttons for user authentication
/// - Uses gradient background for enhanced visual appeal
/// - Implements responsive layout with flexible spacing
///
/// User Interactions:
/// - "GET STARTED" button: Navigates to ConsentPage for new user registration
/// - "I HAVE AN ACCOUNT" button: Navigates to LoginPage for existing users
///
/// Data Flow:
/// - Read-only screen with no data persistence
/// - Acts as a navigation hub to authentication flows
///
/// Navigation:
/// - Forward: ConsentPage (new users) or LoginPage (existing users)
/// - No backward navigation as this is the initial screen
class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {

  /// Builds the main UI structure with gradient background and centered content
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Spacer(flex: 2),
                _buildLogo(),
                const SizedBox(height: 40),
                _buildTitle(),
                const SizedBox(height: 16),
                _buildSubtitle(),
                const Spacer(flex: 3),
                _buildGetStartedButton(context),
                const SizedBox(height: 16),
                _buildAccountButton(context),
                const Spacer(flex: 1),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Builds the app logo with shadow effect
  Widget _buildLogo() {
    return Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(
        color: AppColors.primaryBlue,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryBlue.withValues(alpha: 0.3),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Center(
        child: Text(
          'LOGO',
          style: GoogleFonts.openSans(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: AppColors.white,
            letterSpacing: 1.5,
          ),
        ),
      ),
    );
  }

  /// Builds the main app title using Quicksand font
  Widget _buildTitle() {
    return Text('EczeManage', style: AppTextStyles.headingQuicksand);
  }

  /// Builds the subtitle description text
  Widget _buildSubtitle() {
    return Text(
      'Your personal companion for\nmanaging eczema with confidence',
      textAlign: TextAlign.center,
      style: AppTextStyles.subtextOpenSans,
    );
  }

  /// Builds the primary "GET STARTED" button that navigates to the consent page
  ///
  /// This is the main call-to-action for new users who want to create an account.
  /// Uses elevated button style with primary brand colors and rounded corners.
  Widget _buildGetStartedButton(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: () {
          // Navigate to consent page for new user registration flow
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ConsentPage()),
          );
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryBlue,
          foregroundColor: AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(28),
          ),
          elevation: 0,
        ),
        child: Text('GET STARTED', style: AppTextStyles.buttonText),
      ),
    );
  }

  /// Builds the secondary "I HAVE AN ACCOUNT" button that navigates to the login page
  ///
  /// This is the secondary call-to-action for existing users who want to log in.
  /// Uses outlined button style to differentiate from primary action.
  Widget _buildAccountButton(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: OutlinedButton(
        onPressed: () {
          // Navigate to login page for existing user authentication
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const LoginPage()),
          );
        },
        style: OutlinedButton.styleFrom(
          side: BorderSide(
            color: AppColors.primaryBlue.withValues(alpha: 0.3),
            width: 2,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(28),
          ),
        ),
        child: Text(
          'I HAVE AN ACCOUNT',
          style: AppTextStyles.secondaryButtonText,
        ),
      ),
    );
  }
}
