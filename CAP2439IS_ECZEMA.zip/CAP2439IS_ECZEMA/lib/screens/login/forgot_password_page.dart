import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_services.dart';

class ForgotPasswordPage extends StatefulWidget {
  const ForgotPasswordPage({super.key});

  @override
  State<ForgotPasswordPage> createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
  final _emailController = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  final _authService = AuthService();
  final _firestoreService = FirestoreService();

  bool _isEmailVerified = false;
  bool _isLoading = false;
  bool _obscureNewPassword = true;
  bool _obscureConfirmPassword = true;
  String? _userId;

  @override
  void dispose() {
    _emailController.dispose();
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF474ED8),
      body: Stack(
        children: [
          // Purple background
          Container(
            width: double.infinity,
            height: double.infinity,
            color: const Color(0xFF474ED8),
          ),
          // Back button
          Positioned(
            top: MediaQuery.of(context).padding.top + 16,
            left: 16,
            child: _buildBackButton(),
          ),
          // White card
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            height: MediaQuery.of(context).size.height * 0.7,
            child: _buildForgotPasswordCard(),
          ),
        ],
      ),
    );
  }

  Widget _buildBackButton() {
    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.2),
          borderRadius: BorderRadius.circular(20),
        ),
        child: const Icon(
          Icons.arrow_back_ios_new,
          color: Colors.white,
          size: 20,
        ),
      ),
    );
  }

  Widget _buildForgotPasswordCard() {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(40),
          topRight: Radius.circular(40),
        ),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 48.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildTitle(),
            const SizedBox(height: 12),
            _buildSubtitle(),
            const SizedBox(height: 36),
            if (!_isEmailVerified) ...[
              _buildEmailField(),
              const SizedBox(height: 80),
              _buildVerifyButton(),
            ] else ...[
              _buildNewPasswordField(),
              const SizedBox(height: 20),
              _buildConfirmPasswordField(),
              const SizedBox(height: 80),
              _buildResetButton(),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTitle() {
    return Text(
      _isEmailVerified ? 'Reset Password' : 'Forgot Password',
      style: GoogleFonts.quicksand(
        fontSize: 40,
        fontWeight: FontWeight.bold,
        color: const Color(0xFF1E293B),
      ),
    );
  }

  Widget _buildSubtitle() {
    return Text(
      _isEmailVerified
          ? 'Enter your new password'
          : 'Enter your email to verify your account',
      style: GoogleFonts.openSans(
        fontSize: 14,
        color: const Color(0xFF6B7280),
      ),
    );
  }

  Widget _buildEmailField() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFDEE4FE).withValues(alpha: 0.8),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFDEE4FE), width: 1),
      ),
      child: TextField(
        controller: _emailController,
        keyboardType: TextInputType.emailAddress,
        decoration: InputDecoration(
          hintText: 'email',
          hintStyle: GoogleFonts.openSans(
            fontSize: 16,
            color: const Color(0xFF6478CE),
            fontWeight: FontWeight.w400,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 20,
            vertical: 18,
          ),
        ),
        style: GoogleFonts.openSans(
          fontSize: 16,
          color: const Color(0xFF1E293B),
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildNewPasswordField() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFDEE4FE).withValues(alpha: 0.8),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFDEE4FE), width: 1),
      ),
      child: TextField(
        controller: _newPasswordController,
        obscureText: _obscureNewPassword,
        decoration: InputDecoration(
          hintText: 'new password',
          hintStyle: GoogleFonts.openSans(
            fontSize: 16,
            color: const Color(0xFF6478CE),
            fontWeight: FontWeight.w400,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.only(
            left: 20,
            right: 8,
            top: 18,
            bottom: 18,
          ),
          suffixIcon: IconButton(
            icon: Icon(
              _obscureNewPassword
                  ? Icons.visibility_off_outlined
                  : Icons.visibility_outlined,
              color: const Color(0xFF6478CE),
              size: 22,
            ),
            onPressed: () {
              setState(() {
                _obscureNewPassword = !_obscureNewPassword;
              });
            },
          ),
        ),
        style: GoogleFonts.openSans(
          fontSize: 16,
          color: const Color(0xFF1E293B),
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildConfirmPasswordField() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFDEE4FE).withValues(alpha: 0.8),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFDEE4FE), width: 1),
      ),
      child: TextField(
        controller: _confirmPasswordController,
        obscureText: _obscureConfirmPassword,
        decoration: InputDecoration(
          hintText: 'confirm password',
          hintStyle: GoogleFonts.openSans(
            fontSize: 16,
            color: const Color(0xFF6478CE),
            fontWeight: FontWeight.w400,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.only(
            left: 20,
            right: 8,
            top: 18,
            bottom: 18,
          ),
          suffixIcon: IconButton(
            icon: Icon(
              _obscureConfirmPassword
                  ? Icons.visibility_off_outlined
                  : Icons.visibility_outlined,
              color: const Color(0xFF6478CE),
              size: 22,
            ),
            onPressed: () {
              setState(() {
                _obscureConfirmPassword = !_obscureConfirmPassword;
              });
            },
          ),
        ),
        style: GoogleFonts.openSans(
          fontSize: 16,
          color: const Color(0xFF1E293B),
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildVerifyButton() {
    return Center(
      child: SizedBox(
        width: 200,
        height: 56,
        child: ElevatedButton(
          onPressed: _isLoading ? null : _verifyEmail,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF474ED8),
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(28),
            ),
            elevation: 0,
          ),
          child: _isLoading
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
                )
              : Text(
                  'VERIFY',
                  style: GoogleFonts.openSans(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    letterSpacing: 0.5,
                  ),
                ),
        ),
      ),
    );
  }

  Widget _buildResetButton() {
    return Center(
      child: SizedBox(
        width: 200,
        height: 56,
        child: ElevatedButton(
          onPressed: _isLoading ? null : _resetPassword,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF474ED8),
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(28),
            ),
            elevation: 0,
          ),
          child: _isLoading
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
                )
              : Text(
                  'RESET PASSWORD',
                  style: GoogleFonts.openSans(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    letterSpacing: 0.5,
                  ),
                ),
        ),
      ),
    );
  }

  Future<void> _verifyEmail() async {
    final email = _emailController.text.trim();

    if (email.isEmpty) {
      _showErrorSnackBar('Please enter your email');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // Check if email exists in Firestore
      final userExists = await _authService.isEmailRegistered(email);

      if (!userExists) {
        // Check in test credentials
        final testCredential = await _authService.checkTestCredentials(email, '');
        if (testCredential == null) {
          _showErrorSnackBar('Email not found');
          setState(() {
            _isLoading = false;
          });
          return;
        }
        _userId = testCredential['userId'];
      } else {
        // Get user ID from Firestore by email
        final users = await _firestoreService.getUserByEmail(email);
        if (users == null) {
          _showErrorSnackBar('Email not found');
          setState(() {
            _isLoading = false;
          });
          return;
        }
        _userId = users.id;
      }

      setState(() {
        _isEmailVerified = true;
        _isLoading = false;
      });

      _showSuccessSnackBar('Email verified! Enter your new password');
    } catch (e) {
      _showErrorSnackBar('Error verifying email: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _resetPassword() async {
    final newPassword = _newPasswordController.text.trim();
    final confirmPassword = _confirmPasswordController.text.trim();

    if (newPassword.isEmpty || confirmPassword.isEmpty) {
      _showErrorSnackBar('Please fill in all fields');
      return;
    }

    if (newPassword != confirmPassword) {
      _showErrorSnackBar('Passwords do not match');
      return;
    }

    if (newPassword.length < 6) {
      _showErrorSnackBar('Password must be at least 6 characters');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // Update password in test credentials
      await _authService.updatePassword(_emailController.text.trim(), newPassword);

      if (mounted) {
        _showSuccessSnackBar('Password reset successful!');
        await Future.delayed(const Duration(seconds: 1));
        Navigator.pop(context);
      }
    } catch (e) {
      _showErrorSnackBar('Error resetting password: $e');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red.shade400,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green.shade400,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }
}
