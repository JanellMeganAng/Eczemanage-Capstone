import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../welcome/welcome_screen.dart';
import '../../services/auth_service.dart';
import '../../services/session_service.dart';
import '../dashboard/dashboard_screen.dart';
import 'forgot_password_page.dart';

/// LoginPage - User Authentication Screen
///
/// Provides login interface for existing users to access the app.
///
/// Features:
/// - Email/password input fields with validation
/// - "Remember Me" checkbox for persistent sessions
/// - Password visibility toggle
/// - Forgot password link
/// - Real-time error feedback for invalid credentials
/// - Loading state during authentication
///
/// Authentication Flow:
/// 1. Validates input fields are not empty
/// 2. Checks if email exists in database
/// 3. Verifies password matches stored credentials
/// 4. If "Remember Me" checked, saves session to local storage
/// 5. Navigates to Dashboard on successful login
///
/// Error Handling:
/// - Displays "Email not found" if email doesn't exist
/// - Displays "Wrong password" if password is incorrect
/// - Visual feedback via red borders on error fields
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _authService = AuthService();
  final _sessionService = SessionService();
  bool _rememberMe = false;
  bool _obscurePassword = true;
  bool _isLoading = false;

  // Error states
  bool _emailHasError = false;
  bool _passwordHasError = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF474ED8), // Purple background
      body: Stack(
        children: [
          // Purple background
          Container(
            width: double.infinity,
            height: double.infinity,
            color: const Color(
              0xFF474ED8,
            ), // Solid purple color matching design
          ),
          // White card extended higher
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            height:
                MediaQuery.of(context).size.height *
                0.7, // 70% of screen height
            child: _buildLoginCard(),
          ),
        ],
      ),
    );
  }

  /// Builds the main login card container
  Widget _buildLoginCard() {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(40),
          topRight: Radius.circular(40),
        ),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 48.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildLoginTitle(),
            const SizedBox(height: 36),
            _buildEmailField(),
            const SizedBox(height: 20),
            _buildPasswordField(),
            const SizedBox(height: 24),
            _buildOptionsRow(),
            const SizedBox(height: 80),
            _buildLoginButton(),
            const SizedBox(height: 24),
            _buildSignUpLink(),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  /// Builds the "Login" title
  Widget _buildLoginTitle() {
    return Text(
      'Login',
      style: GoogleFonts.quicksand(
        fontSize: 40,
        fontWeight: FontWeight.bold,
        color: const Color(0xFF1E293B), // Dark color for title
      ),
    );
  }

  /// Builds the email input field
  Widget _buildEmailField() {
    return Container(
      decoration: BoxDecoration(
        color: _emailHasError
            ? Colors.red.shade50
            : const Color(0xFFDEE4FE).withValues(alpha: 0.8),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _emailHasError ? Colors.red : const Color(0xFFDEE4FE),
          width: _emailHasError ? 2 : 1,
        ),
      ),
      child: TextField(
        controller: _emailController,
        onChanged: (_) {
          if (_emailHasError) {
            setState(() {
              _emailHasError = false;
            });
          }
        },
        decoration: InputDecoration(
          hintText: 'email',
          hintStyle: GoogleFonts.openSans(
            fontSize: 16,
            color: const Color(0xFF6478CE),
            fontWeight: FontWeight.w400,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 20,
            vertical: 18,
          ),
        ),
        style: GoogleFonts.openSans(
          fontSize: 16,
          color: const Color(0xFF1E293B),
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  /// Builds the password input field
  Widget _buildPasswordField() {
    return Container(
      decoration: BoxDecoration(
        color: _passwordHasError
            ? Colors.red.shade50
            : const Color(0xFFDEE4FE).withValues(alpha: 0.8),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _passwordHasError ? Colors.red : const Color(0xFFDEE4FE),
          width: _passwordHasError ? 2 : 1,
        ),
      ),
      child: TextField(
        controller: _passwordController,
        obscureText: _obscurePassword,
        onChanged: (_) {
          if (_passwordHasError) {
            setState(() {
              _passwordHasError = false;
            });
          }
        },
        decoration: InputDecoration(
          hintText: 'password',
          hintStyle: GoogleFonts.openSans(
            fontSize: 16,
            color: const Color(0xFF6478CE),
            fontWeight: FontWeight.w400,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.only(
            left: 20,
            right: 8,
            top: 18,
            bottom: 18,
          ),
          suffixIcon: IconButton(
            icon: Icon(
              _obscurePassword
                  ? Icons.visibility_off_outlined
                  : Icons.visibility_outlined,
              color: const Color(0xFF6478CE),
              size: 22,
            ),
            onPressed: () {
              setState(() {
                _obscurePassword = !_obscurePassword;
              });
            },
          ),
        ),
        style: GoogleFonts.openSans(
          fontSize: 16,
          color: const Color(0xFF1E293B),
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  /// Builds the row with "Remember Me?" checkbox and "Forgot Password?" link
  Widget _buildOptionsRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            SizedBox(
              width: 20,
              height: 20,
              child: Checkbox(
                value: _rememberMe,
                onChanged: (value) {
                  setState(() {
                    _rememberMe = value ?? false;
                  });
                },
                activeColor: const Color(0xFF474ED8), // Purple when checked
                checkColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
                side: const BorderSide(color: Color(0xFF9CA3AF), width: 1.5),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              'Remember Me?',
              style: GoogleFonts.openSans(
                fontSize: 14,
                color: const Color(0xFF6B7280),
                fontWeight: FontWeight.w400,
              ),
            ),
          ],
        ),
        TextButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const ForgotPasswordPage()),
            );
          },
          style: TextButton.styleFrom(
            padding: EdgeInsets.zero,
            minimumSize: Size.zero,
            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
          child: Text(
            'Forgot Password?',
            style: GoogleFonts.openSans(
              fontSize: 14,
              color: const Color(0xFF6B7280),
              fontWeight: FontWeight.w400,
            ),
          ),
        ),
      ],
    );
  }

  /// Builds the LOGIN button
  Widget _buildLoginButton() {
    return Center(
      child: SizedBox(
        width: 200,
        height: 56,
        child: ElevatedButton(
          onPressed: _isLoading ? null : _handleLogin,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(
              0xFF474ED8,
            ), // Purple button matching background
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(28),
            ),
            elevation: 0,
          ),
          child: _isLoading
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
                )
              : Text(
                  'LOGIN',
                  style: GoogleFonts.openSans(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    letterSpacing: 0.5,
                  ),
                ),
        ),
      ),
    );
  }

  /// Builds the "Don't have an Account? Sign-Up" link
  Widget _buildSignUpLink() {
    return Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Don't have an Account? ",
            style: GoogleFonts.openSans(
              fontSize: 14,
              color: const Color(0xFF9CA3AF),
              fontWeight: FontWeight.w400,
            ),
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const WelcomeScreen()),
              );
            },
            child: Text(
              'Sign-Up',
              style: GoogleFonts.openSans(
                fontSize: 14,
                color: const Color(0xFF6366F1), // Purple color for link
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Handles the login button press
  void _handleLogin() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    // Reset error states
    setState(() {
      _emailHasError = false;
      _passwordHasError = false;
    });

    if (email.isEmpty || password.isEmpty) {
      _showErrorSnackBar('Please fill in all fields');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // First check if email exists (without password validation)
      final emailExists = await _authService.isEmailRegistered(email);

      // Also check test credentials collection (just to see if email is there)
      final testCredentialDoc = await _authService.checkTestCredentials(email, '');

      if (!emailExists && testCredentialDoc == null) {
        // Email not found in either Firebase Auth or test credentials
        setState(() {
          _emailHasError = true;
          _isLoading = false;
        });
        _showErrorSnackBar('Email not found');
        return;
      }

      // Email exists, now try to login with password
      final user = await _authService.signInWithEmailAndPassword(email, password);

      if (user != null) {
        // Save session if "Remember Me" is checked
        if (_rememberMe) {
          await _sessionService.saveRememberMeSession(
            userId: user.uid,
            email: email,
          );
        }

        // Login successful - navigate to user's dashboard
        if (mounted) {
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => const DashboardScreen()),
            (route) => false,
          );
        }
      }
    } catch (e) {
      if (mounted) {
        // If we get here, email exists but password is wrong
        setState(() {
          _passwordHasError = true;
        });
        _showErrorSnackBar('Wrong password');
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  /// Shows error message in SnackBar
  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red.shade400,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  /// Shows success message in SnackBar
  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green.shade400,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }
}
