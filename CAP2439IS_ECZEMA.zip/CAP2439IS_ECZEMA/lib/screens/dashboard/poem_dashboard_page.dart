import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_styles.dart';
import '../../core/constants/app_button_styles.dart';
import '../../core/constants/app_header.dart';
import '../../core/constants/app_bottom_navigation.dart';
import '../../services/assessment_service.dart';
import 'poem_assessment_page.dart';
import 'poem_history_page.dart';

/// PoemDashboardPage - Main dashboard for POEM assessments
///
/// This screen serves as the central hub for the Patient-Oriented Eczema Measure (POEM)
/// assessments within the EczeManage application. It displays the user’s latest eczema
/// assessment results, progress, and available actions.
///
/// Key Features:
/// - Shows the most recent POEM assessment with severity level and score
/// - Indicates when the next assessment can be taken
/// - Provides quick access to start or retake assessments
/// - Includes navigation to view the full assessment history
/// - Uses color indicators to visually represent eczema severity
///
/// User Interactions:
/// - “TAKE ASSESSMENT” button: Starts a new POEM assessment
/// - “RETAKE ASSESSMENT” button: Allows reassessment after cooldown or for demo use
/// - “VIEW HISTORY” button: Opens past assessments for tracking progress
/// - Info icon: Displays details about the POEM questionnaire
///
/// Data Flow:
/// - Retrieves assessment data from AssessmentService (latest result, cooldown status)
/// - Updates UI dynamically when new assessments are completed

class PoemDashboardPage extends StatefulWidget {
  const PoemDashboardPage({Key? key}) : super(key: key);

  @override
  State<PoemDashboardPage> createState() => _PoemDashboardPageState();
}

class _PoemDashboardPageState extends State<PoemDashboardPage> {
  bool _canTakeAssessment = true;
  DateTime? _nextAvailableDate;
  Map<String, dynamic>? _latestAssessment;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _checkAssessmentStatus();
  }

  /// Checks if the user can take a new assessment and loads the latest data.
  Future<void> _checkAssessmentStatus() async {
    final canTake = await AssessmentService.canTakeAssessment();
    final nextDate = await AssessmentService.getNextAvailableDate();
    final latest = await AssessmentService.getLatestAssessment();

    setState(() {
      _canTakeAssessment = canTake;
      _nextAvailableDate = nextDate;
      _latestAssessment = latest;
      _isLoading = false;
    });
  }

  /// Formats the given [DateTime] into MM.DD.YYYY format.
  String _formatDate(DateTime date) {
    return "${date.month.toString().padLeft(2, '0')}.${date.day.toString()
        .padLeft(2, '0')}.${date.year}";
  }

  /// Returns severity level text based on the total POEM score.
  String _getSeverityLevel(int score) {
    if (score <= 2) return "Clear or almost clear";
    if (score <= 7) return "Mild eczema";
    if (score <= 16) return "Moderate eczema";
    if (score <= 24) return "Severe eczema";
    return "Very severe eczema";
  }

  /// Returns a color corresponding to the eczema severity score.
  Color _getSeverityColor(int score) {
    if (score <= 2) return Colors.green;
    if (score <= 7) return Colors.yellow.shade700;
    if (score <= 16) return Colors.orange;
    if (score <= 24) return Colors.red;
    return Colors.red.shade900;
  }

  /// Builds the main dashboard UI for viewing POEM status and results.
  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: AppColors.backgroundGradient,
          ),
          child: const Center(child: CircularProgressIndicator()),
        ),
      );
    }

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppColors.backgroundGradient,
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header bar
              AppHeader(
                title: "POEM Assessment",
                showMenu: true,
                showSync: true,
              ),

              // Scrollable main content
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Assessment Info Card
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: AppColors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.1),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  "POEM",
                                  style: AppTextStyles.headingQuicksand
                                      .copyWith(
                                    fontSize: 28,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                // Info icon button
                                GestureDetector(
                                  onTap: () => _showInfoDialog(),
                                  child: Container(
                                    width: 20,
                                    height: 20,
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          color: AppColors.primaryBlue),
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Center(
                                      child: Icon(
                                        Icons.info_outline,
                                        size: 12,
                                        color: AppColors.primaryBlue,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            Text(
                              "Track your eczema symptoms weekly with the Patient-Oriented Eczema Measure.",
                              style: AppTextStyles.subtextOpenSans.copyWith(
                                color: AppColors.greyText,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      // Latest Assessment Card
                      if (_latestAssessment != null) ...[
                        _buildLatestAssessmentCard(),
                        const SizedBox(height: 24),
                      ],

                      // Assessment Action Buttons
                      if (_canTakeAssessment)
                        _buildTakeAssessmentButton()
                      else
                        _buildRetakeSection(),

                      const SizedBox(height: 16),
                      // View History Button
                      _buildHistoryButton(),
                    ],
                  ),
                ),
              ),

              // Bottom Navigation Bar
              AppBottomNavigation(
                currentIndex: 0,
                onTap: (index) {},
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Builds the "Latest Assessment" display card.
  Widget _buildLatestAssessmentCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _getSeverityColor(_latestAssessment!['totalScore'])
              .withOpacity(0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Latest Assessment",
                style: AppTextStyles.subtextOpenSans.copyWith(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              Text(
                _formatDate(DateTime.parse(_latestAssessment!['date'])),
                style: AppTextStyles.subtextOpenSans.copyWith(
                  color: AppColors.greyText,
                  fontSize: 12,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              // Circular score indicator
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: _getSeverityColor(_latestAssessment!['totalScore'])
                      .withOpacity(0.1),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: _getSeverityColor(_latestAssessment!['totalScore']),
                    width: 2,
                  ),
                ),
                child: Center(
                  child: Text(
                    "${_latestAssessment!['totalScore']}",
                    style: AppTextStyles.headingQuicksand.copyWith(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: _getSeverityColor(
                          _latestAssessment!['totalScore']),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              // Score details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Score: ${_latestAssessment!['totalScore']}/28",
                      style: AppTextStyles.subtextOpenSans.copyWith(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: _getSeverityColor(
                            _latestAssessment!['totalScore']).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        _getSeverityLevel(_latestAssessment!['totalScore']),
                        style: AppTextStyles.subtextOpenSans.copyWith(
                          color: _getSeverityColor(
                              _latestAssessment!['totalScore']),
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Builds the primary "Take Assessment" button.
  Widget _buildTakeAssessmentButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const PoemAssessmentPage()),
          );
          if (result == true) _checkAssessmentStatus();
        },
        style: AppButtonStyles.primaryButton.copyWith(
          padding: MaterialStateProperty.all(
            const EdgeInsets.symmetric(vertical: 16),
          ),
        ),
        icon: const Icon(Icons.assessment),
        label: const Text("TAKE ASSESSMENT"),
      ),
    );
  }

  /// Builds the section showing the next available assessment date and retake option.
  Widget _buildRetakeSection() {
    return Column(
      children: [
        // Next available date info card
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.lightBlue.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.lightBlue.withOpacity(0.3)),
          ),
          child: Column(
            children: [
              Icon(Icons.schedule, color: AppColors.primaryBlue, size: 32),
              const SizedBox(height: 8),
              Text(
                "Next assessment available",
                style: AppTextStyles.subtextOpenSans.copyWith(
                  color: AppColors.primaryBlue,
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (_nextAvailableDate != null)
                Text(
                  _formatDate(_nextAvailableDate!),
                  style: AppTextStyles.headingQuicksand.copyWith(
                    color: AppColors.primaryBlue,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        // Retake button

        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const PoemAssessmentPage()),
              ).then((_) => _checkAssessmentStatus());
            },
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: AppColors.primaryBlue),
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
            icon: Icon(Icons.refresh, color: AppColors.primaryBlue),
            label: Text(
              "RETAKE ASSESSMENT",
              style: TextStyle(color: AppColors.primaryBlue),
            ),
          ),
        ),
      ],
    );
  }

  /// Builds the "View History" button to open past assessments.
  Widget _buildHistoryButton() {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const PoemHistoryPage()),
          );
        },
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: AppColors.greyText),
          padding: const EdgeInsets.symmetric(vertical: 16),
        ),
        icon: Icon(Icons.history, color: AppColors.greyText),
        label: Text(
          "VIEW HISTORY",
          style: TextStyle(color: AppColors.greyText),
        ),
      ),
    );
  }

  /// Displays an info dialog explaining what the POEM assessment is.
  void _showInfoDialog() {
    showDialog(
      context: context,
      builder: (context) =>
          AlertDialog(
            title: const Text("What is POEM?"),
            content: Text(
              "The Patient-Oriented Eczema Measure (POEM) is a questionnaire used "
                  "to assess eczema severity based on symptoms over the past week. "
                  "It helps track treatment progress and supports communication with healthcare providers.",
              style: AppTextStyles.subtextOpenSans.copyWith(
                color: AppColors.greyText,
                height: 1.5,
              ),
              textAlign: TextAlign.justify,
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  "Close",
                  style: AppTextStyles.subtextOpenSans.copyWith(
                    color: AppColors.primaryBlue,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
    );
  }
}