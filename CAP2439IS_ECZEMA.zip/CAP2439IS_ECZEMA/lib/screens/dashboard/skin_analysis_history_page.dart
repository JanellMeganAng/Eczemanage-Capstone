import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_header.dart';
import '../../core/constants/app_bottom_navigation.dart';
import 'dart:math' as math;

/// SkinAnalysisHistoryPage - Displays a list of past EASI skin assessments
///
/// This screen serves as a historical log of all Eczema Area and Severity Index (EASI)
/// analyses that the user has completed. Each record shows the date, affected body part,
/// severity level, total score, and model confidence level. Users can tap on an entry to
/// view detailed factor breakdowns for that specific case.
///
/// Key Features:
/// - Displays scrollable list of previous EASI analysis results
/// - Allows filtering by body region and specific body parts
/// - Provides color-coded severity indicators (Clear, Mild, Moderate, Severe)
/// - Opens a detailed case dialog showing factor scores and descriptions
/// - Includes top navigation (AppHeader) and bottom navigation (AppBottomNavigation)
///
/// User Interactions:
/// - Tap filter chips to view cases for specific regions
/// - Tap a history card’s "View Case" button to see case details in a popup dialog
/// - Use AppHeader for navigation or data synchronization
///
/// Data Flow:
/// - Supports filtering and sub-filtering of displayed results
/// - Displays detailed factor breakdowns in modal dialogs

final Map<String, List<String>> bodyPartCategories = {
  'Head & Face': ['Forehead', 'Left Cheek', 'Right Cheek', 'Chin', 'Nose'],
  'Neck & Shoulders': ['Front Neck', 'Back Neck', 'Left Shoulder', 'Right Shoulder'],
  'Arms & Hands': ['Left Arm', 'Right Arm', 'Left Hand', 'Right Hand'],
  'Torso': ['Chest', 'Back', 'Abdomen'],
  'Hips & Groin': ['Hip', 'Groin'],
  'Legs & Feet': ['Left Leg', 'Right Leg', 'Left Foot', 'Right Foot'],
};

// Factor descriptions for user understanding
final Map<String, String> factorDescriptions = {
  'Erythema': 'Redness',
  'Induration/Papulation': 'Swelling/ Bumps',
  'Excoriation': 'Scratching Damage',
  'Lichenification': 'Skin Thickening',
};

class SkinAnalysisHistoryPage extends StatefulWidget {
  const SkinAnalysisHistoryPage({Key? key}) : super(key: key);

  @override
  State<SkinAnalysisHistoryPage> createState() => _SkinAnalysisHistoryPageState();
}

class _SkinAnalysisHistoryPageState extends State<SkinAnalysisHistoryPage> {
  String selectedFilter = 'All';
  String? selectedSubFilter;

  final List<String> filters = [
    'All',
    'Head & Face',
    'Neck & Shoulders',
    'Arms & Hands',
    'Torso',
    'Hips & Groin',
    'Legs & Feet',
  ];

  final List<Map<String, dynamic>> historyData = [
    {
      'date': 'Sept 23, 2025 (10:00 AM)',
      'severity': 'Moderate',
      'bodyPart': 'Left Arm',
      'totalScore': 6,
      'confidence': '94%',
      'factors': [
        {'name': 'Erythema', 'score': 2},
        {'name': 'Induration/Papulation', 'score': 3},
        {'name': 'Excoriation', 'score': 0},
        {'name': 'Lichenification', 'score': 1},
      ],
    },
    {
      'date': 'Sept 20, 2025 (03:00 PM)',
      'severity': 'Clear',
      'bodyPart': 'Right Cheek',
      'totalScore': 2,
      'confidence': '89%',
      'factors': [
        {'name': 'Erythema', 'score': 1},
        {'name': 'Induration/Papulation', 'score': 1},
        {'name': 'Excoriation', 'score': 0},
        {'name': 'Lichenification', 'score': 0},
      ],
    },
    {
      'date': 'Sept 18, 2025 (08:30 AM)',
      'severity': 'Severe',
      'bodyPart': 'Back',
      'totalScore': 9,
      'confidence': '96%',
      'factors': [
        {'name': 'Erythema', 'score': 3},
        {'name': 'Induration/Papulation', 'score': 3},
        {'name': 'Excoriation', 'score': 1},
        {'name': 'Lichenification', 'score': 2},
      ],
    },
  ];

  void _showCaseDetailsDialog(BuildContext context, Map<String, dynamic> caseData) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Container(
            width: MediaQuery.of(context).size.width * 0.9,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: AppColors.backgroundGradient,
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              "CASE DETAILS",
                              style: GoogleFonts.quicksand(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: AppColors.primaryBlue,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              caseData['date'],
                              style: GoogleFonts.openSans(
                                fontSize: 12,
                                color: AppColors.greyText,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 24),

                  // Total EASI Score Card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Total EASI Score",
                                  style: GoogleFonts.openSans(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.darkBlue,
                                  ),
                                ),
                                Text(
                                  "Body Part: ${caseData['bodyPart']}",
                                  style: GoogleFonts.openSans(
                                    fontSize: 12,
                                    color: AppColors.greyText,
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              decoration: BoxDecoration(
                                color: _getSeverityColorFromLabel(caseData['severity']).withOpacity(0.1),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                "${caseData['totalScore']}/12",
                                style: GoogleFonts.quicksand(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                  color: _getSeverityColorFromLabel(caseData['severity']),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: _getSeverityColorFromLabel(caseData['severity']).withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                "${caseData['severity']} Severity",
                                style: GoogleFonts.openSans(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: _getSeverityColorFromLabel(caseData['severity']),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Factors Breakdown
                  Text(
                    "EASI Factors Breakdown",
                    style: GoogleFonts.openSans(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: AppColors.darkBlue,
                    ),
                  ),

                  const SizedBox(height: 12),

                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        ...caseData['factors'].map<Widget>((factor) => Padding(
                          padding: const EdgeInsets.only(bottom: 16),
                          child: _buildFactorRow(factor),
                        )).toList(),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Close Button
                  SizedBox(
                    width: double.infinity,
                    height: 44,
                    child: ElevatedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primaryBlue,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
                      ),
                      child: Text(
                        'Close',
                        style: GoogleFonts.openSans(fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildFactorRow(Map<String, dynamic> factor) {
    final factorName = factor['name'] as String;
    final description = factorDescriptions[factorName] ?? '';

    return Row(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: _getFactorColor(factor['score']).withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Center(
            child: Icon(
              _getFactorIcon(factor['name']),
              color: _getFactorColor(factor['score']),
              size: 20,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                factorName,
                style: GoogleFonts.openSans(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppColors.darkBlue,
                ),
              ),
              if (description.isNotEmpty) ...[
                const SizedBox(height: 2),
                Text(
                  description,
                  style: GoogleFonts.openSans(
                    fontSize: 12,
                    color: AppColors.greyText,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
              const SizedBox(height: 4),
              Container(
                height: 6,
                decoration: BoxDecoration(
                  color: AppColors.lightGrey,
                  borderRadius: BorderRadius.circular(3),
                ),
                child: FractionallySizedBox(
                  alignment: Alignment.centerLeft,
                  widthFactor: factor['score'] / 3,
                  child: Container(
                    decoration: BoxDecoration(
                      color: _getFactorColor(factor['score']),
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: _getFactorColor(factor['score']).withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            "${factor['score']}/3",
            style: GoogleFonts.quicksand(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: _getFactorColor(factor['score']),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final filteredHistory = historyData.where((item) {
      final bodyPart = item['bodyPart'] as String;

      if (selectedFilter == 'All') return true;

      if (selectedSubFilter != null) {
        return bodyPart == selectedSubFilter;
      }

      final parts = bodyPartCategories[selectedFilter] ?? [];
      return parts.contains(bodyPart);
    }).toList();

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppColors.backgroundGradient,
        ),
        child: SafeArea(
          child: Column(
            children: [
              AppHeader(
                title: "EASI History",
                showMenu: true,
                showSync: true,
              ),

              Container(
                height: 50,
                margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: filters.length,
                  itemBuilder: (context, index) {
                    final filter = filters[index];
                    final isSelected = selectedFilter == filter;

                    return Padding(
                      padding: const EdgeInsets.only(right: 12),
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            selectedFilter = filter;
                            selectedSubFilter = null;
                          });
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? AppColors.primaryBlue
                                : AppColors.lightBlue.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(25),
                          ),
                          child: Text(
                            filter,
                            style: GoogleFonts.openSans(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: isSelected ? Colors.white : AppColors.primaryBlue,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),

              if (selectedFilter != 'All')
                Container(
                  height: 40,
                  margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: bodyPartCategories[selectedFilter]?.length ?? 0,
                    itemBuilder: (context, index) {
                      final subFilter = bodyPartCategories[selectedFilter]![index];
                      final isSelected = selectedSubFilter == subFilter;

                      return Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              selectedSubFilter = subFilter;
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? AppColors.primaryBlue
                                  : AppColors.lightBlue.withOpacity(0.3),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              subFilter,
                              style: GoogleFonts.openSans(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: isSelected ? Colors.white : AppColors.primaryBlue,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),

              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  itemCount: filteredHistory.length,
                  itemBuilder: (context, index) {
                    final item = filteredHistory[index];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: _buildHistoryCard(item),
                    );
                  },
                ),
              ),
              AppBottomNavigation(
                currentIndex: 0,
                onTap: (index) {},
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHistoryCard(Map<String, dynamic> item) {
    final severity = item['severity'] as String;
    final Color severityColor = _getSeverityColorFromLabel(severity);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.calendar_today,
                  color: AppColors.primaryBlue,
                  size: 16,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  item['date'],
                  style: GoogleFonts.openSans(
                    fontSize: 12,
                    color: AppColors.greyText,
                  ),
                ),
              ),
              GestureDetector(
                onTap: () => _showCaseDetailsDialog(context, item),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppColors.primaryBlue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    "View Case",
                    style: GoogleFonts.openSans(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppColors.primaryBlue,
                    ),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          Row(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: severityColor.withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    "${item['totalScore']}",
                    style: GoogleFonts.quicksand(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: severityColor,
                    ),
                  ),
                ),
              ),

              const SizedBox(width: 16),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "EASI Score: ${item['totalScore']}/12 ($severity)",
                      style: GoogleFonts.openSans(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: AppColors.darkBlue,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "Body Part: ${item['bodyPart']}",
                      style: GoogleFonts.openSans(
                        fontSize: 12,
                        color: AppColors.greyText,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "Analysis Confidence: ${item['confidence']}",
                      style: GoogleFonts.openSans(
                        fontSize: 12,
                        color: AppColors.greyText,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Color _getSeverityColorFromLabel(String severity) {
    switch (severity.toLowerCase()) {
      case 'mild':
      case 'clear':
        return Colors.green;
      case 'moderate':
        return Colors.orange;
      case 'severe':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  Color _getFactorColor(int score) {
    if (score == 0) return Colors.green;
    if (score == 1) return Colors.yellow.shade700;
    if (score == 2) return Colors.orange;
    return Colors.red;
  }

  IconData _getFactorIcon(String factorName) {
    switch (factorName.toLowerCase()) {
      case 'erythema':
        return Icons.circle;
      case 'induration/papulation':
        return Icons.bubble_chart;
      case 'excoriation':
        return Icons.gesture;
      case 'lichenification':
        return Icons.texture;
      default:
        return Icons.assessment;
    }
  }
}

class CaseFactorsBarPainter extends CustomPainter {
  final List<Map<String, dynamic>> factors;

  CaseFactorsBarPainter({required this.factors});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();
    final barWidth = (size.width - (factors.length - 1) * 12) / factors.length;
    final maxScore = 3;

    for (int i = 0; i < factors.length; i++) {
      final factor = factors[i];
      final score = factor['score'];
      final barHeight = (score / maxScore) * size.height;

      final x = i * (barWidth + 12);

      // Background bar
      paint.color = Colors.grey.shade200;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, 0, barWidth, size.height),
          const Radius.circular(6),
        ),
        paint,
      );

      // Score bar
      paint.color = _getFactorColor(score);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, size.height - barHeight, barWidth, barHeight),
          const Radius.circular(6),
        ),
        paint,
      );
    }
  }

  Color _getFactorColor(int score) {
    if (score == 0) return Colors.green;
    if (score == 1) return Colors.yellow.shade700;
    if (score == 2) return Colors.orange;
    return Colors.red;
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}