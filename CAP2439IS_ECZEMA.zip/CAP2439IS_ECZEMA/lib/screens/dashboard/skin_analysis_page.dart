import 'package:cap2439is_eczema/screens/dashboard/skin_analysis_history_page.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_header.dart';
import '../../core/constants/app_bottom_navigation.dart';
import 'dart:math' as math;
import 'manual_easi_page.dart';
import 'skin_analysis_results_page.dart';

/// SkinAnalysisPage - AI-powered eczema skin assessment workflow
///
/// This screen allows users to perform an AI-assisted skin analysis to monitor eczema symptoms
/// on specific body parts. It provides a guided, multi-step process where users can select a
/// body region, capture or upload an image of the affected area, and view their results after
/// automated analysis. The page combines interactive animations, categorized body part selection,
/// and photo capture features to provide a smooth, informative assessment experience.
///
/// Key Features:
/// - Multi-step guided flow (select body part → capture/upload photo → confirm analysis)
/// - Categorized and searchable body part selection with collapsible sections
/// - Integrated camera and gallery picker for image capture or upload
/// - Animated transitions for a smooth user experience
/// - Informational dialog explaining the AI-powered skin analysis feature
/// - Access to history and manual EASI scoring via dedicated buttons
///
/// User Interactions:
/// - Select a body part: Proceeds automatically to the next step
/// - Capture/Upload photo: Opens camera or file picker to acquire an image
/// - Tap info icon: Displays an educational dialog explaining the analysis feature
/// - View History: Opens SkinAnalysisHistoryPage showing previous analyses
/// - Manual Calculate EASI: Opens ManualEASIPage for manual eczema severity scoring
/// - View Results: Navigates to SkinAnalysisResultsPage showing processed AI insights
/// - Analyze Again: Resets the flow and returns to the first step
///
/// Data Flow:
/// - Body part selections are managed locally within the state
/// - Images are acquired via ImagePicker (camera or gallery)
/// - Selected data (body part + image) is passed to SkinAnalysisResultsPage
/// - Search field dynamically filters body parts for quick access
///
/// Validation:
/// - Prevents navigation to result view unless both a body part and image are selected
/// - Requires valid image input from camera or gallery before proceeding
/// - Ensures search input dynamically updates results (case-insensitive)
/// - Validates UI state transitions for consistent step progression
/// - Uses stateful logic to prevent null data from causing navigation errors

class SkinAnalysisPage extends StatefulWidget {
  const SkinAnalysisPage({Key? key}) : super(key: key);

  @override
  State<SkinAnalysisPage> createState() => _SkinAnalysisPageState();
}

class _SkinAnalysisPageState extends State<SkinAnalysisPage>
    with TickerProviderStateMixin {
  final PageController _pageController = PageController();
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  // Animation controllers
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // State variables
  int _currentStep = 0;
  String? _selectedBodyPart;
  File? _selectedImage;
  int? _severityRating;
  bool _isSearching = false;
  List<String> _searchResults = [];
  final Map<String, bool> _expandedCategories = {};

  // Body parts data (same as your existing code)
  final Map<String, List<String>> bodyPartCategories = {
    'Head & Face': [
      'Head', 'Forehead', 'Left Cheek', 'Right Cheek',
      'Nose', 'Lips', 'Chin',
    ],
    'Neck & Shoulders': ['Neck', 'Left Shoulder', 'Right Shoulder'],
    'Arms & Hands': [
      'Left Arm', 'Right Arm', 'Left Elbow', 'Right Elbow',
      'Left Forearm', 'Right Forearm', 'Left Hand', 'Right Hand',
      'Left Wrist', 'Right Wrist', 'Fingers',
    ],
    'Torso': [
      'Chest', 'Back', 'Upper Back', 'Lower Back',
      'Abdomen', 'Stomach', 'Waist',
    ],
    'Hips & Groin': ['Left Hip', 'Right Hip', 'Groin'],
    'Legs & Feet': [
      'Left Thigh', 'Right Thigh', 'Left Knee', 'Right Knee',
      'Left Shin', 'Right Shin', 'Left Calf', 'Right Calf',
      'Left Ankle', 'Right Ankle', 'Left Foot', 'Right Foot', 'Toes',
    ],
  };

  List<String> get allBodyParts {
    return bodyPartCategories.values.expand((parts) => parts).toList();
  }

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));

    // Initialize categories as collapsed
    for (String category in bodyPartCategories.keys) {
      _expandedCategories[category] = false;
    }

    _searchController.addListener(_onSearchChanged);
    _fadeController.forward();
    _slideController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _pageController.dispose();
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    setState(() {
      if (_searchController.text.isEmpty) {
        _isSearching = false;
        _searchResults = [];
      } else {
        _isSearching = true;
        _searchResults = allBodyParts
            .where((part) =>
            part.toLowerCase().contains(
              _searchController.text.toLowerCase(),
            ))
            .toList();
      }
    });
  }

  void _nextStep() {
    if (_currentStep < 2) {
      setState(() {
        _currentStep++;
      });
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
      _slideController.reset();
      _slideController.forward();
    }
  }

  void _selectBodyPart(String bodyPart) {
    setState(() {
      _selectedBodyPart = bodyPart;
    });
    Future.delayed(const Duration(milliseconds: 500), () {
      _nextStep();
    });
  }

  Future<void> _takePicture() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(
      source: ImageSource.camera,
      maxWidth: 1800,
      maxHeight: 1800,
    );

    if (image != null) {
      setState(() {
        _selectedImage = File(image.path);
      });
      _nextStep();
    }
  }

  Future<void> _uploadImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 1800,
      maxHeight: 1800,
    );

    if (image != null) {
      setState(() {
        _selectedImage = File(image.path);
      });
      _nextStep();
    }
  }

  void _selectSeverity(int rating) {
    setState(() {
      _severityRating = rating;
    });
  }

  void _submitAnalysis() {
    // Navigate to results page
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            SkinAnalysisResultsPage(
              bodyPart: _selectedBodyPart!,
              image: _selectedImage!,
            ),
      ),
    );
  }

  void _showInfoDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: AppColors.backgroundGradient,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Removed the circular white background
                Icon(
                  Icons.analytics,
                  color: AppColors.primaryBlue,
                  size: 32,
                ),
                const SizedBox(height: 16),
                Text(
                  "SKIN ANALYSIS",
                  style: GoogleFonts.quicksand(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primaryBlue,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  "Use our AI-powered skin analysis tool to track your eczema symptoms over time. Simply select the affected area, take a photo, and rate your symptoms to get detailed insights about your condition.",
                  style: GoogleFonts.openSans(
                    fontSize: 14,
                    color: AppColors.darkBlue,
                    height: 1.5,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.orange.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.orange.withOpacity(0.3),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.warning_amber_rounded,
                        color: Colors.orange,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          "This tool is not a substitute for professional medical advice. Always consult your healthcare provider.",
                          style: GoogleFonts.openSans(
                            fontSize: 12,
                            color: Colors.orange.shade700,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  height: 44,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryBlue,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(22),
                      ),
                    ),
                    child: Text(
                      'Got it',
                      style: GoogleFonts.openSans(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _analyzeAgain() {
    setState(() {
      _currentStep = 0;
      _selectedBodyPart = null;
      _selectedImage = null;
      _severityRating = null;
    });
    _pageController.animateToPage(
      0,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppColors.backgroundGradient,
        ),
        child: SafeArea(
          child: Stack(
            children: [
              Column(
                children: [
                  AppHeader(
                    title: "Skin Analysis",
                    showMenu: true,
                    showSync: true,
                  ),
                  Expanded(
                    child: PageView(
                      controller: _pageController,
                      physics: const NeverScrollableScrollPhysics(),
                      children: [
                        _buildBodyPartSelection(),
                        _buildPhotoCapture(),
                        _buildAnalysisComplete(),
                      ],
                    ),
                  ),
                  AppBottomNavigation(
                    currentIndex: 0,
                    onTap: (index) {},
                  ),
                ],
              ),
              Positioned(
                top: 16,
                right: 110,
                child: GestureDetector(
                  onTap: _showInfoDialog,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    child: Icon(
                      Icons.info_outline,
                      color: AppColors.primaryBlue,
                      size: 20,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBodyPartSelection() {
    return SlideTransition(
      position: _slideAnimation,
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildChatHeader(
                "Select the region of the body for this analysis",
                Icons.accessibility_new,
              ),
              const SizedBox(height: 20),
              Expanded(
                child: Column(
                  children: [
                    _buildSearchBar(),
                    const SizedBox(height: 16),
                    Expanded(child: _buildBodyPartsList()),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Action buttons
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const SkinAnalysisHistoryPage(),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryBlue,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(26),
                    ),
                  ),
                  icon: const Icon(Icons.history),
                  label: Text(
                    'View History',
                    style: GoogleFonts.openSans(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),

              // New Manual Calculate EASI button
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                        const ManualEASIPage(),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.lightBlue,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(26),
                    ),
                  ),
                  icon: const Icon(Icons.calculate),
                  label: Text(
                    'Manual Calculate EASI',
                    style: GoogleFonts.openSans(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTip(String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("• ",
              style: TextStyle(fontSize: 14, color: Colors.black87)),
          Expanded(
            child: Text(
              text,
              style: GoogleFonts.openSans(
                fontSize: 13,
                color: AppColors.greyText,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }


  Widget _buildPhotoCapture() {
    return SlideTransition(
      position: _slideAnimation,
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            _buildChatHeader(
              "Capture Eczema",
              Icons.camera_alt,
            ),
            const SizedBox(height: 12),
            _buildSelectedBodyPartChip(),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Text(
                    "Take a clear photo of the affected skin area for AI analysis and tracking.",
                    style: GoogleFonts.openSans(
                      fontSize: 14,
                      color: AppColors.darkBlue,
                      height: 1.5,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  Container(
                    padding: const EdgeInsets.all(16),
                    margin: const EdgeInsets.only(top: 16),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.info, color: Colors.blue, size: 20),
                            const SizedBox(width: 8),
                            Text(
                              "Tips for Best Results",
                              style: GoogleFonts.openSans(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: AppColors.darkBlue,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        _buildTip("Make sure the photo is clear and in focus."),
                        _buildTip("Use a neutral, plain background if possible."),
                        _buildTip("Ensure good lighting (natural light is best)."),
                        _buildTip("Keep the affected area centered in the frame."),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton.icon(
                      onPressed: _takePicture,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primaryBlue,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(26),
                        ),
                      ),
                      icon: const Icon(Icons.camera_alt),
                      label: Text(
                        'Take a Photo',
                        style: GoogleFonts.openSans(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton.icon(
                      onPressed: _uploadImage,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.lightBlue,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(26),
                        ),
                      ),
                      icon: const Icon(Icons.upload),
                      label: Text(
                        'Upload an Image',
                        style: GoogleFonts.openSans(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const Spacer(),
            Align(
              alignment: Alignment.centerLeft,
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => const SkinAnalysisPage()),
                        (route) => false, // removes all previous routes
                  );
                },
                icon: const Icon(Icons.arrow_back),
                label: const Text("Back"),
              ),
            )
          ],
        ),
      ),
    );
  }


  Widget _buildAnalysisComplete() {
    return SlideTransition(
      position: _slideAnimation,
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const Spacer(),
            Container(
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.check_circle_outline,
                      color: Colors.green,
                      size: 48,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    "Your Analysis is Complete!",
                    style: GoogleFonts.quicksand(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: AppColors.darkBlue,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Your skin analysis has been processed and your results are ready to view.",
                    style: GoogleFonts.openSans(
                      fontSize: 14,
                      color: AppColors.greyText,
                      height: 1.5,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: _submitAnalysis,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(26),
                  ),
                ),
                icon: const Icon(Icons.visibility),
                label: Text(
                  'View Results',
                  style: GoogleFonts.openSans(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: _analyzeAgain,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryBlue,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(26),
                  ),
                ),
                icon: const Icon(Icons.refresh),
                label: Text(
                  'Analyze Again',
                  style: GoogleFonts.openSans(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const Spacer(),
          ],
        ),
      ),
    );
  }

  Widget _buildChatHeader(String title, IconData icon) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.primaryBlue,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            color: Colors.white,
            size: 24,
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: GoogleFonts.quicksand(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildSelectedBodyPartChip() {
    if (_selectedBodyPart == null) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.primaryBlue.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.primaryBlue.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            "You have selected the: ",
            style: GoogleFonts.openSans(
              fontSize: 14,
              color: AppColors.greyText,
            ),
          ),
          Text(
            _selectedBodyPart!.toUpperCase(),
            style: GoogleFonts.openSans(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: AppColors.primaryBlue,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.lightGrey,
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextField(
        controller: _searchController,
        style: GoogleFonts.openSans(fontSize: 16, color: AppColors.darkBlue),
        decoration: InputDecoration(
          hintText: 'Search body parts...',
          hintStyle: GoogleFonts.openSans(
            fontSize: 16,
            color: AppColors.greyText,
          ),
          prefixIcon: const Icon(Icons.search, color: AppColors.greyText),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 14,
          ),
        ),
      ),
    );
  }

  Widget _buildBodyPartsList() {
    if (_isSearching) {
      return _buildSearchResults();
    }

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.lightGrey, width: 1),
      ),
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: bodyPartCategories.length,
        separatorBuilder: (context, index) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final category = bodyPartCategories.keys.elementAt(index);
          final parts = bodyPartCategories[category]!;
          final isExpanded = _expandedCategories[category] ?? false;

          return Container(
            decoration: BoxDecoration(
              color: AppColors.lightGrey,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                GestureDetector(
                  onTap: () {
                    setState(() {
                      _expandedCategories[category] = !isExpanded;
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isExpanded
                          ? AppColors.primaryBlue.withOpacity(0.1)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: [
                        _buildCategoryIcon(category),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            category,
                            style: GoogleFonts.quicksand(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: AppColors.darkBlue,
                            ),
                          ),
                        ),
                        Icon(
                          isExpanded ? Icons.expand_less : Icons.expand_more,
                          color: AppColors.primaryBlue,
                        ),
                      ],
                    ),
                  ),
                ),
                if (isExpanded) ...[
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: parts.map((part) {
                        return GestureDetector(
                          onTap: () => _selectBodyPart(part),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 8,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: AppColors.primaryBlue,
                                width: 1.5,
                              ),
                            ),
                            child: Text(
                              part,
                              style: GoogleFonts.openSans(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: AppColors.primaryBlue,
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildSearchResults() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.lightGrey,
        borderRadius: BorderRadius.circular(16),
      ),
      child: _searchResults.isEmpty
          ? _buildNoResultsMessage()
          : Padding(
        padding: const EdgeInsets.all(16),
        child: GridView.builder(
          itemCount: _searchResults.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 3.5,
          ),
          itemBuilder: (context, index) {
            final bodyPart = _searchResults[index];
            return GestureDetector(
              onTap: () => _selectBodyPart(bodyPart),
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: AppColors.primaryBlue,
                    width: 1.5,
                  ),
                ),
                child: Center(
                  child: Text(
                    bodyPart,
                    style: GoogleFonts.openSans(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: AppColors.primaryBlue,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildCategoryIcon(String category) {
    String? iconPath = _getCustomIconPath(category);

    if (iconPath != null) {
      return Container(
        width: 24,
        height: 24,
        child: Image.asset(
          iconPath,
          width: 24,
          height: 24,
          color: AppColors.primaryBlue,
          fit: BoxFit.contain,
        ),
      );
    }

    return Icon(
      _getCategoryIcon(category),
      color: AppColors.primaryBlue,
      size: 24,
    );
  }

  String? _getCustomIconPath(String category) {
    switch (category) {
      case 'Head & Face':
        return 'assets/icons/head.png';
      case 'Neck & Shoulders':
        return 'assets/icons/neckandshoulders.png';
      case 'Arms & Hands':
        return 'assets/icons/hands.png';
      case 'Torso':
        return 'assets/icons/torso.png';
      case 'Hips & Groin':
        return 'assets/icons/hips.png';
      case 'Legs & Feet':
        return 'assets/icons/legs.png';
      default:
        return null;
    }
  }


  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Head & Face':
        return Icons.face_rounded;
      case 'Neck & Shoulders':
        return Icons.accessibility;
      case 'Arms & Hands':
        return Icons.front_hand;
      case 'Torso':
        return Icons.radio_button_unchecked;
      case 'Hips & Groin':
        return Icons.crop_landscape;
      case 'Legs & Feet':
        return Icons.nordic_walking;
      default:
        return Icons.radio_button_unchecked;
    }
  }

  Widget _buildNoResultsMessage() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search_off,
              size: 64,
              color: AppColors.greyText.withOpacity(0.5),
            ),
            const SizedBox(height: 16),
            Text(
              'No body parts found',
              style: GoogleFonts.openSans(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: AppColors.greyText,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSeveritySlider() {
    return Column(
      children: [
        // Numbers row
        Row(
          children: List.generate(11, (index) {
            return Expanded(
              child: Text(
                '$index',
                textAlign: TextAlign.center,
                style: GoogleFonts.openSans(
                  fontSize: 12,
                  color: AppColors.greyText,
                  fontWeight: FontWeight.w500,
                ),
              ),
            );
          }),
        ),

        // Slider
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            activeTrackColor: AppColors.primaryBlue,
            inactiveTrackColor: AppColors.lightGrey,
            thumbColor: AppColors.primaryBlue,
            trackHeight: 4,
            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
          ),
          child: Slider(
            value: (_severityRating ?? 0).toDouble(),
            min: 0,
            max: 10,
            divisions: 10,
            onChanged: (value) {
              _selectSeverity(value.round());
            },
          ),
        ),

        const SizedBox(height: 8),

        // Labels + current value
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'No itch',
              style: GoogleFonts.openSans(
                fontSize: 10,
                color: AppColors.greyText,
              ),
            ),
            if (_severityRating != null)
              Container(
                padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.primaryBlue,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '$_severityRating',
                  style: GoogleFonts.openSans(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            Text(
              'Worst possible itch',
              style: GoogleFonts.openSans(
                fontSize: 10,
                color: AppColors.greyText,
              ),
            ),
          ],
        ),
      ],
    );
  }
}