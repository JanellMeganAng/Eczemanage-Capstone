import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_bottom_navigation.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_header.dart';
import '../../models/weather_model.dart';

/// WeatherPage - Displays weather conditions and their impact on eczema.
///
/// This screen provides real-time (or mock) weather data that helps users
/// understand how current environmental conditions—such as humidity, UV index,
/// and temperature—affect their eczema. It also includes eczema risk levels,
/// environmental triggers, and a location search dialog for changing the displayed city.
///
/// Key Features:
/// - Displays local weather metrics: temperature, humidity, UV index, and wind speed.
/// - Highlights eczema risk level and provides actionable insights.
/// - Lists environmental triggers (humidity, UV exposure, air quality, etc.).
/// - Allows user to change location via searchable city list.
/// - Includes header sync button and bottom navigation for navigation consistency.
///
/// User Interactions:
/// - Tap “Change Location” → opens a searchable dialog with Philippine cities.
/// - Tap “Sync” → triggers a mock weather data refresh action.
/// - Search bar dynamically filters city list by name, province, or region.
/// - Selecting a city updates the displayed location.
///
/// Data Flow:
/// - Uses internal state to store and update location and search query.
///
/// Validation:
/// - Input handling for search text (clears input dynamically).
/// - Ensures that search, selection, and dialogs maintain UI stability.
/// - Prepared for integration with real weather APIs (OpenWeather, AccuWeather, etc.).

class WeatherPage extends StatefulWidget {
  const WeatherPage({Key? key}) : super(key: key);

  @override
  State<WeatherPage> createState() => _WeatherPageState();
}

class _WeatherPageState extends State<WeatherPage> {
  String currentLocation = "XYZ Location";

  // Add these variables for search functionality
  String searchQuery = "";
  final TextEditingController _searchController = TextEditingController();

  // Weather data - you can replace with API calls
  final WeatherData weatherData = WeatherData(
    temperature: 28,
    condition: "Partly Cloudy",
    humidity: 75,
    uvIndex: 6,
    windSpeed: 12,
    eczemaRisk: "Medium",
    riskMessage: "Current weather conditions may affect your eczema.",
  );

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // Filter cities based on search query
  List<Map<String, String>> get filteredCities {
    if (searchQuery.isEmpty) {
      return philippineCities;
    }
    return philippineCities.where((city) {
      final cityName = city['name']!.toLowerCase();
      final province = city['province']!.toLowerCase();
      final region = city['region']!.toLowerCase();
      final query = searchQuery.toLowerCase();

      return cityName.contains(query) ||
          province.contains(query) ||
          region.contains(query);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: AppColors.backgroundGradient,
        ),
        child: SafeArea(
          child: Column(
            children: [
              AppHeader(
                title: "Weather Impact",
                showMenu: true,
                showSync: true,
                onSyncPressed: _refreshWeatherData,
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildLocationSection(),
                      const SizedBox(height: 20),
                      _buildMainWeatherCard(),
                      const SizedBox(height: 20),
                      _buildEczemaRiskCard(),
                      const SizedBox(height: 20),
                      _buildEnvironmentTriggersSection(),
                    ],
                  ),
                ),
              ),
              AppBottomNavigation(
                currentIndex: 0,
                onTap: (index) {},
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLocationSection() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Approximate Location",
              style: GoogleFonts.quicksand(
                fontSize: 14,
                color: AppColors.primaryBlue,
                fontWeight: FontWeight.w500,
              ),
            ),
            Text(
              currentLocation,
              style: GoogleFonts.quicksand(
                fontSize: 16,
                color: AppColors.darkBlue,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        TextButton(
          onPressed: _changeLocation,
          child: Text(
            "Change Location",
            style: GoogleFonts.quicksand(
              fontSize: 14,
              color: AppColors.greyText,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMainWeatherCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              // Weather icon
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF4E6),
                  borderRadius: BorderRadius.circular(30),
                ),
                child: const Icon(
                  Icons.wb_sunny,
                  color: Color(0xFFFFB800),
                  size: 32,
                ),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "${weatherData.temperature}°",
                          style: GoogleFonts.quicksand(
                            fontSize: 48,
                            fontWeight: FontWeight.bold,
                            color: AppColors.darkBlue,
                            height: 1,
                          ),
                        ),
                        Text(
                          "C",
                          style: GoogleFonts.quicksand(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: AppColors.darkBlue,
                          ),
                        ),
                      ],
                    ),
                    Text(
                      weatherData.condition,
                      style: GoogleFonts.quicksand(
                        fontSize: 16,
                        color: Colors.grey[600],
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              // Weather details
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _buildWeatherDetail("Humidity", "${weatherData.humidity}%"),
                  const SizedBox(height: 8),
                  _buildWeatherDetail("UV Index", "${weatherData.uvIndex}"),
                  const SizedBox(height: 8),
                  _buildWeatherDetail("Wind", "${weatherData.windSpeed} km/h"),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildWeatherDetail(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          label,
          style: GoogleFonts.quicksand(
            fontSize: 12,
            color: AppColors.primaryBlue,
            fontWeight: FontWeight.w500,
          ),
        ),
        Text(
          value,
          style: GoogleFonts.quicksand(
            fontSize: 14,
            color: AppColors.darkBlue,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildEczemaRiskCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF4E6),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFFB800), width: 1),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: const Color(0xFFFFB800),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Icon(
              Icons.warning,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Eczema Risk: ${weatherData.eczemaRisk}",
                  style: GoogleFonts.quicksand(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFFB8860B),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  weatherData.riskMessage,
                  style: GoogleFonts.quicksand(
                    fontSize: 14,
                    color: const Color(0xFFB8860B),
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEnvironmentTriggersSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: AppColors.primaryBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(
                Icons.eco,
                color: AppColors.primaryBlue,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Text(
              "Environment Triggers",
              style: GoogleFonts.quicksand(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.darkBlue,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 10,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            children: [
              _buildTriggerRow(
                icon: Icons.water_drop,
                iconColor: AppColors.primaryBlue,
                title: "High Humidity",
                subtitle: "Triggers: Low 5%",
                isTop: true,
              ),
              const Divider(height: 1, color: Color(0xFFE5E5E5)),
              _buildTriggerRow(
                icon: Icons.air,
                iconColor: Colors.grey[600]!,
                title: "Air Quality",
                subtitle: "Triggers: Fair 7%",
              ),
              const Divider(height: 1, color: Color(0xFFE5E5E5)),
              _buildTriggerRow(
                icon: Icons.wb_sunny,
                iconColor: const Color(0xFFFFB800),
                title: "UV Exposure",
                subtitle: "Triggers: Moderate 4%",
              ),
              const Divider(height: 1, color: Color(0xFFE5E5E5)),
              _buildTriggerRow(
                icon: Icons.thermostat,
                iconColor: Colors.green,
                title: "Temperature",
                subtitle: "${weatherData.temperature}°C",
                isBottom: true,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTriggerRow({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    bool isTop = false,
    bool isBottom = false,
  }) {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Icon(
              icon,
              color: iconColor,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.quicksand(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AppColors.darkBlue,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: GoogleFonts.quicksand(
                    fontSize: 14,
                    color: Colors.grey[600],
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _refreshWeatherData() {
    // Implement weather data refresh logic here
    // This would typically involve calling a weather API
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Refreshing weather data..."),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _changeLocation() {
    // Reset search when dialog opens
    _searchController.clear();
    searchQuery = "";

    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: StatefulBuilder(
          builder: (context, setDialogState) => Container(
            width: MediaQuery.of(context).size.width * 0.9,
            height: MediaQuery.of(context).size.height * 0.7,
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Change Location",
                  style: GoogleFonts.quicksand(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: AppColors.darkBlue,
                  ),
                ),
                const SizedBox(height: 16),

                // Search field
                TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: "Search for a city...",
                    prefixIcon: Icon(Icons.search, color: AppColors.primaryBlue),
                    suffixIcon: searchQuery.isNotEmpty
                        ? IconButton(
                      icon: Icon(Icons.clear, color: Colors.grey[600]),
                      onPressed: () {
                        _searchController.clear();
                        setDialogState(() {
                          searchQuery = "";
                        });
                      },
                    )
                        : null,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: Colors.grey[300]!),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: AppColors.primaryBlue),
                    ),
                  ),
                  onChanged: (value) {
                    setDialogState(() {
                      searchQuery = value;
                    });
                  },
                ),

                const SizedBox(height: 20),

                Text(
                  filteredCities.isEmpty ? "No cities found" : "Cities (${filteredCities.length})",
                  style: GoogleFonts.quicksand(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AppColors.darkBlue,
                  ),
                ),

                const SizedBox(height: 12),

                // Cities list
                Expanded(
                  child: filteredCities.isEmpty
                      ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.location_off,
                          size: 48,
                          color: Colors.grey[400],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          "No cities match your search",
                          style: GoogleFonts.quicksand(
                            fontSize: 16,
                            color: Colors.grey[600],
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Try searching for a different city name",
                          style: GoogleFonts.quicksand(
                            fontSize: 14,
                            color: Colors.grey[500],
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ],
                    ),
                  )
                      : ListView.builder(
                    itemCount: filteredCities.length,
                    itemBuilder: (context, index) {
                      final cityData = filteredCities[index];
                      return _buildCityOption(
                        cityData['name']!,
                        cityData['region']!,
                        cityData['province']!,
                        onTap: () {
                          setState(() {
                            currentLocation = cityData['name']!;
                          });
                          Navigator.pop(context);
                        },
                      );
                    },
                  ),
                ),

                const SizedBox(height: 16),

                // Action buttons
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text(
                        "Cancel",
                        style: GoogleFonts.quicksand(
                          color: Colors.grey[600],
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCityOption(String city, String region, String province, {required VoidCallback onTap}) {
    bool isSelected = currentLocation == city;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: isSelected ? AppColors.primaryBlue.withOpacity(0.1) : Colors.grey[50],
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected ? AppColors.primaryBlue : Colors.grey[200]!,
              width: isSelected ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: isSelected ? AppColors.primaryBlue : Colors.grey[300],
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Icon(
                  Icons.location_city,
                  color: isSelected ? Colors.white : Colors.grey[600],
                  size: 20,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      city,
                      style: GoogleFonts.quicksand(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: isSelected ? AppColors.primaryBlue : AppColors.darkBlue,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      "$province, $region",
                      style: GoogleFonts.quicksand(
                        fontSize: 14,
                        color: Colors.grey[600],
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              if (isSelected)
                Icon(
                  Icons.check_circle,
                  color: AppColors.primaryBlue,
                  size: 24,
                ),
            ],
          ),
        ),
      ),
    );
  }

  // Philippine cities data
  static const List<Map<String, String>> philippineCities = [
    {'name': 'Manila', 'province': 'Metro Manila', 'region': 'NCR'},
    {'name': 'Quezon City', 'province': 'Metro Manila', 'region': 'NCR'},
    {'name': 'Makati', 'province': 'Metro Manila', 'region': 'NCR'},
    {'name': 'Taguig', 'province': 'Metro Manila', 'region': 'NCR'},
    {'name': 'Pasig', 'province': 'Metro Manila', 'region': 'NCR'},
    {'name': 'Antipolo', 'province': 'Rizal', 'region': 'Calabarzon'},
    {'name': 'Cebu City', 'province': 'Cebu', 'region': 'Central Visayas'},
    {'name': 'Davao City', 'province': 'Davao del Sur', 'region': 'Davao Region'},
    {'name': 'Cagayan de Oro', 'province': 'Misamis Oriental', 'region': 'Northern Mindanao'},
    {'name': 'Zamboanga City', 'province': 'Zamboanga del Sur', 'region': 'Zamboanga Peninsula'},
    {'name': 'Iloilo City', 'province': 'Iloilo', 'region': 'Western Visayas'},
    {'name': 'Bacolod', 'province': 'Negros Occidental', 'region': 'Western Visayas'},
    {'name': 'Baguio', 'province': 'Benguet', 'region': 'Cordillera Administrative Region'},
    {'name': 'General Santos', 'province': 'South Cotabato', 'region': 'Soccsksargen'},
    {'name': 'Butuan', 'province': 'Agusan del Norte', 'region': 'Caraga'},
    {'name': 'Angeles', 'province': 'Pampanga', 'region': 'Central Luzon'},
    {'name': 'Olongapo', 'province': 'Zambales', 'region': 'Central Luzon'},
    {'name': 'Tarlac City', 'province': 'Tarlac', 'region': 'Central Luzon'},
    {'name': 'Cabanatuan', 'province': 'Nueva Ecija', 'region': 'Central Luzon'},
    {'name': 'San Jose del Monte', 'province': 'Bulacan', 'region': 'Central Luzon'},
    {'name': 'Bacoor', 'province': 'Cavite', 'region': 'Calabarzon'},
    {'name': 'Dasmariñas', 'province': 'Cavite', 'region': 'Calabarzon'},
    {'name': 'Calamba', 'province': 'Laguna', 'region': 'Calabarzon'},
    {'name': 'Batangas City', 'province': 'Batangas', 'region': 'Calabarzon'},
    {'name': 'Lucena', 'province': 'Quezon', 'region': 'Calabarzon'},
    {'name': 'Naga', 'province': 'Camarines Sur', 'region': 'Bicol Region'},
    {'name': 'Legazpi', 'province': 'Albay', 'region': 'Bicol Region'},
    {'name': 'Tacloban', 'province': 'Leyte', 'region': 'Eastern Visayas'},
    {'name': 'Ormoc', 'province': 'Leyte', 'region': 'Eastern Visayas'},
    {'name': 'Dumaguete', 'province': 'Negros Oriental', 'region': 'Central Visayas'},
    {'name': 'Tagbilaran', 'province': 'Bohol', 'region': 'Central Visayas'},
    {'name': 'Puerto Princesa', 'province': 'Palawan', 'region': 'Mimaropa'},
    {'name': 'Lipa', 'province': 'Batangas', 'region': 'Calabarzon'},
    {'name': 'Biñan', 'province': 'Laguna', 'region': 'Calabarzon'},
    {'name': 'Cainta', 'province': 'Rizal', 'region': 'Calabarzon'},
  ];
}