import 'package:cap2439is_eczema/screens/dashboard/poem_history_page.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_styles.dart';
import '../../core/constants/app_button_styles.dart';
import '../../core/constants/app_header.dart';
import '../../core/constants/app_bottom_navigation.dart';
import 'dart:math' as math;

import '../../services/assessment_service.dart';

/// PoemResultsPage - Displays the results summary of a completed POEM assessment
///
/// This screen presents the final score and interpretation of the Patient-Oriented Eczema Measure (POEM)
/// immediately after the user completes their assessment. It provides both a visual and textual summary
/// of the user’s eczema severity level, along with a personalized recommendation and the next available
/// assessment date.
///
/// Key Features:
/// - Displays total POEM score with a visual gauge representation
/// - Highlights eczema severity level (Clear, Mild, Moderate, Severe, Very Severe)
/// - Shows personalized feedback message based on the user’s score
/// - Indicates when the next POEM assessment can be taken
/// - Provides navigation to the full assessment history
///
/// User Interactions:
/// - "VIEW HISTORY" button: Navigates to PoemHistoryPage for reviewing past results
/// - AppHeader icons (menu, sync): Allow quick navigation and data synchronization
/// - Static result elements display assessment data in a read-only format
///
/// Data Flow:
/// - Receives totalScore and answers list as parameters from the previous POEM assessment flow
/// - Calculates severity level, color, and recommendation text based on score
/// - Dynamically generates date for next assessment availability

class PoemResultsPage extends StatelessWidget {
  final int totalScore;
  final List<int?> answers;

  const PoemResultsPage({
    Key? key,
    required this.totalScore,
    required this.answers,
  }) : super(key: key);

  String getSeverityLevel(int score) {
    if (score <= 2) return "Clear or almost clear";
    if (score <= 7) return "Mild eczema";
    if (score <= 16) return "Moderate eczema";
    if (score <= 24) return "Severe eczema";
    return "Very severe eczema";
  }

  Color getSeverityColor(int score) {
    if (score <= 2) return Colors.green;
    if (score <= 7) return Colors.yellow.shade700;
    if (score <= 16) return Colors.orange;
    if (score <= 24) return Colors.red;
    return Colors.red.shade900;
  }

  String getSeverityPrompt(int score) {
    if (score <= 2) return "Great news! Your skin is clear or nearly clear. Keep up with your current care routine to maintain this progress.";
    if (score <= 7) return "Your eczema is mild. Stay consistent with your skincare and avoid common triggers to prevent flare-ups.";
    if (score <= 16) return "Your eczema is moderate. You may experience frequent symptoms. Monitoring your skin daily and following your treatment plan can help reduce discomfort.";
    if (score <= 24) return "Your eczema is severe. This level of symptoms can impact daily life. Consider discussing your treatment with your healthcare provider for additional support.";
    return "Your eczema is very severe. Please seek medical advice as soon as possible to manage your symptoms effectively.";
  }

  String getFormattedDate() {
    final now = DateTime.now();
    final nextWeek = now.add(const Duration(days: 7));
    return "${nextWeek.month.toString().padLeft(2, '0')}.${nextWeek.day.toString().padLeft(2, '0')}.${nextWeek.year}";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppColors.backgroundGradient,
        ),
        child: SafeArea(
          child: Column(
            children: [
              AppHeader(
                title: "POEM Results",
                showMenu: true,
                showSync: true,
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Enhanced Results Summary with Gauge
                      Center(
                        child: Container(
                          padding: const EdgeInsets.all(32),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.1),
                                blurRadius: 20,
                                offset: const Offset(0, 8),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              Text(
                                "Your POEM Score",
                                style: AppTextStyles.subtextOpenSans.copyWith(
                                  color: AppColors.greyText,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                "${DateTime.now().month.toString().padLeft(2, '0')}.${DateTime.now().day.toString().padLeft(2, '0')}.${DateTime.now().year}",
                                style: AppTextStyles.subtextOpenSans.copyWith(
                                  color: AppColors.darkBlue,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                              SizedBox(
                                width: 200,
                                height: 160, // Increased height to accommodate more spacing
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    CustomPaint(
                                      size: const Size(200, 120),
                                      painter: GaugePainter(
                                        score: totalScore,
                                        maxScore: 28,
                                        color: getSeverityColor(totalScore),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 0,
                                      child: Column(
                                        children: [
                                          const SizedBox(height: 12), // Add spacing above the score
                                          Text(
                                            "$totalScore",
                                            style: AppTextStyles.headingQuicksand.copyWith(
                                              fontSize: 48,
                                              fontWeight: FontWeight.bold,
                                              color: getSeverityColor(totalScore),
                                            ),
                                          ),
                                          Text(
                                            "out of 28",
                                            style: AppTextStyles.subtextOpenSans.copyWith(
                                              color: AppColors.greyText,
                                              fontSize: 14,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              const SizedBox(height: 16),

                              // Severity Level
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                decoration: BoxDecoration(
                                  color: getSeverityColor(totalScore).withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                    color: getSeverityColor(totalScore).withOpacity(0.3),
                                  ),
                                ),
                                child: Text(
                                  getSeverityLevel(totalScore),
                                  style: AppTextStyles.subtextOpenSans.copyWith(
                                    color: getSeverityColor(totalScore),
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 24),

                      // Severity Prompt Widget
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: getSeverityColor(totalScore).withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Icon(
                                    Icons.lightbulb_outline,
                                    color: getSeverityColor(totalScore),
                                    size: 20,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Text(
                                  "Recommendation",
                                  style: AppTextStyles.subtextOpenSans.copyWith(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: AppColors.darkBlue,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            Text(
                              getSeverityPrompt(totalScore),
                              style: AppTextStyles.subtextOpenSans.copyWith(
                                color: AppColors.greyText,
                                fontSize: 14,
                                height: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      // Next available date - now full width to match recommendation block
                      Container(
                        width: double.infinity, // Changed from Center widget to full width container
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppColors.lightBlue.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.lightBlue.withOpacity(0.3)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center, // Center the content within the container
                          children: [
                            Icon(
                              Icons.calendar_today,
                              color: AppColors.primaryBlue,
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              "Next POEM available on ${getFormattedDate()}",
                              style: AppTextStyles.subtextOpenSans.copyWith(
                                color: AppColors.primaryBlue,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 32),

                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const PoemHistoryPage(),
                              ),
                            );
                          },
                          style: AppButtonStyles.primaryButton.copyWith(
                            padding: MaterialStateProperty.all(
                              const EdgeInsets.symmetric(vertical: 16),
                            ),
                          ),
                          icon: const Icon(Icons.history),
                          label: const Text("VIEW HISTORY"),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              AppBottomNavigation(
                currentIndex: 0,
                onTap: (index) {},
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GaugePainter extends CustomPainter {
  final int score;
  final int maxScore;
  final Color color;

  GaugePainter({
    required this.score,
    required this.maxScore,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height);
    final radius = size.width / 2 - 10;

    // Background arc
    final backgroundPaint = Paint()
      ..color = Colors.grey.shade200
      ..strokeWidth = 12
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      math.pi,
      math.pi,
      false,
      backgroundPaint,
    );

    // Progress arc
    final progressPaint = Paint()
      ..color = color
      ..strokeWidth = 12
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final sweepAngle = (score / maxScore) * math.pi;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      math.pi,
      sweepAngle,
      false,
      progressPaint,
    );

    // Draw severity markers
    final markerPaint = Paint()
      ..color = Colors.grey.shade400
      ..strokeWidth = 2;

    final severityLevels = [2, 7, 16, 24, 28];
    for (int level in severityLevels) {
      final angle = math.pi + (level / maxScore) * math.pi;
      final startPoint = Offset(
        center.dx + (radius - 15) * math.cos(angle),
        center.dy + (radius - 15) * math.sin(angle),
      );
      final endPoint = Offset(
        center.dx + (radius + 5) * math.cos(angle),
        center.dy + (radius + 5) * math.sin(angle),
      );

      canvas.drawLine(startPoint, endPoint, markerPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}