import 'package:cap2439is_eczema/screens/dashboard/poem_dashboard_page.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_header.dart';
import '../../core/constants/app_bottom_navigation.dart';
import '../../services/auth_service.dart';
import '../../services/session_service.dart';
import '../../services/firestore_services.dart';
import '../../models/user_model.dart';
import '../../models/daily_log_model.dart';
import 'skin_analysis_page.dart';
import 'account_edit_page.dart';
import '../login/login_page.dart';

/// DashboardScreen - Main hub for user's eczema management activities
///
/// This screen serves as the primary interface after user authentication, providing
/// a comprehensive overview of the user's eczema management progress, recent activities,
/// and quick access to assessment tools.
///
/// Key Features:
/// - Real-time user progress tracking with visual indicators
/// - Daily and weekly logging statistics with progress gauges
/// - EASI-based severity assessment visualization
/// - Quick access buttons to POEM assessment and skin analysis
/// - Recent activity log display
/// - Personalized recommendations based on user data
/// - Goals tracking with progress bars
///
/// User Interactions:
/// - View personalized dashboard with user's name
/// - Access POEM assessment through dialog and button
/// - Navigate to skin analysis for body area mapping
/// - View and track daily logging progress
/// - Monitor eczema severity trends
/// - Access account settings through drawer menu
/// - Logout functionality with confirmation
///
/// Data Flow:
/// - Reads: User profile data from Firestore
/// - Reads: Daily logs stream for progress tracking
/// - Reads: Severity assessment data for EASI calculations
/// - Writes: None (read-only dashboard display)
/// - Updates: Session state on logout
///
/// State Management:
/// - Uses StreamBuilder for real-time daily log updates
/// - Maintains loading state during data fetch operations
/// - Handles authentication state with fallback user display
/// - Implements timeout protection for Firestore operations
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  // Service instances for data access and authentication
  final AuthService _authService = AuthService();
  final SessionService _sessionService = SessionService();
  final FirestoreService _firestoreService = FirestoreService();

  // State variables for user data and UI state
  UserModel? _currentUser; // Currently authenticated user's profile data
  List<DailyLog> _dailyLogs = []; // User's daily log entries
  bool _isLoading = true; // Loading state for initial data fetch
  bool _showOnboarding = true; // Show onboarding guide for new users

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  /// Load current user's data from Firestore with timeout protection
  ///
  /// This method retrieves the authenticated user's profile information from Firestore.
  /// Implements a 5-second timeout to prevent indefinite hanging if Firestore is slow.
  /// If the fetch times out or fails, creates a fallback user model from auth data.
  ///
  /// Error Handling:
  /// - Timeout: Creates basic user from Firebase Auth display name and email
  /// - Network failure: Falls back to auth data
  /// - No user: Sets _currentUser to null
  Future<void> _loadUserData() async {
    try {
      final user = _authService.currentUser;
      if (user != null) {
        // Load user data with 5-second timeout to prevent hanging
        final userData = await _firestoreService
            .getUser(user.uid)
            .timeout(
          const Duration(seconds: 5),
          onTimeout: () {
            debugPrint('Timeout loading user data, using fallback');
            // Create a basic user model from auth data if Firestore times out
            return UserModel(
              id: user.uid,
              email: user.email ?? '',
              passwordHash: '',
              firstName: user.displayName?.split(' ').first ?? 'User',
              lastName: user.displayName?.split(' ').last ?? '',
              birthdate: DateTime.now(),
              gender: '',
              createdAt: DateTime.now(),
              updatedAt: DateTime.now(),
            );
          },
        );

        if (mounted) {
          setState(() {
            _currentUser = userData;
          });
        }
      }
    } catch (e) {
      debugPrint('Error loading user data: $e');

      // Try to create a fallback user from auth data
      final user = _authService.currentUser;
      if (user != null && mounted) {
        setState(() {
          _currentUser = UserModel(
            id: user.uid,
            email: user.email ?? '',
            passwordHash: '',
            firstName: user.displayName?.split(' ').first ?? 'User',
            lastName: user.displayName?.split(' ').last ?? '',
            birthdate: DateTime.now(),
            gender: '',
            createdAt: DateTime.now(),
            updatedAt: DateTime.now(),
          );
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  /// Mock severity factors data structure for EASI calculation
  ///
  /// This getter provides mock data for eczema severity assessment.
  /// In production, this would be replaced with actual data from user's
  /// POEM assessments and daily logs.
  ///
  /// Returns map containing:
  /// - poemScore: Patient-Oriented Eczema Measure score (0-28 scale)
  /// - affectedAreas: List of body areas currently affected
  /// - itchiness: Itching severity rating (1-5 scale)
  /// - skinAppearance: Visual skin condition rating (1-5 scale)
  /// - lastAssessmentDate: Date of most recent assessment
  Map<String, dynamic> get _severityFactors {
    return {
      'poemScore': 28, // POEM score for testing (0-28 range)
      'affectedAreas': ['arms'], // Currently affected body areas
      'itchiness': 5, // Itch severity (1-5 scale)
      'skinAppearance': 3, // Skin condition (1-5 scale)
      'lastAssessmentDate': DateTime.now().subtract(const Duration(days: 2)),
    };
  }

  /// Calculate user logging statistics from actual daily logs
  ///
  /// This getter processes the user's daily log entries to generate
  /// statistics for today and the current week. Used to drive the
  /// progress indicators on the dashboard.
  ///
  /// Returns map containing:
  /// - yourLogsToday: Number of logs created today
  /// - yourLogsThisWeek: Total logs created this week (Monday-today)
  ///
  /// Logic:
  /// - Filters logs by comparing dates (year, month, day for today)
  /// - Week calculation starts from Monday (weekday - 1)
  /// - Handles null dates gracefully by skipping those entries
  Map<String, dynamic> get _userStats {
    final today = DateTime.now();
    final startOfWeek = today.subtract(Duration(days: today.weekday - 1));

    // Count logs created today (same year, month, and day)
    final logsToday = _dailyLogs.where((log) {
      if (log.date == null) return false;
      final logDate = log.date!;
      return logDate.year == today.year &&
          logDate.month == today.month &&
          logDate.day == today.day;
    }).length;

    // Count logs created this week (from Monday onwards)
    final logsThisWeek = _dailyLogs.where((log) {
      if (log.date == null) return false;
      return log.date!.isAfter(startOfWeek);
    }).length;

    return {'yourLogsToday': logsToday, 'yourLogsThisWeek': logsThisWeek};
  }

  /// Calculate current eczema severity score based on multiple weighted factors
  ///
  /// This getter computes a composite severity score (0-10) by combining:
  /// 1. POEM score (40% weight): Validated patient questionnaire
  /// 2. Affected areas (30% weight): Extent of body involvement
  /// 3. Symptom ratings (30% weight): Average of itchiness and appearance
  ///
  /// Calculation details:
  /// - POEM: Normalized from 0-28 scale to 0-10, then weighted
  /// - Areas: Normalized based on max 8 body areas, then weighted
  /// - Symptoms: Average of three 1-5 ratings, normalized to 0-10, then weighted
  ///
  /// Returns: Integer severity score from 0-10 (clamped to ensure valid range)
  int get currentSeverity {
    double calculatedSeverity = 0;

    // POEM score contributes 40% to overall severity (normalize 0-28 to 0-10)
    calculatedSeverity += (_severityFactors['poemScore'] / 28) * 10 * 0.4;

    // Number of affected areas contributes 30% (normalize based on 8 max areas)
    calculatedSeverity +=
        (_severityFactors['affectedAreas'].length / 8) * 10 * 0.3;

    // Average of symptom ratings contributes 30% (itchiness, appearance)
    double avgSymptoms =
        (_severityFactors['itchiness'] + _severityFactors['skinAppearance']) /
            3;
    calculatedSeverity += (avgSymptoms / 5) * 10 * 0.3;

    // Round to integer and clamp to valid 0-10 range
    return calculatedSeverity.round().clamp(0, 10);
  }

  /// Get human-readable severity label based on current severity score
  ///
  /// Categorizes the 0-10 severity score into three clinical categories:
  /// - Mild: 0-3
  /// - Moderate: 4-6
  /// - Severe: 7-10
  String get severityLabel {
    int severity = currentSeverity;
    if (severity <= 3) return 'Mild';
    if (severity <= 6) return 'Moderate';
    return 'Severe';
  }

  /// Get color representation for current severity level
  ///
  /// Maps severity scores to visual colors for quick recognition:
  /// - Green: Mild severity (0-3)
  /// - Orange: Moderate severity (4-6)
  /// - Red: Severe (7-10)
  Color get severityColor {
    int severity = currentSeverity;
    if (severity <= 3) return Colors.green;
    if (severity <= 6) return Colors.orange;
    return Colors.red;
  }

  @override
  Widget build(BuildContext context) {
    final user = _authService.currentUser;

    debugPrint('Dashboard build - user: ${user?.uid}, isLoading: $_isLoading');

    // Check authentication first, before loading state
    if (user == null) {
      debugPrint('No user found in dashboard');
      return Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: AppColors.backgroundGradient,
          ),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Please log in to view your dashboard',
                  style: TextStyle(fontSize: 16, color: AppColors.darkBlue),
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: const Text('Go Back'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    if (_isLoading) {
      return Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: AppColors.backgroundGradient,
          ),
          child: const Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryBlue),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      drawer: _buildDrawer(),
      body: StreamBuilder<List<DailyLog>>(
        stream: _firestoreService.streamDailyLogs(user.uid),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            _dailyLogs = snapshot.data!;
          }

          return Container(
            decoration: const BoxDecoration(
              gradient: AppColors.backgroundGradient,
            ),
            child: SafeArea(
              child: Column(
                children: [
                  AppHeader(
                    title: _currentUser != null
                        ? 'Hi, ${_currentUser!.firstName}!'
                        : 'Dashboard',
                  ), // Personalized header with user's name
                  Expanded(
                    // Add Expanded here
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 20),
                          _buildOnboardingGuide(),
                          const SizedBox(height: 20),
                          _buildUserStatsCard(),
                          const SizedBox(height: 20),
                          _buildActionButtons(),
                          const SizedBox(height: 20),
                          _buildRecommendedActions(),
                          const SizedBox(height: 20),
                          _buildLastSeverityCheck(),
                          const SizedBox(height: 20),
                          _buildGoalsStatus(),
                          const SizedBox(height: 20),
                          _buildRecentLogs(),
                          const SizedBox(height: 20),
                        ],
                      ),
                    ),
                  ),
                  AppBottomNavigation(
                    // Move inside body as a child widget
                    currentIndex: 0,
                    onTap: (index) {
                      // handle navigation
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildUserStatsCard() {
    double todayProgress = (_userStats['yourLogsToday'] / 5).clamp(0.0, 1.0);

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.white.withOpacity(0.8),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Your Progress Overview',
            style: GoogleFonts.quicksand(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
            ),
          ),
          const SizedBox(height: 24),

          // Clean gauge layout
          Row(
            children: [
              // Circular Progress Gauge
              SizedBox(
                height: 100,
                width: 100,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Background circle
                    SizedBox(
                      height: 100,
                      width: 100,
                      child: CircularProgressIndicator(
                        value: 1.0,
                        strokeWidth: 8,
                        backgroundColor: AppColors.lightGrey.withOpacity(0.2),
                        valueColor: AlwaysStoppedAnimation<Color>(
                          AppColors.lightGrey.withOpacity(0.2),
                        ),
                      ),
                    ),
                    // Progress circle
                    SizedBox(
                      height: 100,
                      width: 100,
                      child: CircularProgressIndicator(
                        value: todayProgress,
                        strokeWidth: 8,
                        backgroundColor: Colors.transparent,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          _getProgressColor(todayProgress),
                        ),
                        strokeCap: StrokeCap.round,
                      ),
                    ),
                    // Center content
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          '${(todayProgress * 100).round()}%',
                          style: GoogleFonts.quicksand(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: _getProgressColor(todayProgress),
                          ),
                        ),
                        Text(
                          'Complete',
                          style: GoogleFonts.openSans(
                            fontSize: 10,
                            color: AppColors.greyText,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 32),

              // Simple stats without boxes
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${_userStats['yourLogsToday']}',
                              style: GoogleFonts.quicksand(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: AppColors.primaryBlue,
                              ),
                            ),
                            Text(
                              'Logs Today',
                              style: GoogleFonts.openSans(
                                fontSize: 12,
                                color: AppColors.greyText,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          width: 32,
                        ), // Fixed spacing between stats
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${_userStats['yourLogsThisWeek']}',
                              style: GoogleFonts.quicksand(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Colors.green,
                              ),
                            ),
                            Text(
                              'This Week',
                              style: GoogleFonts.openSans(
                                fontSize: 12,
                                color: AppColors.greyText,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    // Visual indicator for remaining logs with clear labeling
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Daily Goal Progress',
                          style: GoogleFonts.openSans(
                            fontSize: 12,
                            color: AppColors.darkBlue,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            // Dot indicators for logs
                            ...List.generate(5, (index) {
                              bool isCompleted =
                                  index < _userStats['yourLogsToday'];
                              return Container(
                                margin: const EdgeInsets.only(right: 6),
                                width: 10,
                                height: 10,
                                decoration: BoxDecoration(
                                  color: isCompleted
                                      ? _getProgressColor(todayProgress)
                                      : AppColors.lightGrey.withOpacity(0.3),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: isCompleted
                                        ? _getProgressColor(todayProgress)
                                        : AppColors.lightGrey.withOpacity(0.5),
                                    width: 1,
                                  ),
                                ),
                              );
                            }),
                            const SizedBox(width: 8),
                            Text(
                              '${_userStats['yourLogsToday']}/5 entries',
                              style: GoogleFonts.openSans(
                                fontSize: 11,
                                color: AppColors.greyText,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Build onboarding guide for new users
  Widget _buildOnboardingGuide() {
    if (!_showOnboarding) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppColors.primaryBlue.withOpacity(0.1),
            AppColors.lightBlue.withOpacity(0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: AppColors.primaryBlue.withOpacity(0.3),
          width: 2,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.primaryBlue,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  Icons.waving_hand,
                  color: Colors.white,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Get Started with EczeManage',
                  style: GoogleFonts.quicksand(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: AppColors.darkBlue,
                  ),
                ),
              ),
              IconButton(
                onPressed: () {
                  setState(() {
                    _showOnboarding = false;
                  });
                },
                icon: Icon(
                  Icons.close,
                  color: AppColors.greyText,
                  size: 20,
                ),
                padding: EdgeInsets.zero,
                constraints: BoxConstraints(),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildOnboardingStep(
            1,
            'Take POEM Assessment',
            Icons.description_outlined,
            AppColors.primaryBlue,
          ),
          const SizedBox(height: 10),
          _buildOnboardingStep(
            2,
            'Take A Skin Analysis Test',
            Icons.person_search_outlined,
            AppColors.primaryBlue,
          ),
          const SizedBox(height: 10),
          _buildOnboardingStep(
            3,
            'Create Your Care Routine',
            Icons.medical_services_rounded,
            AppColors.primaryBlue,
          ),
          const SizedBox(height: 10),
          _buildOnboardingStep(
            4,
            'Log Your Triggers',
            Icons.warning_amber_rounded,
            AppColors.primaryBlue,
          ),
        ],
      ),
    );
  }

  Widget _buildOnboardingStep(
      int stepNumber,
      String title,
      IconData icon,
      Color color,
      ) {
    return Row(
      children: [
        Container(
          width: 28,
          height: 28,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              '$stepNumber',
              style: GoogleFonts.quicksand(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            title,
            style: GoogleFonts.quicksand(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
            ),
          ),
        ),
      ],
    );
  }

  /// Helper method to get progress indicator color based on completion percentage
  ///
  /// Applies color coding to progress indicators to provide visual feedback:
  /// - Green: 80%+ completion (excellent progress)
  /// - Orange: 60-79% completion (good progress)
  /// - Blue: 40-59% completion (moderate progress)
  /// - Red: <40% completion (needs improvement)
  Color _getProgressColor(double progress) {
    if (progress >= 0.8) return Colors.green;
    if (progress >= 0.6) return Colors.orange;
    if (progress >= 0.4) return AppColors.primaryBlue;
    return Colors.red;
  }

  Widget _buildActionButtons() {
    return Column(
      children: [
        _buildWideButton(
          'POEM Assessment',
          'Track eczema impact on daily life',
          Icons.description_outlined,
          [AppColors.primaryBlue, AppColors.lightBlue],
              () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const PoemDashboardPage()),
            );
          },
        ),
        const SizedBox(height: 12),
        _buildWideButton(
          'Skin Analysis',
          'Analyze affected body areas',
          Icons.person_search_outlined,
          [Color(0xFF6C63FF), Color(0xFF9C88FF)],
              () => _showBodyMapDialog(),
        ),
      ],
    );
  }

  Widget _buildWideButton(
      String title,
      String subtitle,
      IconData icon,
      List<Color> gradientColors,
      VoidCallback onPressed,
      ) {
    return Container(
      height: 70,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: gradientColors,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: gradientColors[0].withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onPressed,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: Colors.white, size: 24),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        title,
                        style: GoogleFonts.quicksand(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        subtitle,
                        style: GoogleFonts.openSans(
                          fontSize: 11,
                          color: Colors.white.withOpacity(0.8),
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios,
                  color: Colors.white.withOpacity(0.8),
                  size: 16,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // EASI-based Last Severity Check
  Widget _buildLastSeverityCheck() {
    final DateTime? lastCheck =
    _severityFactors['lastAssessmentDate'] as DateTime?;
    final int daysSinceLastCheck = lastCheck != null
        ? DateTime.now().difference(lastCheck).inDays
        : 0;

    final List<String> affectedAreas =
        (_severityFactors['affectedAreas'] as List<String>?) ?? [];

    // Mock EASI results data
    final Map<String, dynamic> easiResults = {
      'totalScore': 6,
      'maxScore': 12,
      'severity': 'Moderate',
      'factors': [
        {
          'name': 'Erythema',
          'description': 'Redness',
          'score': 2,
          'maxScore': 3,
        },
        {
          'name': 'Edema/Papulation',
          'description': 'Swelling/Bumps',
          'score': 3,
          'maxScore': 3,
        },
        {
          'name': 'Excoriation',
          'description': 'Scratching Damage',
          'score': 0,
          'maxScore': 3,
        },
        {
          'name': 'Lichenification',
          'description': 'Skin Thickening',
          'score': 1,
          'maxScore': 3,
        },
      ],
    };

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.white.withOpacity(0.9),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Last Severity Check',
                style: GoogleFonts.quicksand(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: AppColors.darkBlue,
                ),
              ),
              Text(
                '$daysSinceLastCheck days ago',
                style: GoogleFonts.openSans(
                  fontSize: 12,
                  color: AppColors.greyText,
                ),
              ),
            ],
          ),

          const SizedBox(height: 16), // Reduced from 20
          // Gauge
          // Fixed Gauge - no text overlap
          Center(
            child: SizedBox(
              width: 140,
              height: 140,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Background circle
                  SizedBox(
                    width: 140,
                    height: 140,
                    child: CircularProgressIndicator(
                      value: 1.0, // Full circle for background
                      strokeWidth: 8,
                      color: AppColors.lightGrey.withOpacity(0.2),
                    ),
                  ),
                  // Progress circle
                  SizedBox(
                    width: 180,
                    height: 180,
                    child: CircularProgressIndicator(
                      value:
                      (easiResults['totalScore'].toDouble() /
                          easiResults['maxScore'].toDouble())
                          .clamp(0.0, 1.0),
                      strokeWidth: 8, // Reduced from 12
                      backgroundColor: Colors.transparent, // Remove background
                      valueColor: AlwaysStoppedAnimation<Color>(
                        _getEasiSeverityColor(
                          easiResults['totalScore'].toDouble(),
                        ),
                      ),
                    ),
                  ),
                  // Center content - positioned properly
                  SizedBox(
                    width: 120, // Define explicit width for center content
                    height: 120,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          '${easiResults['totalScore']}',
                          style: GoogleFonts.quicksand(
                            fontSize: 42,
                            fontWeight: FontWeight.bold,
                            color: _getEasiSeverityColor(
                              easiResults['totalScore'].toDouble(),
                            ),
                          ),
                        ),
                        Text(
                          easiResults['severity'],
                          style: GoogleFonts.openSans(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: AppColors.greyText,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'out of ${easiResults['maxScore']}',
                          style: GoogleFonts.openSans(
                            fontSize: 12,
                            color: AppColors.greyText.withOpacity(0.7),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16), // Reduced from 24
          // EASI factors
          ...easiResults['factors'].map<Widget>((factor) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 16), // Reduced from 20
              child: _buildCleanFactorItem(factor),
            );
          }).toList(),

          const SizedBox(height: 4), // Reduced from 8
          // Affected areas info
          Row(
            children: [
              Icon(
                Icons.location_on_outlined,
                size: 16,
                color: AppColors.greyText,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Affected area: ${affectedAreas.isNotEmpty ? affectedAreas.join(", ") : "No data"}',
                  style: GoogleFonts.openSans(
                    fontSize: 12,
                    color: AppColors.darkBlue,
                  ),
                ),
              ),
            ],
          ),

          // Prompt if too old
          if (daysSinceLastCheck > 7) ...[
            const SizedBox(height: 12), // Reduced from 16
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.orange.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  Icon(Icons.refresh, size: 16, color: Colors.orange[700]),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Consider taking a new assessment',
                      style: GoogleFonts.openSans(
                        fontSize: 12,
                        color: Colors.orange[700],
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  // Clean factor item widget - FIXED
  Widget _buildCleanFactorItem(Map<String, dynamic> factor) {
    final Color factorColor = _getFactorColor(factor['score'] as int);
    final double progress = (factor['score'] / factor['maxScore']).clamp(
      0.0,
      1.0,
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    factor['name'],
                    style: GoogleFonts.openSans(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: AppColors.darkBlue,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    factor['description'],
                    style: GoogleFonts.openSans(
                      fontSize: 12,
                      color: AppColors.greyText,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: factorColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                '${factor['score']}/${factor['maxScore']}',
                style: GoogleFonts.quicksand(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: factorColor,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 6), // Reduced from 8
        Container(
          height: 6, // Reduced from 8 to be less chunky
          decoration: BoxDecoration(
            color: AppColors.lightGrey.withOpacity(0.3), // Made more visible
            borderRadius: BorderRadius.circular(3),
          ),
          child: Stack(
            children: [
              // Always show background
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: AppColors.lightGrey.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
              // Show progress bar only if score > 0, or minimum width if score == 0
              FractionallySizedBox(
                alignment: Alignment.centerLeft,
                widthFactor: progress == 0.0
                    ? 0.02
                    : progress, // Minimum 2% width for 0 scores
                child: Container(
                  decoration: BoxDecoration(
                    color: progress == 0.0
                        ? factorColor.withOpacity(0.3)
                        : factorColor,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // Factor color helper - IMPROVED
  Color _getFactorColor(int score) {
    switch (score) {
      case 0:
        return Colors.green;
      case 1:
        return Colors.yellow.shade700;
      case 2:
        return Colors.orange;
      default:
        return Colors.red;
    }
  }

  // EASI severity color helper - FIXED
  Color _getEasiSeverityColor(double score) {
    if (score <= 3) return Colors.green;
    if (score <= 6) return Colors.lightGreen;
    if (score <= 9) return Colors.orange;
    if (score <= 12) return Colors.deepOrange;
    return Colors.red;
  }

  Widget _buildRecommendedActions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Recommended Actions',
          style: GoogleFonts.quicksand(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 12),
        _buildAlertCard(
          'High Severity Alert',
          'Your eczema severity has increased. Consider seeing a dermatologist.',
          Icons.warning,
          Colors.orange,
        ),
        const SizedBox(height: 8),
        _buildAlertCard(
          'Moisturize Reminder',
          'You haven\'t logged moisturizing today. Apply moisturizer now.',
          Icons.water_drop,
          AppColors.lightBlue,
        ),
      ],
    );
  }

  Widget _buildAlertCard(
      String title,
      String description,
      IconData icon,
      Color color,
      ) {
    return Container(
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: AppColors.white.withOpacity(0.8),
        borderRadius: BorderRadius.circular(12),
        border: Border(left: BorderSide(color: color, width: 4)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.openSans(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: AppColors.darkBlue,
                  ),
                ),
                Text(
                  description,
                  style: GoogleFonts.openSans(
                    fontSize: 12,
                    color: AppColors.greyText,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGoalsStatus() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Goals Status',
          style: GoogleFonts.quicksand(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 12),
        _buildGoalCard(
          'Daily Symptom Logging',
          _userStats['yourLogsToday'] / 5,
          '${_userStats['yourLogsToday']}/5 logs today',
        ),
        _buildGoalCard(
          'Weekly Assessment',
          _userStats['yourLogsThisWeek'] / 21,
          '${_userStats['yourLogsThisWeek']}/21 logs this week',
        ),
      ],
    );
  }

  Widget _buildGoalCard(String title, double progress, String subtitle) {
    return Container(
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: AppColors.white.withOpacity(0.8),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: GoogleFonts.openSans(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: AppColors.darkBlue,
                ),
              ),
              Text(
                '${(progress * 100).round()}%',
                style: GoogleFonts.openSans(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: AppColors.primaryBlue,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          LinearProgressIndicator(
            value: progress.clamp(0.0, 1.0),
            backgroundColor: AppColors.lightGrey,
            valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryBlue),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: GoogleFonts.openSans(
              fontSize: 12,
              color: AppColors.greyText,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentLogs() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Recent Logs',
              style: GoogleFonts.quicksand(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppColors.darkBlue,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        _buildLogCard(
          'Severity: $currentSeverity',
          'Today, 2:30 PM',
          Icons.trending_up,
        ),
        _buildLogCard(
          'Affected areas updated',
          'Today, 10:15 AM',
          Icons.person_outline,
        ),
      ],
    );
  }

  Widget _buildLogCard(String action, String time, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: AppColors.white.withOpacity(0.8),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.lightGrey,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: AppColors.primaryBlue, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  action,
                  style: GoogleFonts.openSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppColors.darkBlue,
                  ),
                ),
                Text(
                  time,
                  style: GoogleFonts.openSans(
                    fontSize: 12,
                    color: AppColors.greyText,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showBodyMapDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Skin Analysis',
            style: GoogleFonts.quicksand(
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Select the area of your body affected by eczema for a more detailed assessment.',
                style: GoogleFonts.openSans(color: AppColors.darkBlue),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text(
                'Cancel',
                style: GoogleFonts.openSans(color: AppColors.greyText),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SkinAnalysisPage()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBlue,
              ),
              child: Text(
                'Select Area',
                style: GoogleFonts.openSans(
                  color: AppColors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  /// Build drawer menu with account and logout options
  Widget _buildDrawer() {
    return Drawer(
      child: Container(
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: AppColors.primaryBlue),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  CircleAvatar(
                    radius: 35,
                    backgroundColor: Colors.white,
                    child: Icon(
                      Icons.person,
                      size: 40,
                      color: AppColors.primaryBlue,
                    ),
                  ),
                  SizedBox(height: 12),
                  Text(
                    _currentUser != null
                        ? '${_currentUser!.firstName} ${_currentUser!.lastName}'
                        : 'User',
                    style: GoogleFonts.quicksand(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    _currentUser?.email ?? '',
                    style: GoogleFonts.openSans(
                      fontSize: 14,
                      color: Colors.white70,
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.person, color: AppColors.primaryBlue),
              title: Text(
                'Account',
                style: GoogleFonts.openSans(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: AppColors.darkBlue,
                ),
              ),
              onTap: () async {
                Navigator.pop(context); // Close drawer
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AccountEditPage()),
                );
                // Reload user data when returning from account edit
                _loadUserData();
              },
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.logout, color: Colors.red),
              title: Text(
                'Logout',
                style: GoogleFonts.openSans(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.red,
                ),
              ),
              onTap: () async {
                // Show confirmation dialog
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text(
                      'Logout',
                      style: GoogleFonts.quicksand(fontWeight: FontWeight.bold),
                    ),
                    content: Text(
                      'Are you sure you want to logout?',
                      style: GoogleFonts.openSans(),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: Text(
                          'Cancel',
                          style: GoogleFonts.openSans(
                            color: AppColors.greyText,
                          ),
                        ),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: Text(
                          'Logout',
                          style: GoogleFonts.openSans(
                            color: Colors.red,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                );

                if (confirm == true) {
                  // Clear session
                  await _sessionService.clearSession();
                  // Sign out
                  await _authService.signOut();

                  if (mounted) {
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => LoginPage()),
                          (route) => false,
                    );
                  }
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
