import 'package:cap2439is_eczema/screens/dashboard/skin_analysis_history_page.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_header.dart';
import '../../core/constants/app_bottom_navigation.dart';
import 'dart:math' as math;

import 'manual_easi_page.dart';

final Map<String, List<String>> bodyPartCategories = {
  'Head & Face': ['Forehead', 'Left Cheek', 'Right Cheek', 'Chin', 'Nose'],
  'Neck & Shoulders': ['Front Neck', 'Back Neck', 'Left Shoulder', 'Right Shoulder'],
  'Arms & Hands': ['Left Arm', 'Right Arm', 'Left Hand', 'Right Hand'],
  'Torso': ['Chest', 'Back', 'Abdomen'],
  'Hips & Groin': ['Hip', 'Groin'],
  'Legs & Feet': ['Left Leg', 'Right Leg', 'Left Foot', 'Right Foot'],
};

class SkinAnalysisResultsPage extends StatelessWidget {
  final String bodyPart;
  final File image;

  const SkinAnalysisResultsPage({
    Key? key,
    required this.bodyPart,
    required this.image,
  }) : super(key: key);

  String _getEASISeverityLabel(int totalScore) {
    if (totalScore == 0) return "No significant EASI features detected";
    if (totalScore <= 3) return "Mild EASI severity";
    if (totalScore <= 6) return "Moderate EASI severity";
    if (totalScore <= 9) return "Severe EASI severity";
    return "Very Severe EASI severity";
  }

  Color _getEASISeverityColor(int totalScore) {
    if (totalScore == 0) return Colors.green;
    if (totalScore <= 3) return Colors.lightGreen;
    if (totalScore <= 6) return Colors.orange;
    if (totalScore <= 9) return Colors.red;
    return Colors.red.shade900;
  }

  // Mock EASI data - simplified to just the four factors
  Map<String, dynamic> _getMockEASIData() {
    return {
      'totalScore': 6, // Total EASI score (sum of 4 factors)
      'factors': [
        {
          'name': 'Erythema',
          'description': 'Redness',
          'score': 2,
          'maxScore': 3,
          'details': 'Moderate redness detected across the analyzed area'
        },
        {
          'name': 'Induration/Papulation',
          'description': 'Swelling/Bumps',
          'score': 3,
          'maxScore': 3,
          'details': 'Significant swelling and raised areas present'
        },
        {
          'name': 'Excoriation',
          'description': 'Scratching Damage',
          'score': 0,
          'maxScore': 3,
          'details': 'No visible scratching damage detected'
        },
        {
          'name': 'Lichenification',
          'description': 'Skin Thickening',
          'score': 1,
          'maxScore': 3,
          'details': 'Mild skin thickening observed'
        }
      ]
    };
  }

  void _showEASIInfoDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: AppColors.backgroundGradient,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.analytics,
                  color: AppColors.primaryBlue,
                  size: 32,
                ),
                const SizedBox(height: 16),
                Text(
                  "EASI SCORE ANALYSIS",
                  style: GoogleFonts.quicksand(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primaryBlue,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  "The Eczema Area and Severity Index (EASI) is a standardized tool used to measure the extent and severity of atopic dermatitis. It evaluates four key signs: erythema (redness), induration/papulation (swelling/bumps), excoriation (scratching damage), and lichenification (skin thickening). Each factor is scored 0-3, with a maximum total of 12.",
                  style: GoogleFonts.openSans(
                    fontSize: 14,
                    color: AppColors.darkBlue,
                    height: 1.5,
                  ),
                  textAlign: TextAlign.justify,
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 44,
                  child: ElevatedButton(
                    onPressed: () => Navigator.of(context).pop(),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryBlue,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
                    ),
                    child: Text('Got it', style: GoogleFonts.openSans(fontSize: 16, fontWeight: FontWeight.w600)),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showFactorDetailsDialog(BuildContext context, Map<String, dynamic> factor) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: AppColors.backgroundGradient,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _getFactorColor(factor['score']).withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    _getFactorIcon(factor['name']),
                    color: _getFactorColor(factor['score']),
                    size: 32,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  factor['name'].toUpperCase(),
                  style: GoogleFonts.quicksand(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primaryBlue,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  factor['description'],
                  style: GoogleFonts.openSans(
                    fontSize: 14,
                    color: AppColors.greyText,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  factor['details'],
                  style: GoogleFonts.openSans(
                    fontSize: 14,
                    color: AppColors.darkBlue,
                    height: 1.5,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _getFactorColor(factor['score']).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Score: ",
                        style: GoogleFonts.openSans(
                          fontSize: 16,
                          color: AppColors.darkBlue,
                        ),
                      ),
                      Text(
                        "${factor['score']}/${factor['maxScore']}",
                        style: GoogleFonts.quicksand(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: _getFactorColor(factor['score']),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 44,
                  child: ElevatedButton(
                    onPressed: () => Navigator.of(context).pop(),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryBlue,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
                    ),
                    child: Text('Close', style: GoogleFonts.openSans(fontSize: 16, fontWeight: FontWeight.w600)),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final easiData = _getMockEASIData();
    final totalScore = easiData['totalScore'] as int;
    final factors = easiData['factors'] as List<Map<String, dynamic>>;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppColors.backgroundGradient,
        ),
        child: SafeArea(
          child: Column(
            children: [
              AppHeader(
                title: "EASI Results",
                showMenu: true,
                showSync: true,
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      // Header with disclaimer
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: AppColors.primaryBlue,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(
                          children: [
                            Text(
                              "EASI Analysis Results",
                              style: GoogleFonts.quicksand(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              "Disclaimer: This is not a medical diagnosis. Please consult your Doctor for any advice.",
                              style: GoogleFonts.openSans(
                                fontSize: 12,
                                color: Colors.white.withOpacity(0.9),
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              "${DateTime.now().month.toString().padLeft(2, '0')}/${DateTime.now().day.toString().padLeft(2, '0')}/${DateTime.now().year} (${_getCurrentTime()})",
                              style: GoogleFonts.openSans(
                                fontSize: 12,
                                color: Colors.white.withOpacity(0.8),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      // Body part and image
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Analyzed Area: $bodyPart",
                              style: GoogleFonts.openSans(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: AppColors.darkBlue,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Container(
                              height: 200,
                              width: double.infinity,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                image: DecorationImage(
                                  image: FileImage(image),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      // 1. Total EASI Score Gauge
                      _buildEASIScoreGauge(context, totalScore),

                      const SizedBox(height: 24),

                      // 2. EASI Factors List
                      _buildEASIFactorsList(factors, context),

                      const SizedBox(height: 24),

                      // Action buttons
                      Column(
                        children: [
                          SizedBox(
                            width: double.infinity,
                            height: 52,
                            child: ElevatedButton.icon(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                    const SkinAnalysisHistoryPage(),
                                  ),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.primaryBlue,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(26),
                                ),
                              ),
                              icon: const Icon(Icons.history),
                              label: Text(
                                'View History',
                                style: GoogleFonts.openSans(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(height: 12),

                          // New Manual Calculate EASI button
                          SizedBox(
                            width: double.infinity,
                            height: 52,
                            child: ElevatedButton.icon(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                    const ManualEASIPage(),
                                  ),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.lightBlue,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(26),
                                ),
                              ),
                              icon: const Icon(Icons.calculate),
                              label: Text(
                                'Manual Calculate EASI',
                                style: GoogleFonts.openSans(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              AppBottomNavigation(
                currentIndex: 0,
                onTap: (index) {},
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEASIScoreGauge(BuildContext context, int totalScore) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white,
            Colors.grey.shade50,
          ],
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 20,
            offset: const Offset(0, 8),
            spreadRadius: -4,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Total EASI Score",
                style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: AppColors.darkBlue,
                  letterSpacing: -0.5,
                ),
              ),
              GestureDetector(
                onTap: () => _showEASIInfoDialog(context),
                child: Icon(
                  Icons.info_outline,
                  color: AppColors.primaryBlue,
                  size: 20,
                ),
              ),
            ],
          ),
          const SizedBox(height: 32),

          // Enhanced Gauge for EASI Score (0-12)
          Container(
            width: 220,
            height: 160,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 200,
                  height: 200,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: _getEASISeverityColor(totalScore).withOpacity(0.1),
                        blurRadius: 20,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                ),

                CustomPaint(
                  size: const Size(200, 200),
                  painter: EASIGaugePainter(
                    score: totalScore,
                    maxScore: 12,
                    color: _getEASISeverityColor(totalScore),
                  ),
                ),

                Positioned(
                  bottom: 20,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: _getEASISeverityColor(totalScore).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          "$totalScore",
                          style: GoogleFonts.inter(
                            fontSize: 36,
                            fontWeight: FontWeight.w800,
                            color: _getEASISeverityColor(totalScore),
                            height: 1,
                          ),
                        ),
                      ),

                      const SizedBox(height: 8),

                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF8FAFC),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: _getEASISeverityColor(totalScore).withOpacity(0.2),
                            width: 1,
                          ),
                        ),
                        child: Text(
                          _getEASISeverityLabel(totalScore).split(' ').sublist(0, 2).join(' '),
                          style: GoogleFonts.inter(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: _getEASISeverityColor(totalScore),
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),

                      const SizedBox(height: 4),

                      Text(
                        "out of 12",
                        style: GoogleFonts.inter(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: const Color(0xFF64748B),
                          letterSpacing: 0.3,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEASIFactorsList(List<Map<String, dynamic>> factors, BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "EASI Factors Breakdown",
            style: GoogleFonts.openSans(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
            ),
          ),
          const SizedBox(height: 16),
          ...factors.map((factor) => Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: _buildFactorListItem(factor, context),
          )).toList(),
        ],
      ),
    );
  }

  Widget _buildFactorListItem(Map<String, dynamic> factor, BuildContext context) {
    return GestureDetector(
      onTap: () => _showFactorDetailsDialog(context, factor),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _getFactorColor(factor['score']).withOpacity(0.05),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: _getFactorColor(factor['score']).withOpacity(0.2),
            width: 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: _getFactorColor(factor['score']).withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                _getFactorIcon(factor['name']),
                color: _getFactorColor(factor['score']),
                size: 24,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    factor['name'],
                    style: GoogleFonts.openSans(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: AppColors.darkBlue,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    factor['description'],
                    style: GoogleFonts.openSans(
                      fontSize: 12,
                      color: AppColors.greyText,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    height: 6,
                    decoration: BoxDecoration(
                      color: AppColors.lightGrey,
                      borderRadius: BorderRadius.circular(3),
                    ),
                    child: FractionallySizedBox(
                      alignment: Alignment.centerLeft,
                      widthFactor: factor['score'] / factor['maxScore'],
                      child: Container(
                        decoration: BoxDecoration(
                          color: _getFactorColor(factor['score']),
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: _getFactorColor(factor['score']).withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                "${factor['score']}/3",
                style: GoogleFonts.quicksand(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: _getFactorColor(factor['score']),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getFactorColor(int score) {
    if (score == 0) return Colors.green;
    if (score == 1) return Colors.yellow.shade700;
    if (score == 2) return Colors.orange;
    return Colors.red;
  }

  IconData _getFactorIcon(String factorName) {
    switch (factorName.toLowerCase()) {
      case 'erythema':
        return Icons.circle;
      case 'induration/papulation':
        return Icons.bubble_chart;
      case 'excoriation':
        return Icons.gesture;
      case 'lichenification':
        return Icons.texture;
      default:
        return Icons.assessment;
    }
  }

  String _getCurrentTime() {
    final now = DateTime.now();
    final hour = now.hour.toString().padLeft(2, '0');
    final minute = now.minute.toString().padLeft(2, '0');
    return "$hour:$minute";
  }
}

class EASIGaugePainter extends CustomPainter {
  final int score;
  final int maxScore;
  final Color color;

  EASIGaugePainter({
    required this.score,
    required this.maxScore,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width / 2) - 15;

    // Background track
    final backgroundPaint = Paint()
      ..color = const Color(0xFFF1F5F9)
      ..strokeWidth = 16
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      math.pi * 0.75,
      math.pi * 1.5,
      false,
      backgroundPaint,
    );

    // Progress track
    final progressPaint = Paint()
      ..strokeWidth = 16
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final gradient = LinearGradient(
      colors: [
        color.withOpacity(0.6),
        color,
        color.withOpacity(0.9),
      ],
      stops: const [0.0, 0.7, 1.0],
    );

    final rect = Rect.fromCircle(center: center, radius: radius);
    progressPaint.shader = gradient.createShader(rect);

    final sweepAngle = (score / maxScore) * math.pi * 1.5;

    canvas.drawArc(
      rect,
      math.pi * 0.75,
      sweepAngle,
      false,
      progressPaint,
    );

    // Add tick marks for EASI scale
    _drawTickMarks(canvas, center, radius);
  }

  void _drawTickMarks(Canvas canvas, Offset center, double radius) {
    final tickPaint = Paint()
      ..color = const Color(0xFFCBD5E1)
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;

    for (int i = 0; i <= maxScore; i += 3) {
      final angle = math.pi * 0.75 + (i / maxScore) * math.pi * 1.5;
      final startRadius = radius + 8;
      final endRadius = radius + 15;

      final start = Offset(
        center.dx + math.cos(angle) * startRadius,
        center.dy + math.sin(angle) * startRadius,
      );

      final end = Offset(
        center.dx + math.cos(angle) * endRadius,
        center.dy + math.sin(angle) * endRadius,
      );

      canvas.drawLine(start, end, tickPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
