import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_styles.dart';
import '../../core/constants/app_header.dart';
import '../../core/constants/app_bottom_navigation.dart';
import 'dart:math' as math;

import '../../services/assessment_service.dart';

/// PoemHistoryPage - Displays the user’s past POEM assessments
///
/// This screen shows a chronological list of all completed Patient-Oriented Eczema Measure (POEM)
/// assessments stored in the application. It allows users to review their eczema symptom progression,
/// view detailed results for each past entry, and monitor trends over time.
///
/// Key Features:
/// - Displays a scrollable list of completed POEM assessments
/// - Highlights the latest assessment entry for quick identification
/// - Shows each assessment’s date, time, severity level, and total score
/// - Opens a detailed dialog with per-question scores and severity indicators
/// - Shows an empty state when no assessments have been completed yet
///
/// User Interactions:
/// - Tap an assessment card: Opens a detailed dialog with score breakdown and metadata
/// - “Take First Assessment” button (empty state): Returns to dashboard to begin a new POEM test
/// - AppHeader menu and sync icons: Provide quick navigation and refresh options
///
/// Data Flow:
/// - Fetches assessment history from AssessmentService upon initialization
/// - Dynamically updates the list when data is loaded
/// - Performs read-only data operations (no editing or deletion)
/// - Formats stored dates and scores into readable formats for display

class PoemHistoryPage extends StatefulWidget {
  const PoemHistoryPage({Key? key}) : super(key: key);

  @override
  State<PoemHistoryPage> createState() => _PoemHistoryPageState();
}

class _PoemHistoryPageState extends State<PoemHistoryPage> {
  List<Map<String, dynamic>> _assessments = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  /// Loads the list of completed POEM assessments from the AssessmentService.
  /// Updates the state once the data is retrieved.
  Future<void> _loadHistory() async {
    final history = await AssessmentService.getAssessmentHistory();
    setState(() {
      _assessments = history;
      _isLoading = false;
    });
  }

  /// Formats a [DateTime] into a readable string
  String _formatDate(DateTime date) {
    final months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return "${months[date.month - 1]} ${date.day}, ${date.year}";
  }

  /// Formats a [DateTime] into a readable 12-hour time format with AM/PM
  String _formatTime(DateTime date) {
    final hour = date.hour > 12 ? date.hour - 12 : (date.hour == 0 ? 12 : date.hour);
    final period = date.hour >= 12 ? 'PM' : 'AM';
    return "$hour:${date.minute.toString().padLeft(2, '0')} $period";
  }

  /// Determines the eczema severity level based on the given POEM [score]
  String _getSeverityLevel(int score) {
    if (score <= 2) return "Clear or almost clear";
    if (score <= 7) return "Mild eczema";
    if (score <= 16) return "Moderate eczema";
    if (score <= 24) return "Severe eczema";
    return "Very severe eczema";
  }

  /// Returns a color corresponding to the eczema severity level
  Color _getSeverityColor(int score) {
    if (score <= 2) return Colors.green;
    if (score <= 7) return Colors.yellow.shade700;
    if (score <= 16) return Colors.orange;
    if (score <= 24) return Colors.red;
    return Colors.red.shade900;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppColors.backgroundGradient,
        ),
        child: SafeArea(
          child: Column(
            children: [
              AppHeader(
                title: "POEM History",
                showMenu: true,
                showSync: true,
              ),
              Expanded(
                child: _isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : _assessments.isEmpty
                    ? _buildEmptyState()
                    : _buildHistoryList(),
              ),
              AppBottomNavigation(
                currentIndex: 0,
                onTap: (index) {},
              ),

            ],
          ),
        ),
      ),
    );
  }

  /// Builds the UI shown when there are no completed POEM assessments
  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.assignment_outlined,
              size: 80,
              color: AppColors.greyText,
            ),
            const SizedBox(height: 24),
            Text(
              "No Assessments Yet",
              style: AppTextStyles.headingQuicksand.copyWith(
                fontSize: 24,
                color: AppColors.darkBlue,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              "Complete your first POEM assessment to start tracking your eczema symptoms.",
              style: AppTextStyles.subtextOpenSans.copyWith(
                color: AppColors.greyText,
                fontSize: 16,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBlue,
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
              ),
              child: Text(
                "Take First Assessment",
                style: AppTextStyles.buttonText,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Builds the scrollable list of past POEM assessments
  Widget _buildHistoryList() {
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            itemCount: _assessments.length,
            itemBuilder: (context, index) {
              final assessment = _assessments[index];
              final date = DateTime.parse(assessment['date']);
              return _buildHistoryItem(assessment, date, index);
            },
          ),
        ),
      ],
    );
  }

  /// Builds a visual component representing a single assessment record.
  Widget _buildHistoryItem(Map<String, dynamic> assessment, DateTime date, int index) {
    final score = assessment['totalScore'];
    final isLatest = index == 0;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(12),
        border: isLatest ? Border.all(color: AppColors.primaryBlue, width: 2) : null,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => _showDetailDialog(assessment, date),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                // Score circle
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: _getSeverityColor(score).withOpacity(0.1),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _getSeverityColor(score),
                      width: 2,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      "$score",
                      style: AppTextStyles.headingQuicksand.copyWith(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: _getSeverityColor(score),
                      ),
                    ),
                  ),
                ),

                const SizedBox(width: 16),

                // Details
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            _formatDate(date),
                            style: AppTextStyles.subtextOpenSans.copyWith(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: AppColors.darkBlue,
                            ),
                          ),
                          if (isLatest)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: AppColors.primaryBlue,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                "LATEST",
                                style: AppTextStyles.subtextOpenSans.copyWith(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                        ],
                      ),
                      Text(
                        _formatTime(date),
                        style: AppTextStyles.subtextOpenSans.copyWith(
                          color: AppColors.greyText,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _getSeverityColor(score).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          _getSeverityLevel(score),
                          style: AppTextStyles.subtextOpenSans.copyWith(
                            color: _getSeverityColor(score),
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                Icon(
                  Icons.chevron_right,
                  color: AppColors.greyText,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Displays a dialog containing full details of a specific assessment.
  /// Includes total score, severity level, timestamp, and per-question breakdown.
  void _showDetailDialog(Map<String, dynamic> assessment, DateTime date) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Assessment Details",
                    style: AppTextStyles.headingQuicksand.copyWith(
                      fontSize: 20,
                      color: AppColors.darkBlue,
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Score and date
              Row(
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      color: _getSeverityColor(assessment['totalScore']).withOpacity(0.1),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: _getSeverityColor(assessment['totalScore']),
                        width: 3,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        "${assessment['totalScore']}",
                        style: AppTextStyles.headingQuicksand.copyWith(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: _getSeverityColor(assessment['totalScore']),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 20),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "${assessment['totalScore']}/28",
                          style: AppTextStyles.subtextOpenSans.copyWith(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: AppColors.darkBlue,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: _getSeverityColor(assessment['totalScore']).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            _getSeverityLevel(assessment['totalScore']),
                            style: AppTextStyles.subtextOpenSans.copyWith(
                              color: _getSeverityColor(assessment['totalScore']),
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "${_formatDate(date)} at ${_formatTime(date)}",
                          style: AppTextStyles.subtextOpenSans.copyWith(
                            color: AppColors.greyText,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 24),

              // Individual question scores
              Text(
                "Question Scores",
                style: AppTextStyles.subtextOpenSans.copyWith(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: AppColors.darkBlue,
                ),
              ),
              const SizedBox(height: 12),

              Container(
                constraints: const BoxConstraints(maxHeight: 200),
                child: SingleChildScrollView(
                  child: Column(
                    children: List.generate(7, (index) {
                      final questions = [
                        "Itchy skin",
                        "Sleep disrupted",
                        "Bleeding skin",
                        "Weeping/oozing",
                        "Cracked skin",
                        "Flaky skin",
                        "Dry/rough skin"
                      ];

                      final score = assessment['answers'][index] ?? 0;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                "${index + 1}. ${questions[index]}",
                                style: AppTextStyles.subtextOpenSans.copyWith(
                                  fontSize: 13,
                                  color: AppColors.darkBlue,
                                ),
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: AppColors.lightGrey,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                "$score",
                                style: AppTextStyles.subtextOpenSans.copyWith(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.darkBlue,
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}