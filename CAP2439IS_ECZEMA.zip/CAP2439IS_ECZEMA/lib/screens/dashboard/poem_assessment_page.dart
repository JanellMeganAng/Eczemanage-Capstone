import 'package:cap2439is_eczema/screens/dashboard/poem_results_page.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_styles.dart';
import '../../core/constants/app_button_styles.dart';
import '../../core/constants/app_header.dart';
import '../../core/constants/app_bottom_navigation.dart';
import '../../services/assessment_service.dart';

/// PoemAssessmentPage - Patient-Oriented Eczema Measure (POEM) Questionnaire
///
/// This screen allows users to complete the POEM assessment, a standardized
/// seven-question survey that measures eczema severity based on symptoms
/// experienced over the past week.
///
/// Key Features:
/// - Step-based symptom questionnaire with auto-scrolling
/// - Interactive score selection (0–4 scale)
/// - Automatic total score calculation and severity classification
/// - Data saved locally via AssessmentService
///
/// User Interactions:
/// - Selects response for each question (number of days affected)
/// - Automatically scrolls to the next question
/// - Views "Done" button once all questions are answered
/// - Can review results summary after submission
///
/// Data Flow:
/// - Saves assessment data via AssessmentService
/// - Passes total score and answers to PoemResultsPage

class PoemAssessmentPage extends StatefulWidget {
  const PoemAssessmentPage({Key? key}) : super(key: key);

  @override
  State<PoemAssessmentPage> createState() => _PoemAssessmentPageState();
}

class _PoemAssessmentPageState extends State<PoemAssessmentPage> {
  List<int?> answers = List.filled(7, null);
  final ScrollController _scrollController = ScrollController();

  final List<String> questions = [
    "Over the last week, on how many days has your/your child's skin been itchy because of the eczema?",
    "Over the last week, on how many days has your/your child's sleep been disturbed because of the eczema?",
    "Over the last week, on how many days has your/your child's skin been bleeding because of the eczema?",
    "Over the last week, on how many days has your/your child's skin been weeping or oozing clear fluid because of the eczema?",
    "Over the last week, on how many days has your/your child's skin been cracked because of the eczema?",
    "Over the last week, on how many days has your/your child's skin been flaky because of the eczema?",
    "Over the last week, on how many days has your/your child's skin felt dry or rough because of the eczema?"
  ];

  final List<String> scoreLabels = ["0", "1-2", "3-4", "5-6", "7"];
  final List<int> scoreValues = [0, 1, 2, 3, 4];

  int get visibleQuestions {
    for (int i = 0; i < answers.length; i++) {
      if (answers[i] == null) return i + 1;
    }
    return answers.length;
  }

  bool get allQuestionsAnswered => answers.every((a) => a != null);

  int get totalScore => answers.fold(0, (sum, a) => sum + (a ?? 0));

  /// Returns the severity level interpretation based on total POEM score.
  ///
  /// Severity Classification:
  /// - 0–2: Clear or almost clear
  /// - 3–7: Mild eczema
  /// - 8–16: Moderate eczema
  /// - 17–24: Severe eczema
  /// - ≥25: Very severe eczema
  ///
  /// Used to provide readable feedback after assessment completion.

  String getSeverityLevel(int score) {
    if (score <= 2) return "Clear or almost clear";
    if (score <= 7) return "Mild eczema";
    if (score <= 16) return "Moderate eczema";
    if (score <= 24) return "Severe eczema";
    return "Very severe eczema";
  }

  /// Handles user answer selection for a given question.
  ///
  /// Updates the [answers] list with the chosen score value, then:
  /// - Automatically scrolls to the next question after a short delay.
  /// - If all questions are answered, scrolls to the end to reveal the "DONE" button.
  ///
  /// Parameters:
  /// - `questionIndex`: Index of the current question.
  /// - `value`: The numerical score selected (0–4).

  void selectAnswer(int questionIndex, int value) {
    setState(() {
      answers[questionIndex] = value;
    });

    if (questionIndex < questions.length - 1) {
      Future.delayed(const Duration(milliseconds: 300), () {
        _scrollToNextQuestion(questionIndex + 1);
      });
    } else if (allQuestionsAnswered) {
      Future.delayed(const Duration(milliseconds: 300), () {
        if (_scrollController.hasClients) {
          _scrollController.animateTo(
            _scrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 500),
            curve: Curves.easeInOut,
          );
        }
      });
    }
  }

  void _scrollToNextQuestion(int questionIndex) {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        (questionIndex * 200.0),
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    }
  }

  /// Saves the completed POEM assessment and navigates to the results page.
  ///
  /// Process:
  /// 1. Saves the total score, answers, and severity level locally
  ///    using [AssessmentService.saveAssessment].
  /// 2. Navigates to [PoemResultsPage] and passes the computed data.
  /// 3. Returns to the previous screen with a success status upon completion.
  ///
  /// Called when the user presses the "DONE" button after answering all questions.

  Future<void> _saveAndProceed() async {
    // Save the assessment
    await AssessmentService.saveAssessment(
      totalScore: totalScore,
      answers: answers,
      severityLevel: getSeverityLevel(totalScore),
    );

    // Navigate to results
    if (mounted) {
      final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) =>
              PoemResultsPage(
                totalScore: totalScore,
                answers: answers,
              ),
        ),
      );

      // Return to previous screen with success result
      Navigator.pop(context, true);
    }
  }

  /// Builds the main POEM Assessment screen layout.
  ///
  /// Contains:
  /// - App header with title and info button
  /// - Instructional header card describing POEM purpose
  /// - Sequential question cards with dynamic visibility
  /// - "DONE" button shown only when all questions are answered
  /// - Bottom navigation bar for consistent app layout
  ///
  /// Uses gradient background for consistent app theme.

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppColors.backgroundGradient,
        ),
        child: SafeArea(
          child: Column(
            children: [
              AppHeader(
                title: "POEM Assessment",
                showMenu: true,
                showSync: true,
              ),
              Expanded(
                child: SingleChildScrollView(
                  controller: _scrollController,
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    children: [
                      // Header section
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: AppColors.lightGrey,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  "POEM",
                                  style: AppTextStyles.headingQuicksand
                                      .copyWith(
                                    fontSize: 28,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                GestureDetector(
                                  onTap: () {
                                    showDialog(
                                      context: context,
                                      builder: (context) =>
                                          AlertDialog(
                                            title: const Text("What is POEM?"),
                                            content: Text(
                                              "The Patient-Oriented Eczema Measure (POEM) is a questionnaire used "
                                                  "to assess the severity of eczema based on symptoms experienced over "
                                                  "the past week. It helps track how eczema affects daily life, monitor "
                                                  "treatment progress, and support better communication with healthcare providers.",
                                              style: AppTextStyles
                                                  .subtextOpenSans.copyWith(
                                                color: AppColors.greyText,
                                                height: 1.5,
                                              ),
                                              textAlign: TextAlign.justify,
                                            ),
                                            actions: [
                                              TextButton(
                                                onPressed: () =>
                                                    Navigator.pop(context),
                                                child: Text(
                                                  "Close",
                                                  style: AppTextStyles
                                                      .subtextOpenSans.copyWith(
                                                    color: AppColors
                                                        .primaryBlue,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                    );
                                  },
                                  child: Container(
                                    width: 20,
                                    height: 20,
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          color: AppColors.primaryBlue),
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Center(
                                      child: Icon(
                                        Icons.info_outline,
                                        size: 12,
                                        color: AppColors.primaryBlue,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            Text(
                              "Complete the POEM questionnaire once a week to track changes in your skin condition.",
                              style: AppTextStyles.subtextOpenSans.copyWith(
                                color: AppColors.greyText,
                              ),
                            ),
                            const SizedBox(height: 24),
                            Text(
                              "Please answer the questions below:",
                              style: AppTextStyles.subtextOpenSans.copyWith(
                                color: AppColors.darkBlue,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 32),

                      // Questions
                      ...List.generate(visibleQuestions, (index) {
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 24),
                          child: _buildQuestionWidget(index),
                        );
                      }),

                      if (allQuestionsAnswered) ...[
                        const SizedBox(height: 24),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: _saveAndProceed,
                            style: AppButtonStyles.primaryButton,
                            child: const Text("DONE"),
                          ),
                        ),
                        const SizedBox(height: 32),
                      ],
                      Align(
                        alignment: Alignment.centerLeft,
                        child: ElevatedButton.icon(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          icon: const Icon(Icons.arrow_back),
                          label: const Text("Back"),
                        ),
                      )
                    ],
                  ),
                ),
              ),
              AppBottomNavigation(
                currentIndex: 0,
                onTap: (index) {},
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Builds an individual question card for the POEM questionnaire.
  ///
  /// Each card displays:
  /// - The question text
  /// - Five circular buttons representing score options (0–4)
  ///
  /// When the user selects an answer:
  /// - The corresponding score is stored in `answers`
  /// - The UI updates instantly to highlight the selected value
  /// - Automatically scrolls to the next question
  ///
  /// Parameters:
  /// - `questionIndex`: The index of the current question in the list
  ///
  /// Returns:
  /// A styled [Container] widget with question text and selectable score buttons.

  Widget _buildQuestionWidget(int questionIndex) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.primaryBlue,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "${questionIndex + 1}. ${questions[questionIndex]}",
            style: AppTextStyles.subtextOpenSans.copyWith(
              color: AppColors.white,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(5, (index) {
              final isSelected = answers[questionIndex] == scoreValues[index];
              return GestureDetector(
                onTap: () => selectAnswer(questionIndex, scoreValues[index]),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: isSelected ? AppColors.white : Colors.transparent,
                    border: Border.all(color: AppColors.white, width: 2),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      scoreLabels[index],
                      style: AppTextStyles.buttonText.copyWith(
                        color: isSelected ? AppColors.primaryBlue : AppColors
                            .white,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}