import 'package:cap2439is_eczema/screens/dashboard/skin_analysis_history_page.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_bottom_navigation.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_header.dart';

/// ManualEASIPage - Manual Eczema Area and Severity Index (EASI) Assessment Screen
///
/// This screen allows users to manually compute their EASI score by evaluating
/// eczema severity and affected area across four body regions.
/// It guides the user through a step-by-step form and displays the calculated result.
///
/// Key Features:
/// - Step-based assessment flow for each body region
/// - Interactive sliders and buttons for rating symptom severity and area
/// - Auto-calculated EASI score and severity interpretation
/// - Age-based scoring adjustment (under 8 years vs. 8 years and older)
///
/// User Interactions:
/// - Selects age group for correct multipliers
/// - Rates severity for each region and symptom
/// - Navigates between steps to complete assessment
/// - Views results summary and severity breakdown
///
/// Data Flow:
/// - Stores assessment data locally in-state
/// - Results are computed dynamically

class ManualEASIPage extends StatefulWidget {
  const ManualEASIPage({Key? key}) : super(key: key);

  @override
  State<ManualEASIPage> createState() => _ManualEASIPageState();
}

class _ManualEASIPageState extends State<ManualEASIPage> {
  int currentStep = 0;
  bool isUnder8Years = false;

  // Body regions data
  final List<String> bodyRegions = [
    'Head & Neck',
    'Upper Extremities',
    'Trunk',
    'Lower Extremities'
  ];

  // Assessment data for each region
  Map<String, Map<String, int>> assessmentData = {
    'Head & Neck': {
      'erythema': 0,
      'edema': 0,
      'excoriation': 0,
      'lichenification': 0,
      'area': 0,
    },
    'Upper Extremities': {
      'erythema': 0,
      'edema': 0,
      'excoriation': 0,
      'lichenification': 0,
      'area': 0,
    },
    'Trunk': {
      'erythema': 0,
      'edema': 0,
      'excoriation': 0,
      'lichenification': 0,
      'area': 0,
    },
    'Lower Extremities': {
      'erythema': 0,
      'edema': 0,
      'excoriation': 0,
      'lichenification': 0,
      'area': 0,
    },
  };

  /// Returns EASI body region multipliers based on age group
  Map<String, double> get multipliers => isUnder8Years
      ? {
    'Head & Neck': 0.2,
    'Upper Extremities': 0.2,
    'Trunk': 0.3,
    'Lower Extremities': 0.3,
  }
      : {
    'Head & Neck': 0.1,
    'Upper Extremities': 0.2,
    'Trunk': 0.3,
    'Lower Extremities': 0.4,
  };

  /// Converts the area score (0–6) to a percentage description
  String getAreaScoreText(int score) {
    switch (score) {
      case 0: return '0% (No involvement)';
      case 1: return '1-9%';
      case 2: return '10-29%';
      case 3: return '30-49%';
      case 4: return '50-69%';
      case 5: return '70-89%';
      case 6: return '90-100%';
      default: return '0%';
    }
  }

  /// Returns a readable severity label for each symptom score
  String getSeverityDescription(String symptom, int score) {
    Map<String, List<String>> descriptions = {
      'erythema': ['None', 'Mild', 'Moderate', 'Severe'],
      'edema': ['None', 'Mild swelling', 'Moderate swelling', 'Severe swelling'],
      'excoriation': ['None', 'Mild scratching', 'Moderate scratching', 'Severe scratching'],
      'lichenification': ['None', 'Mild thickening', 'Moderate thickening', 'Severe thickening'],
    };
    return descriptions[symptom]?[score] ?? 'None';
  }

  /// Calculates the total score for a specific body region
  double calculateRegionScore(String region) {
    final data = assessmentData[region]!;
    final severitySum = data['erythema']! + data['edema']! +
        data['excoriation']! + data['lichenification']!;
    final areaScore = data['area']!;
    final multiplier = multipliers[region]!;

    return severitySum * areaScore * multiplier;
  }

  /// Calculates the overall EASI score across all body regions
  double calculateTotalEasiScore() {
    double total = 0;
    for (String region in bodyRegions) {
      total += calculateRegionScore(region);
    }
    return total;
  }

  /// Interprets EASI score into severity classification
  String getSeverityInterpretation(double score) {
    if (score <= 1.0) return 'Clear';
    if (score <= 7.0) return 'Mild';
    if (score <= 21.0) return 'Moderate';
    if (score <= 50.0) return 'Severe';
    return 'Very Severe';
  }

  /// Returns a color corresponding to severity level
  Color getSeverityColor(double score) {
    if (score <= 1.0) return Colors.green;
    if (score <= 7.0) return Colors.lightGreen;
    if (score <= 21.0) return Colors.orange;
    if (score <= 50.0) return Colors.deepOrange;
    return Colors.red;
  }

  /// Displays an informational dialog explaining EASI scoring
  void _showInfoDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("What is EASI?"),
        content: Text(
          "The Eczema Area and Severity Index (EASI) is a standardized scoring system used to assess the severity and extent of eczema. It evaluates four symptoms (redness, swelling, scratching, and thickening) across four body regions, with scores ranging from 0-72. This manual assessment allows you to calculate your own EASI score by evaluating the affected area percentage and symptom severity for each body region. The manual EASI calculator is based on the version developed by Dr. Blake Mumford, a dermatologist at Skill Health Institute.",
          style: GoogleFonts.openSans(
            color: AppColors.greyText,
            height: 1.5,
          ),
          textAlign: TextAlign.justify,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Close",
              style: GoogleFonts.openSans(
                color: AppColors.primaryBlue,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Builds the overall page layout and controls step-based navigation
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppColors.backgroundGradient,
        ),
        child: SafeArea(
          child: Stack(
            children: [
              Column(
                children: [
                  AppHeader(
                    title: "Manual EASI",
                    showMenu: true,
                    showSync: true,
                  ),
                  Expanded(
                    child: currentStep == 0
                        ? _buildAgeSelection()
                        : currentStep <= 4
                        ? _buildRegionAssessment()
                        : _buildResultsPage(),
                  ),
                  AppBottomNavigation(
                    currentIndex: 0,
                    onTap: (index) {},
                  ),
                ],
              ),
              Positioned(
                top: 16,
                right: 110,
                child: GestureDetector(
                  onTap: _showInfoDialog,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    child: Icon(
                      Icons.info_outline,
                      color: AppColors.primaryBlue,
                      size: 20,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Step 1: Builds the age group selection screen
  ///
  /// Users choose between “Under 8 Years” or “8 Years and Older”
  /// which determines the EASI region multipliers.
  Widget _buildAgeSelection() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Patient Age Group',
            style: GoogleFonts.quicksand(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Please select the appropriate age group as this affects the calculation multipliers.',
            style: GoogleFonts.openSans(
              fontSize: 14,
              color: AppColors.greyText,
            ),
          ),
          const SizedBox(height: 30),
          _buildAgeOption(false, '8 Years and Older', 'Standard adult multipliers'),
          const SizedBox(height: 16),
          _buildAgeOption(true, 'Under 8 Years', 'Adjusted multipliers for children'),
          const Spacer(),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                setState(() {
                  currentStep = 1;
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBlue,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(
                'Continue',
                style: GoogleFonts.openSans(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Builds each selectable age option container
  Widget _buildAgeOption(bool value, String title, String subtitle) {
    return GestureDetector(
      onTap: () {
        setState(() {
          isUnder8Years = value;
        });
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.white.withOpacity(0.8),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isUnder8Years == value
                ? AppColors.primaryBlue
                : Colors.transparent,
            width: 2,
          ),
        ),
        child: Row(
          children: [
            Radio<bool>(
              value: value,
              groupValue: isUnder8Years,
              onChanged: (bool? newValue) {
                setState(() {
                  isUnder8Years = newValue ?? false;
                });
              },
              activeColor: AppColors.primaryBlue,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.quicksand(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: AppColors.darkBlue,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: GoogleFonts.openSans(
                      fontSize: 12,
                      color: AppColors.greyText,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Step 2–5: Builds the assessment screen for each body region
  Widget _buildRegionAssessment() {
    String currentRegion = bodyRegions[currentStep - 1];

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Progress indicator
          Container(
            margin: const EdgeInsets.only(bottom: 20),
            child: Row(
              children: [
                ...List.generate(4, (index) {
                  return Expanded(
                    child: Container(
                      height: 4,
                      margin: const EdgeInsets.only(right: 4),
                      decoration: BoxDecoration(
                        color: index < currentStep - 1
                            ? AppColors.primaryBlue
                            : AppColors.lightGrey.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  );
                }),
              ],
            ),
          ),

          Text(
            currentRegion,
            style: GoogleFonts.quicksand(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
            ),
          ),
          Text(
            'Step ${currentStep} of 4',
            style: GoogleFonts.openSans(
              fontSize: 14,
              color: AppColors.greyText,
            ),
          ),
          const SizedBox(height: 24),

          // Area assessment
          _buildAreaAssessment(currentRegion),
          const SizedBox(height: 24),

          // Severity assessments
          _buildSeverityAssessment(currentRegion, 'erythema', 'Erythema (Redness)'),
          const SizedBox(height: 20),
          _buildSeverityAssessment(currentRegion, 'edema', 'Edema/Papulation (Swelling)'),
          const SizedBox(height: 20),
          _buildSeverityAssessment(currentRegion, 'excoriation', 'Excoriation (Scratching)'),
          const SizedBox(height: 20),
          _buildSeverityAssessment(currentRegion, 'lichenification', 'Lichenification (Thickening)'),

          const SizedBox(height: 30),

          // Navigation buttons
          Row(
            children: [
              if (currentStep > 1)
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      setState(() {
                        currentStep--;
                      });
                    },
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: AppColors.primaryBlue),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text(
                      'Previous',
                      style: GoogleFonts.openSans(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.primaryBlue,
                      ),
                    ),
                  ),
                ),
              if (currentStep > 1) const SizedBox(width: 16),
              Expanded(
                child: ElevatedButton(
                  onPressed: () {
                    setState(() {
                      currentStep++;
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryBlue,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    currentStep == 4 ? 'View Results' : 'Next',
                    style: GoogleFonts.openSans(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Builds the area involvement selector for each region
  Widget _buildAreaAssessment(String region) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.white.withOpacity(0.8),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Area of Involvement',
            style: GoogleFonts.quicksand(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'What percentage of this body region is affected by eczema?',
            style: GoogleFonts.openSans(
              fontSize: 12,
              color: AppColors.darkBlue,
            ),
          ),
          const SizedBox(height: 16),
          ...List.generate(7, (index) {
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              child: RadioListTile<int>(
                value: index,
                groupValue: assessmentData[region]!['area'],
                onChanged: (int? value) {
                  setState(() {
                    assessmentData[region]!['area'] = value ?? 0;
                  });
                },
                title: Text(
                  getAreaScoreText(index),
                  style: GoogleFonts.openSans(
                    fontSize: 14,
                    color: AppColors.darkBlue,
                  ),
                ),
                activeColor: AppColors.primaryBlue,
                contentPadding: EdgeInsets.zero,
                dense: true,
              ),
            );
          }),
        ],
      ),
    );
  }

  /// Builds a symptom severity selector (0–3) for each symptom
  Widget _buildSeverityAssessment(String region, String symptom, String title) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.white.withOpacity(0.8),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.quicksand(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: List.generate(4, (index) {
              bool isSelected = assessmentData[region]![symptom] == index;
              return Expanded(
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      assessmentData[region]![symptom] = index;
                    });
                  },
                  child: Container(
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppColors.primaryBlue.withOpacity(0.1)
                          : AppColors.lightGrey.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: isSelected
                            ? AppColors.primaryBlue
                            : Colors.transparent,
                        width: 2,
                      ),
                    ),
                    child: Column(
                      children: [
                        Text(
                          '$index',
                          style: GoogleFonts.quicksand(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: isSelected
                                ? AppColors.primaryBlue
                                : AppColors.darkBlue,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          getSeverityDescription(symptom, index),
                          textAlign: TextAlign.center,
                          style: GoogleFonts.openSans(
                            fontSize: 10,
                            color: AppColors.darkBlue,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  /// Final step: Displays total EASI score, regional breakdown, and severity guide
  Widget _buildResultsPage() {
    double totalScore = calculateTotalEasiScore();
    String severity = getSeverityInterpretation(totalScore);
    Color severityColor = getSeverityColor(totalScore);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'EASI Assessment Results',
            style: GoogleFonts.quicksand(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
            ),
          ),
          const SizedBox(height: 24),

          // Total score display
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.white.withOpacity(0.9),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.06),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: severityColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: severityColor.withOpacity(0.3),
                      width: 2,
                    ),
                  ),
                  child: Column(
                    children: [
                      Text(
                        totalScore.toStringAsFixed(1),
                        style: GoogleFonts.quicksand(
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          color: severityColor,
                        ),
                      ),
                      Text(
                        'EASI Score',
                        style: GoogleFonts.openSans(
                          fontSize: 12,
                          color: AppColors.greyText,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 20),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: severityColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          severity,
                          style: GoogleFonts.openSans(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: severityColor,
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Severity Classification',
                        style: GoogleFonts.openSans(
                          fontSize: 12,
                          color: AppColors.greyText,
                        ),
                      ),
                      Text(
                        'Score range: 0-72',
                        style: GoogleFonts.openSans(
                          fontSize: 11,
                          color: AppColors.greyText,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Regional breakdown
          Text(
            'Regional Breakdown',
            style: GoogleFonts.quicksand(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
            ),
          ),
          const SizedBox(height: 12),

          ...bodyRegions.map((region) {
            double regionScore = calculateRegionScore(region);
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.white.withOpacity(0.8),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      region,
                      style: GoogleFonts.openSans(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AppColors.darkBlue,
                      ),
                    ),
                  ),
                  Text(
                    regionScore.toStringAsFixed(2),
                    style: GoogleFonts.quicksand(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: AppColors.primaryBlue,
                    ),
                  ),
                ],
              ),
            );
          }),

          const SizedBox(height: 24),

          // Severity guide
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.lightGrey.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.info_outline,
                      size: 16,
                      color: AppColors.greyText,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'EASI Score Interpretation',
                      style: GoogleFonts.openSans(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: AppColors.darkBlue,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  '0-1: Clear • 2-7: Mild • 8-21: Moderate • 22-50: Severe • 51-72: Very Severe',
                  style: GoogleFonts.openSans(
                    fontSize: 11,
                    color: AppColors.greyText,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 30),

          // Action buttons
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () {
                    setState(() {
                      currentStep = 0;
                      // Reset all data
                      for (String region in bodyRegions) {
                        assessmentData[region] = {
                          'erythema': 0,
                          'edema': 0,
                          'excoriation': 0,
                          'lichenification': 0,
                          'area': 0,
                        };
                      }
                    });
                  },
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: AppColors.primaryBlue),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    'New Assessment',
                    style: GoogleFonts.openSans(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: AppColors.primaryBlue,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const SkinAnalysisHistoryPage(),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryBlue,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    'Save Results',
                    style: GoogleFonts.openSans(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}