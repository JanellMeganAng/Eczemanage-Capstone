import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import 'body_map_selector.dart';
import '../../services/notification_service.dart';
import '../../services/care_routine_storage.dart';
import 'care_routine_history.dart';
import '../test/notification_test_screen.dart';

/// CareRoutinePage - Create and manage eczema care routines with reminders
///
/// This screen allows users to create detailed care routines for managing their eczema,
/// including product applications, moisturizing schedules, and medication timing.
/// Integrates with notification service for reminder functionality.
///
/// Key Features:
/// - Create and edit care routines with detailed scheduling
/// - Interactive body map for selecting application areas
/// - Customizable frequency and interval settings
/// - Time-of-day selection (Morning, Afternoon, Evening, Night)
/// - Optional reminder notifications with custom intervals
/// - Product/medication tracking
/// - Notes field for additional instructions
///
/// User Interactions:
/// - Input routine details (name, type, product name)
/// - Select body areas using interactive body map
/// - Configure frequency and interval for routine
/// - Choose time-of-day preferences
/// - Toggle reminder notifications
/// - Save routine with validation
/// - Navigate to routine history
///
/// Data Flow:
/// - Reads: Existing routine data if editing (passed via constructor)
/// - Writes: Saves new routines to CareRoutineStorage
/// - Updates: Modifies existing routines
/// - Notifications: Schedules reminders through NotificationService
///
/// Validation:
/// - Routine name must not be empty
/// - Product/medication name is required
/// - At least one application area must be selected
class CareRoutinePage extends StatefulWidget {
  final Map<String, dynamic>? editingRoutine;  // Optional routine data for editing

  const CareRoutinePage({super.key, this.editingRoutine});

  @override
  State<CareRoutinePage> createState() => _CareRoutinePageState();
}

class _CareRoutinePageState extends State<CareRoutinePage> {
  // Text field controllers for user input
  final TextEditingController routineNameController = TextEditingController();
  final TextEditingController productNameController = TextEditingController();
  final TextEditingController notesController = TextEditingController();

  String selectedRoutineType = 'Moisturizer';
  String selectedFrequency = 'Daily';
  String selectedInterval = 'Every 1 mins';
  Set<String> selectedAreas = <String>{};
  Set<String> selectedTimeOfDay = <String>{};
  bool reminderEnabled = true;
  String customFrequency = '';
  String customInterval = '';
  TimeOfDay? customTime;
  String? editingRoutineId;

  final List<String> routineTypes = [
    'Moisturizer',
    'Topical medications',
    'Bathing',
    'Others',
  ];

  final List<String> frequencies = [
    'Daily',
    'Twice Daily',
    'Weekly',
    'Monthly',
    'As Needed',
  ];

  final List<String> intervals = [
    'Every 1 mins',
    'Every 1 hour',
    'Every 2 hours',
    'Every 6 hours',
    'Every 12 hours',
    'Once daily',
    'Custom',
  ];

  final List<String> timeOptions = [
    'Morning',
    'Afternoon',
    'Evening',
    'Night',
  ];

  @override
  void initState() {
    super.initState();
    _initializeForEditing();
  }

  void _initializeForEditing() {
    if (widget.editingRoutine != null) {
      final routine = widget.editingRoutine!;
      editingRoutineId = routine['id'];

      routineNameController.text = routine['routineName'] ?? '';
      productNameController.text = routine['productName'] ?? '';
      notesController.text = routine['notes'] ?? '';

      selectedRoutineType = routine['routineType'] ?? 'Moisturizer';
      selectedFrequency = routine['frequency'] ?? 'Daily';
      selectedInterval = routine['interval'] ?? 'Every 1 mins';
      selectedAreas = Set<String>.from(routine['applicationAreas'] ?? []);
      selectedTimeOfDay = Set<String>.from(routine['timeOfDay'] ?? []);
      reminderEnabled = routine['reminderEnabled'] ?? true;
    }
  }

  @override
  void dispose() {
    routineNameController.dispose();
    productNameController.dispose();
    notesController.dispose();
    super.dispose();
  }

  void _showFullBodyMapSelector() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.85,
        decoration: const BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Select Body Areas',
                    style: GoogleFonts.quicksand(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: AppColors.darkBlue,
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                    color: AppColors.greyText,
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                child: BodyMapSelector(
                  selectedAreas: selectedAreas,
                  onAreasChanged: (Set<String> areas) {
                    setState(() {
                      selectedAreas = areas;
                    });
                  },
                  showSearchBar: true,
                  showSelectedAreasHeader: true,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showCustomIntervalDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return _CustomIntervalPicker(
          onTimeSelected: (hours, minutes, period) {
            setState(() {
              customTime = TimeOfDay(hour: hours, minute: minutes);

              // Format the time as interval display (remove AM/PM for notification parsing)
              if (hours == 0 && minutes > 0) {
                customInterval = 'Every $minutes min${minutes > 1 ? 's' : ''}';
              } else if (minutes == 0 && hours > 0) {
                customInterval = 'Every $hours hour${hours > 1 ? 's' : ''}';
              } else if (hours > 0 && minutes > 0) {
                customInterval = 'Every ${hours}h ${minutes}m';
              } else {
                customInterval = 'Every 1 hour'; // fallback
              }
              selectedInterval = customInterval;
            });
          },
        );
      },
    );
  }

  String _getValidDropdownValue() {
    // If selectedInterval is in the predefined list, return it
    if (intervals.contains(selectedInterval)) {
      return selectedInterval;
    }
    // If it's a custom interval, return 'Custom' to show in dropdown
    else if (customInterval.isNotEmpty) {
      return 'Custom';
    }
    // Default fallback
    else {
      return intervals.first;
    }
  }

  List<DropdownMenuItem<String>> _getDropdownItems() {
    List<DropdownMenuItem<String>> items = intervals.map<DropdownMenuItem<String>>((String value) {
      // Always show the original value in dropdown menu items
      return DropdownMenuItem<String>(
        value: value,
        child: Text(
          value, // Shows "Custom" in the dropdown menu
          style: GoogleFonts.openSans(fontSize: 12),
          overflow: TextOverflow.ellipsis,
        ),
      );
    }).toList();

    return items;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      body: Container(
        color: const Color(0xFFF7F7F7),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 24),
                      _buildRoutineNameField(),
                      const SizedBox(height: 20),
                      _buildRoutineTypeDropdown(),
                      const SizedBox(height: 20),
                      _buildProductNameField(),
                      const SizedBox(height: 20),
                      _buildApplicationAreasSection(),
                      const SizedBox(height: 20),
                      _buildFrequencySection(),
                      const SizedBox(height: 20),
                      _buildTimeOfDaySection(),
                      const SizedBox(height: 20),
                      _buildReminderToggle(),
                      const SizedBox(height: 20),
                      _buildNotesField(),
                      const SizedBox(height: 20),
                      _buildSaveButton(),
                      const SizedBox(height: 20),
                      _buildDebugButtons(),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 20),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.primaryBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Padding(
                padding: EdgeInsets.only(left: 5),
                child: Icon(
                  Icons.arrow_back_ios,
                  color: AppColors.primaryBlue,
                  size: 20,
                ),
              ),
            ),
          ),
          Expanded(
            child: Center(
              child: Text(
                widget.editingRoutine != null ? 'Edit Routine' : 'Care Routine',
                style: GoogleFonts.quicksand(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: AppColors.primaryBlue,
                ),
              ),
            ),
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const CareRoutineHistory()),
              );
            },
            child: Container(
              padding: const EdgeInsets.all(8),
              margin: const EdgeInsets.only(right: 8),
              decoration: BoxDecoration(
                color: AppColors.primaryBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.history,
                color: AppColors.primaryBlue,
                size: 20,
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.primaryBlue.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.person,
              color: AppColors.primaryBlue,
              size: 20,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRoutineNameField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Routine Name',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppColors.lightGrey,
            borderRadius: BorderRadius.circular(12),
          ),
          child: TextField(
            controller: routineNameController,
            style: GoogleFonts.openSans(
              fontSize: 16,
              color: AppColors.darkBlue,
            ),
            decoration: InputDecoration(
              hintText: 'Enter routine name',
              hintStyle: GoogleFonts.openSans(
                fontSize: 16,
                color: AppColors.greyText,
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(16),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildRoutineTypeDropdown() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Routine Type',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppColors.lightGrey,
            borderRadius: BorderRadius.circular(12),
          ),
          child: DropdownButtonFormField<String>(
            value: selectedRoutineType,
            onChanged: (String? newValue) {
              if (newValue != null) {
                setState(() {
                  selectedRoutineType = newValue;
                });
              }
            },
            style: GoogleFonts.openSans(
              fontSize: 16,
              color: AppColors.darkBlue,
            ),
            decoration: const InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.all(16),
            ),
            dropdownColor: AppColors.white,
            icon: const Icon(
              Icons.keyboard_arrow_down,
              color: AppColors.primaryBlue,
            ),
            items: routineTypes.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildProductNameField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Product/Medication',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppColors.lightGrey,
            borderRadius: BorderRadius.circular(12),
          ),
          child: TextField(
            controller: productNameController,
            style: GoogleFonts.openSans(
              fontSize: 16,
              color: AppColors.darkBlue,
            ),
            decoration: InputDecoration(
              hintText: 'Enter product name',
              hintStyle: GoogleFonts.openSans(
                fontSize: 16,
                color: AppColors.greyText,
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(16),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildApplicationAreasSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Application Areas',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 12),
        if (selectedAreas.isNotEmpty) ...[
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.primaryBlue.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppColors.primaryBlue.withOpacity(0.3),
                width: 1,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Selected Areas (${selectedAreas.length})',
                  style: GoogleFonts.openSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppColors.darkBlue,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: selectedAreas.map((area) {
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppColors.primaryBlue,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            area,
                            style: GoogleFonts.openSans(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: AppColors.white,
                            ),
                          ),
                          const SizedBox(width: 4),
                          GestureDetector(
                            onTap: () {
                              setState(() {
                                selectedAreas.remove(area);
                              });
                            },
                            child: const Icon(Icons.close, size: 16, color: AppColors.white),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
        ],
        Container(
          height: 400,
          decoration: BoxDecoration(
            color: AppColors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.lightGrey, width: 1),
          ),
          child: BodyMapSelector(
            selectedAreas: selectedAreas,
            onAreasChanged: (Set<String> areas) {
              setState(() {
                selectedAreas = areas;
              });
            },
            showSearchBar: false,
            showSelectedAreasHeader: false,
            height: 400,
          ),
        ),
      ],
    );
  }

  Widget _buildFrequencySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Frequency & Interval',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            // Frequency Dropdown
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Frequency',
                    style: GoogleFonts.openSans(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: AppColors.greyText,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.lightGrey,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: DropdownButtonFormField<String>(
                      value: selectedFrequency,
                      onChanged: (String? newValue) {
                        if (newValue != null) {
                          setState(() {
                            selectedFrequency = newValue;
                          });
                        }
                      },
                      style: GoogleFonts.openSans(
                        fontSize: 14,
                        color: AppColors.darkBlue,
                      ),
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      ),
                      dropdownColor: AppColors.white,
                      icon: const Icon(
                        Icons.keyboard_arrow_down,
                        color: AppColors.primaryBlue,
                        size: 20,
                      ),
                      items: frequencies.map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(
                            value,
                            style: GoogleFonts.openSans(fontSize: 12),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            // Interval Dropdown
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Interval',
                    style: GoogleFonts.openSans(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: AppColors.greyText,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.lightGrey,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: DropdownButtonFormField<String>(
                      value: _getValidDropdownValue(),
                      selectedItemBuilder: (BuildContext context) {
                        return intervals.map<Widget>((String value) {
                          // Show custom interval text in the preview box when Custom is selected
                          if (value == 'Custom' && customInterval.isNotEmpty) {
                            return Text(
                              customInterval,
                              style: GoogleFonts.openSans(
                                fontSize: 14,
                                color: AppColors.darkBlue,
                              ),
                              overflow: TextOverflow.ellipsis,
                            );
                          }
                          // Show normal text for other options
                          return Text(
                            value,
                            style: GoogleFonts.openSans(
                              fontSize: 14,
                              color: AppColors.darkBlue,
                            ),
                          );
                        }).toList();
                      },
                      onChanged: (String? newValue) {
                        if (newValue != null) {
                          if (newValue == 'Custom') {
                            _showCustomIntervalDialog();
                          } else {
                            setState(() {
                              selectedInterval = newValue;
                            });
                          }
                        }
                      },
                      style: GoogleFonts.openSans(
                        fontSize: 14,
                        color: AppColors.darkBlue,
                      ),
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      ),
                      dropdownColor: AppColors.white,
                      icon: const Icon(
                        Icons.keyboard_arrow_down,
                        color: AppColors.primaryBlue,
                        size: 20,
                      ),
                      items: _getDropdownItems(),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildTimeOfDaySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Time of Day',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.lightGrey,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: timeOptions.map((time) {
              final isSelected = selectedTimeOfDay.contains(time);

              return GestureDetector(
                onTap: () {
                  setState(() {
                    if (isSelected) {
                      selectedTimeOfDay.remove(time);
                    } else {
                      selectedTimeOfDay.add(time);
                    }
                  });
                },
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? AppColors.primaryBlue
                        : AppColors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: AppColors.primaryBlue,
                      width: 1.5,
                    ),
                  ),
                  child: Column(
                    children: [
                      Icon(
                        _getTimeIcon(time),
                        size: 24,
                        color: isSelected
                            ? AppColors.white
                            : AppColors.primaryBlue,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        time,
                        style: GoogleFonts.openSans(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: isSelected
                              ? AppColors.white
                              : AppColors.primaryBlue,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  IconData _getTimeIcon(String time) {
    switch (time) {
      case 'Morning':
        return Icons.wb_sunny; // Sun icon for morning
      case 'Afternoon':
        return Icons.wb_sunny_outlined; // Outlined sun for afternoon
      case 'Evening':
        return Icons.wb_twilight; // Twilight icon for evening
      case 'Night':
        return Icons.bedtime; // Moon/night icon
      default:
        return Icons.access_time;
    }
  }

  Widget _buildReminderToggle() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.lightGrey,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Reminder',
            style: GoogleFonts.openSans(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: AppColors.darkBlue,
            ),
          ),
          Switch(
            value: reminderEnabled,
            onChanged: (value) {
              setState(() {
                reminderEnabled = value;
              });
            },
            activeColor: AppColors.primaryBlue,
            activeTrackColor: AppColors.primaryBlue.withOpacity(0.3),
          ),
        ],
      ),
    );
  }

  Widget _buildNotesField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Notes (Optional)',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.darkBlue,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppColors.lightGrey,
            borderRadius: BorderRadius.circular(12),
          ),
          child: TextField(
            controller: notesController,
            maxLines: 4,
            style: GoogleFonts.openSans(
              fontSize: 16,
              color: AppColors.darkBlue,
            ),
            decoration: InputDecoration(
              hintText: 'Add any additional notes or instructions...',
              hintStyle: GoogleFonts.openSans(
                fontSize: 16,
                color: AppColors.greyText,
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(16),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSaveButton() {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton(
        onPressed: () {
          print('🔘 SAVE BUTTON TAPPED!');
          _saveCareRoutine();
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryBlue,
          foregroundColor: AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(26),
          ),
          elevation: 2,
          shadowColor: AppColors.primaryBlue.withOpacity(0.3),
        ),
        child: Text(
          widget.editingRoutine != null ? 'Update Routine' : 'Save Care Routine',
          style: GoogleFonts.openSans(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.4,
          ),
        ),
      ),
    );
  }

  Widget _buildDebugButtons() {
    return Column(
      children: [
        Text(
          'Debug Tools',
          style: GoogleFonts.openSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.greyText,
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: () async {
                  final notificationService = NotificationService();
                  final pending = await notificationService.getPendingNotifications();
                  print('📋 Pending notifications: ${pending.length}');
                  for (var notification in pending) {
                    print('  - ID: ${notification.id}, Title: ${notification.title}');
                  }
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('${pending.length} pending notifications (check console)'),
                      backgroundColor: AppColors.greyText,
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.greyText,
                  foregroundColor: AppColors.white,
                  padding: const EdgeInsets.all(12),
                ),
                child: Text('Check Pending', style: GoogleFonts.openSans(fontSize: 12)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton(
                onPressed: () async {
                  final notificationService = NotificationService();
                  await notificationService.showImmediateNotification(
                    id: 8888,
                    title: '🧪 Debug Test',
                    body: 'This notification should appear immediately!',
                  );
                  print('🧪 Immediate debug notification sent');
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  foregroundColor: AppColors.white,
                  padding: const EdgeInsets.all(12),
                ),
                child: Text('Test Now', style: GoogleFonts.openSans(fontSize: 12)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const NotificationTestScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryBlue,
                  foregroundColor: AppColors.white,
                  padding: const EdgeInsets.all(12),
                ),
                child: Text('Notification Test', style: GoogleFonts.openSans(fontSize: 12)),
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _saveCareRoutine() {
    print('=== STARTING CARE ROUTINE SAVE ===');
    print('Reminder enabled: $reminderEnabled');

    // Validate required fields
    if (routineNameController.text.isEmpty) {
      print('❌ VALIDATION ERROR: Routine name is empty');
      _showValidationError('Please enter a routine name');
      return;
    }

    if (productNameController.text.isEmpty) {
      print('❌ VALIDATION ERROR: Product name is empty');
      _showValidationError('Please enter a product/medication name');
      return;
    }

    if (selectedAreas.isEmpty) {
      print('❌ VALIDATION ERROR: No areas selected');
      print('selectedAreas: $selectedAreas');
      _showValidationError('Please select at least one application area');
      return;
    }

    // Create the care routine data
    final routineData = {
      'routineName': routineNameController.text,
      'routineType': selectedRoutineType,
      'productName': productNameController.text,
      'applicationAreas': selectedAreas.toList(),
      'frequency': selectedFrequency,
      'interval': selectedInterval == 'Custom' ? customInterval : selectedInterval,
      'timeOfDay': selectedTimeOfDay.toList(),
      'reminderEnabled': reminderEnabled,
      'notes': notesController.text,
      'createdAt': DateTime.now().toIso8601String(),
    };

    print('Care Routine Data: $routineData');

    // If reminders are enabled, schedule them
    if (reminderEnabled) {
      print('Reminders are enabled, calling _scheduleReminders...');
      _scheduleReminders(routineData);
    } else {
      print('Reminders are DISABLED, skipping notification scheduling');
    }

    // Save to storage
    _saveToStorage(routineData);
  }

  Future<void> _saveToStorage(Map<String, dynamic> routineData) async {
    try {
      if (editingRoutineId != null) {
        // Update existing routine
        await CareRoutineStorage.updateRoutine(editingRoutineId!, routineData);
        print('✅ Care routine updated successfully');

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'Care routine updated successfully!',
                style: GoogleFonts.openSans(),
              ),
              backgroundColor: AppColors.primaryBlue,
              duration: const Duration(seconds: 2),
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
          );

          Navigator.pop(context); // Go back to history page
        }
      } else {
        // Save new routine
        await CareRoutineStorage.saveRoutine(routineData);
        print('✅ Care routine saved successfully');

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                reminderEnabled
                    ? 'Care routine saved with reminders!'
                    : 'Care routine saved successfully!',
                style: GoogleFonts.openSans(),
              ),
              backgroundColor: AppColors.primaryBlue,
              duration: const Duration(seconds: 3),
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
          );

          _clearForm();
        }
      }
    } catch (e) {
      print('❌ Error saving care routine: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Error saving routine: $e',
              style: GoogleFonts.openSans(),
            ),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    }
  }

  void _showValidationError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: GoogleFonts.openSans(),
        ),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _scheduleReminders(Map<String, dynamic> routineData) async {
    print('=== SCHEDULING REMINDERS ===');
    try {
      final notificationService = NotificationService();

      String title = _getNotificationTitle(routineData);
      String body = _getNotificationBody(routineData);
      String interval = routineData['interval'];
      List<String> timeOfDay = List<String>.from(routineData['timeOfDay']);

      // Generate unique ID based on routine name hash
      int notificationId = routineData['routineName'].hashCode.abs();

      print('Calling notificationService.scheduleRepeatingNotification with:');
      print('  ID: $notificationId');
      print('  Title: $title');
      print('  Body: $body');
      print('  Interval: "$interval"');
      print('  Time of day: $timeOfDay');

      await notificationService.scheduleRepeatingNotification(
        id: notificationId,
        title: title,
        body: body,
        interval: interval,
        timeOfDay: timeOfDay,
        payload: routineData['routineName'],
      );

      print('✅ Notification scheduling completed successfully');

      // Also send an immediate test notification to verify it works
      print('🧪 Sending immediate test notification to verify system works...');
      await notificationService.showImmediateNotification(
        id: 9999,
        title: '✅ Care Routine Saved!',
        body: 'Your "${routineData['routineName']}" routine is now scheduled. You\'ll receive reminders at your selected times!',
        payload: 'test_care_routine',
      );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Reminder notification scheduled for $interval',
            style: GoogleFonts.openSans(),
          ),
          backgroundColor: AppColors.primaryBlue.withOpacity(0.8),
          duration: const Duration(seconds: 2),
        ),
      );
    } catch (e) {
      print('❌ Error scheduling notification: $e');
      print('Stack trace: ${StackTrace.current}');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Error setting reminder: $e',
            style: GoogleFonts.openSans(),
          ),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  void _clearForm() {
    setState(() {
      routineNameController.clear();
      productNameController.clear();
      notesController.clear();
      selectedRoutineType = 'Moisturizer';
      selectedFrequency = 'Daily';
      selectedInterval = 'Every 1 mins';
      selectedAreas.clear();
      selectedTimeOfDay.clear();
      reminderEnabled = true;
      customFrequency = '';
      customInterval = '';
      customTime = null;
    });
  }

  String _getNotificationTitle(Map<String, dynamic> routineData) {
    final routineName = routineData['routineName'];
    final routineType = routineData['routineType'];
    final timeOfDay = List<String>.from(routineData['timeOfDay']);

    // Get the current time to determine appropriate greeting
    final now = DateTime.now();
    final hour = now.hour;

    String timeGreeting = '';
    if (hour >= 5 && hour < 12) {
      timeGreeting = 'Good morning!';
    } else if (hour >= 12 && hour < 17) {
      timeGreeting = 'Good afternoon!';
    } else if (hour >= 17 && hour < 21) {
      timeGreeting = 'Good evening!';
    } else {
      timeGreeting = 'Time for your routine!';
    }

    // Create personalized titles based on routine type
    switch (routineType.toLowerCase()) {
      case 'moisturizer':
        return '$timeGreeting Time for your $routineName';
      case 'topical medications':
        return '$timeGreeting Don\'t forget your $routineName medication';
      case 'bathing':
        return '$timeGreeting Time for your $routineName bath routine';
      default:
        return '$timeGreeting Time for your $routineName routine';
    }
  }

  String _getNotificationBody(Map<String, dynamic> routineData) {
    final productName = routineData['productName'];
    final routineType = routineData['routineType'];
    final applicationAreas = List<String>.from(routineData['applicationAreas']);

    String areaText = '';
    if (applicationAreas.isNotEmpty) {
      if (applicationAreas.length == 1) {
        areaText = 'to your ${applicationAreas.first.toLowerCase()}';
      } else if (applicationAreas.length == 2) {
        areaText = 'to your ${applicationAreas.join(' and ').toLowerCase()}';
      } else {
        areaText = 'to your selected areas';
      }
    } else {
      areaText = 'to your selected areas';
    }

    // Create personalized body messages based on routine type
    switch (routineType.toLowerCase()) {
      case 'moisturizer':
        return 'Apply $productName $areaText to keep your skin hydrated 💧';
      case 'topical medications':
        return 'Apply $productName $areaText as prescribed 💊';
      case 'bathing':
        return 'Time for your cleansing routine with $productName 🛁';
      default:
        return 'Don\'t forget to apply $productName $areaText ✨';
    }
  }

}

class _CustomIntervalPicker extends StatefulWidget {
  final Function(int hours, int minutes, String period) onTimeSelected;

  const _CustomIntervalPicker({
    required this.onTimeSelected,
  });

  @override
  State<_CustomIntervalPicker> createState() => _CustomIntervalPickerState();
}

class _CustomIntervalPickerState extends State<_CustomIntervalPicker> {
  int selectedHours = 1;
  int selectedMinutes = 0;
  String selectedPeriod = 'AM';

  final List<int> hours = List.generate(12, (index) => index + 1); // 1-12
  final List<int> minutes = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55];
  final List<String> periods = ['AM', 'PM'];

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: AppColors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      title: Text(
        'Set Custom Interval',
        style: GoogleFonts.quicksand(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: AppColors.darkBlue,
        ),
        textAlign: TextAlign.center,
      ),
      content: Container(
        width: double.maxFinite,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'How often should this routine repeat?',
              style: GoogleFonts.openSans(
                fontSize: 14,
                color: AppColors.greyText,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            Container(
              height: 150,
              decoration: BoxDecoration(
                color: AppColors.lightGrey,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  // Hours
                  Expanded(
                    child: Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          child: Text(
                            'Hours',
                            style: GoogleFonts.openSans(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: AppColors.darkBlue,
                            ),
                          ),
                        ),
                        Expanded(
                          child: ListWheelScrollView.useDelegate(
                            controller: FixedExtentScrollController(
                              initialItem: selectedHours - 1,
                            ),
                            itemExtent: 40,
                            perspective: 0.005,
                            diameterRatio: 1.2,
                            physics: const FixedExtentScrollPhysics(),
                            childDelegate: ListWheelChildBuilderDelegate(
                              childCount: hours.length,
                              builder: (context, index) {
                                final hour = hours[index];
                                final isSelected = hour == selectedHours;
                                return Container(
                                  alignment: Alignment.center,
                                  decoration: isSelected
                                      ? BoxDecoration(
                                          color: AppColors.primaryBlue,
                                          borderRadius: BorderRadius.circular(8),
                                        )
                                      : null,
                                  child: Text(
                                    hour.toString().padLeft(2, '0'),
                                    style: GoogleFonts.openSans(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w600,
                                      color: isSelected
                                          ? AppColors.white
                                          : AppColors.darkBlue,
                                    ),
                                  ),
                                );
                              },
                            ),
                            onSelectedItemChanged: (index) {
                              setState(() {
                                selectedHours = hours[index];
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 1,
                    height: 100,
                    color: AppColors.primaryBlue.withOpacity(0.3),
                  ),
                  // Minutes
                  Expanded(
                    child: Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          child: Text(
                            'Minutes',
                            style: GoogleFonts.openSans(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: AppColors.darkBlue,
                            ),
                          ),
                        ),
                        Expanded(
                          child: ListWheelScrollView.useDelegate(
                            controller: FixedExtentScrollController(
                              initialItem: minutes.indexOf(selectedMinutes),
                            ),
                            itemExtent: 40,
                            perspective: 0.005,
                            diameterRatio: 1.2,
                            physics: const FixedExtentScrollPhysics(),
                            childDelegate: ListWheelChildBuilderDelegate(
                              childCount: minutes.length,
                              builder: (context, index) {
                                final minute = minutes[index];
                                final isSelected = minute == selectedMinutes;
                                return Container(
                                  alignment: Alignment.center,
                                  decoration: isSelected
                                      ? BoxDecoration(
                                          color: AppColors.primaryBlue,
                                          borderRadius: BorderRadius.circular(8),
                                        )
                                      : null,
                                  child: Text(
                                    minute.toString().padLeft(2, '0'),
                                    style: GoogleFonts.openSans(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w600,
                                      color: isSelected
                                          ? AppColors.white
                                          : AppColors.darkBlue,
                                    ),
                                  ),
                                );
                              },
                            ),
                            onSelectedItemChanged: (index) {
                              setState(() {
                                selectedMinutes = minutes[index];
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 1,
                    height: 100,
                    color: AppColors.primaryBlue.withOpacity(0.3),
                  ),
                  // AM/PM
                  Expanded(
                    child: Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          child: Text(
                            'Period',
                            style: GoogleFonts.openSans(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: AppColors.darkBlue,
                            ),
                          ),
                        ),
                        Expanded(
                          child: ListWheelScrollView.useDelegate(
                            controller: FixedExtentScrollController(
                              initialItem: periods.indexOf(selectedPeriod),
                            ),
                            itemExtent: 40,
                            perspective: 0.005,
                            diameterRatio: 1.2,
                            physics: const FixedExtentScrollPhysics(),
                            childDelegate: ListWheelChildBuilderDelegate(
                              childCount: periods.length,
                              builder: (context, index) {
                                final period = periods[index];
                                final isSelected = period == selectedPeriod;
                                return Container(
                                  alignment: Alignment.center,
                                  decoration: isSelected
                                      ? BoxDecoration(
                                          color: AppColors.primaryBlue,
                                          borderRadius: BorderRadius.circular(8),
                                        )
                                      : null,
                                  child: Text(
                                    period,
                                    style: GoogleFonts.openSans(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w600,
                                      color: isSelected
                                          ? AppColors.white
                                          : AppColors.darkBlue,
                                    ),
                                  ),
                                );
                              },
                            ),
                            onSelectedItemChanged: (index) {
                              setState(() {
                                selectedPeriod = periods[index];
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.primaryBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: AppColors.primaryBlue.withOpacity(0.3),
                ),
              ),
              child: Text(
                _getDisplayText(),
                style: GoogleFonts.openSans(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppColors.primaryBlue,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(
            'Cancel',
            style: GoogleFonts.openSans(
              color: AppColors.greyText,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        ElevatedButton(
          onPressed: () {
            final convertedHours = _convertTo24Hour(selectedHours, selectedPeriod);
            widget.onTimeSelected(convertedHours, selectedMinutes, selectedPeriod);
            Navigator.pop(context);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primaryBlue,
            foregroundColor: AppColors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Text(
            'Set Interval',
            style: GoogleFonts.openSans(
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  String _getDisplayText() {
    if (selectedHours == 0 && selectedMinutes > 0) {
      return 'Every $selectedMinutes minute${selectedMinutes > 1 ? 's' : ''}';
    } else if (selectedMinutes == 0 && selectedHours > 0) {
      return 'Every $selectedHours hour${selectedHours > 1 ? 's' : ''}';
    } else if (selectedHours > 0 && selectedMinutes > 0) {
      return 'Every ${selectedHours}h ${selectedMinutes}m';
    } else {
      return 'Every 1 hour';
    }
  }

  int _convertTo24Hour(int hour12, String period) {
    if (period == 'AM') {
      return hour12 == 12 ? 0 : hour12;
    } else {
      return hour12 == 12 ? 12 : hour12 + 12;
    }
  }
}