import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../../services/care_routine_storage.dart';
import '../../services/notification_service.dart';
import 'care_routine_page.dart';

class CareRoutineHistory extends StatefulWidget {
  const CareRoutineHistory({super.key});

  @override
  State<CareRoutineHistory> createState() => _CareRoutineHistoryState();
}

class _CareRoutineHistoryState extends State<CareRoutineHistory> {
  List<Map<String, dynamic>> routines = [];
  bool isLoading = true;
  String searchQuery = '';

  @override
  void initState() {
    super.initState();
    _loadRoutines();
  }

  Future<void> _loadRoutines() async {
    setState(() => isLoading = true);
    final loadedRoutines = await CareRoutineStorage.getAllRoutines();

    // Sort by creation date (newest first)
    loadedRoutines.sort((a, b) {
      final dateA = DateTime.parse(a['createdAt'] ?? DateTime.now().toIso8601String());
      final dateB = DateTime.parse(b['createdAt'] ?? DateTime.now().toIso8601String());
      return dateB.compareTo(dateA);
    });

    setState(() {
      routines = loadedRoutines;
      isLoading = false;
    });
  }

  List<Map<String, dynamic>> get filteredRoutines {
    if (searchQuery.isEmpty) return routines;

    return routines.where((routine) {
      final routineName = routine['routineName']?.toString().toLowerCase() ?? '';
      final productName = routine['productName']?.toString().toLowerCase() ?? '';
      final routineType = routine['routineType']?.toString().toLowerCase() ?? '';
      final query = searchQuery.toLowerCase();

      return routineName.contains(query) ||
             productName.contains(query) ||
             routineType.contains(query);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildSearchBar(),
            _buildStatsBar(),
            Expanded(
              child: isLoading
                  ? _buildLoadingState()
                  : routines.isEmpty
                      ? _buildEmptyState()
                      : _buildRoutinesList(),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const CareRoutinePage()),
          ).then((_) => _loadRoutines());
        },
        backgroundColor: AppColors.primaryBlue,
        foregroundColor: AppColors.white,
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 16),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.primaryBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Padding(
                padding: EdgeInsets.only(left: 5),
                child: Icon(
                  Icons.arrow_back_ios,
                  color: AppColors.primaryBlue,
                  size: 20,
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Care Routine History',
                  style: GoogleFonts.quicksand(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primaryBlue,
                  ),
                ),
                Text(
                  'Manage your saved routines',
                  style: GoogleFonts.openSans(
                    fontSize: 14,
                    color: AppColors.greyText,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(24, 0, 24, 16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryBlue.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TextField(
        onChanged: (value) => setState(() => searchQuery = value),
        style: GoogleFonts.openSans(fontSize: 16),
        decoration: InputDecoration(
          hintText: 'Search routines...',
          hintStyle: GoogleFonts.openSans(
            fontSize: 16,
            color: AppColors.greyText,
          ),
          prefixIcon: const Icon(
            Icons.search,
            color: AppColors.greyText,
          ),
          suffixIcon: searchQuery.isNotEmpty
              ? GestureDetector(
                  onTap: () => setState(() => searchQuery = ''),
                  child: const Icon(
                    Icons.clear,
                    color: AppColors.greyText,
                  ),
                )
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.all(16),
        ),
      ),
    );
  }

  Widget _buildStatsBar() {
    final filtered = filteredRoutines;
    return Container(
      margin: const EdgeInsets.fromLTRB(24, 0, 24, 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.primaryBlue.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppColors.primaryBlue.withOpacity(0.2),
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.schedule,
            color: AppColors.primaryBlue,
            size: 20,
          ),
          const SizedBox(width: 8),
          Text(
            searchQuery.isEmpty
                ? 'Total: ${routines.length} routine${routines.length != 1 ? 's' : ''}'
                : 'Found: ${filtered.length} of ${routines.length} routine${routines.length != 1 ? 's' : ''}',
            style: GoogleFonts.openSans(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: AppColors.primaryBlue,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return const Center(
      child: CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryBlue),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.primaryBlue.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.event_note,
              size: 48,
              color: AppColors.primaryBlue.withOpacity(0.7),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'No Care Routines Yet',
            style: GoogleFonts.quicksand(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Create your first care routine to\nstart tracking your skincare journey',
            textAlign: TextAlign.center,
            style: GoogleFonts.openSans(
              fontSize: 16,
              color: AppColors.greyText,
            ),
          ),
          const SizedBox(height: 32),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.primaryBlue.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppColors.primaryBlue.withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.add_circle_outline,
                  color: AppColors.primaryBlue,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Text(
                  'Tap the + button to create your first routine',
                  style: GoogleFonts.openSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: AppColors.primaryBlue,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRoutinesList() {
    final filtered = filteredRoutines;

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
      itemCount: filtered.length,
      itemBuilder: (context, index) {
        final routine = filtered[index];
        return _buildRoutineCard(routine, index);
      },
    );
  }

  Widget _buildRoutineCard(Map<String, dynamic> routine, int index) {
    final routineName = routine['routineName'] ?? 'Unnamed Routine';
    final productName = routine['productName'] ?? 'No Product';
    final routineType = routine['routineType'] ?? 'General';
    final applicationAreas = List<String>.from(routine['applicationAreas'] ?? []);
    final interval = routine['interval'] ?? 'No Schedule';
    final reminderEnabled = routine['reminderEnabled'] ?? false;
    final createdAt = DateTime.parse(routine['createdAt'] ?? DateTime.now().toIso8601String());

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryBlue.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => _showRoutineDetails(routine),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: _getRoutineTypeColor(routineType).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        _getRoutineTypeIcon(routineType),
                        color: _getRoutineTypeColor(routineType),
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            routineName,
                            style: GoogleFonts.quicksand(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: AppColors.darkBlue,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            productName,
                            style: GoogleFonts.openSans(
                              fontSize: 14,
                              color: AppColors.greyText,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () => _showCustomMenu(context, routine),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: const Color(0xFF474ed8).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.more_vert,
                          color: Color(0xFF474ed8),
                          size: 20,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                _buildInfoRow(Icons.category, routineType),
                const SizedBox(height: 6),
                _buildInfoRow(Icons.schedule, interval),
                const SizedBox(height: 6),
                _buildInfoRow(
                  Icons.accessibility_new,
                  applicationAreas.isEmpty
                      ? 'No areas selected'
                      : applicationAreas.length <= 2
                          ? applicationAreas.join(', ')
                          : '${applicationAreas.take(2).join(', ')} +${applicationAreas.length - 2} more',
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: reminderEnabled
                            ? AppColors.primaryBlue.withOpacity(0.1)
                            : AppColors.greyText.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: reminderEnabled
                              ? AppColors.primaryBlue.withOpacity(0.2)
                              : AppColors.greyText.withOpacity(0.2),
                          width: 1,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.notifications_outlined,
                            size: 14,
                            color: reminderEnabled ? AppColors.primaryBlue : AppColors.greyText,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            'Reminders',
                            style: GoogleFonts.openSans(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: reminderEnabled ? AppColors.primaryBlue : AppColors.greyText,
                            ),
                          ),
                          const SizedBox(width: 8),
                          GestureDetector(
                            onTap: () => _toggleReminder(routine, index),
                            child: Container(
                              width: 36,
                              height: 20,
                              decoration: BoxDecoration(
                                color: reminderEnabled
                                    ? AppColors.primaryBlue
                                    : AppColors.greyText.withOpacity(0.3),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: AnimatedAlign(
                                duration: const Duration(milliseconds: 200),
                                alignment: reminderEnabled
                                    ? Alignment.centerRight
                                    : Alignment.centerLeft,
                                child: Container(
                                  width: 16,
                                  height: 16,
                                  margin: const EdgeInsets.all(2),
                                  decoration: const BoxDecoration(
                                    color: Colors.white,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    Text(
                      _formatDate(createdAt),
                      style: GoogleFonts.openSans(
                        fontSize: 12,
                        color: AppColors.greyText,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String text) {
    return Row(
      children: [
        Icon(
          icon,
          size: 16,
          color: AppColors.greyText,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: GoogleFonts.openSans(
              fontSize: 13,
              color: AppColors.greyText,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  Color _getRoutineTypeColor(String type) {
    switch (type.toLowerCase()) {
      case 'moisturizer':
        return Colors.blue;
      case 'topical medications':
        return Colors.red;
      case 'bathing':
        return Colors.teal;
      default:
        return AppColors.primaryBlue;
    }
  }

  IconData _getRoutineTypeIcon(String type) {
    switch (type.toLowerCase()) {
      case 'moisturizer':
        return Icons.water_drop;
      case 'topical medications':
        return Icons.medical_services;
      case 'bathing':
        return Icons.bathtub;
      default:
        return Icons.healing;
    }
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays == 0) {
      return 'Today';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }

  Future<void> _toggleReminder(Map<String, dynamic> routine, int index) async {
    try {
      final routineId = routine['id'];
      final currentReminderEnabled = routine['reminderEnabled'] ?? false;

      // Update the routine data
      routine['reminderEnabled'] = !currentReminderEnabled;

      // Update in storage
      await CareRoutineStorage.updateRoutine(routineId, routine);

      // Update notifications
      final notificationService = NotificationService();
      final notificationId = routine['routineName'].hashCode.abs();

      if (!currentReminderEnabled) {
        // Enable notifications
        await notificationService.scheduleRepeatingNotification(
          id: notificationId,
          title: _getNotificationTitle(routine),
          body: _getNotificationBody(routine),
          interval: routine['interval'] ?? 'Every 1 hour',
          timeOfDay: List<String>.from(routine['timeOfDay'] ?? []),
          payload: routine['routineName'],
        );
      } else {
        // Disable notifications
        await notificationService.cancelNotification(notificationId);
      }

      // Update the local state
      setState(() {
        routines[index] = routine;
      });

      // Show feedback
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              !currentReminderEnabled
                  ? 'Reminders enabled for ${routine['routineName']}'
                  : 'Reminders disabled for ${routine['routineName']}',
              style: GoogleFonts.openSans(),
            ),
            backgroundColor: !currentReminderEnabled ? AppColors.primaryBlue : AppColors.greyText,
            duration: const Duration(seconds: 2),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
        );
      }
    } catch (e) {
      print('Error toggling reminder: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Error updating reminder: $e',
              style: GoogleFonts.openSans(),
            ),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  String _getNotificationTitle(Map<String, dynamic> routineData) {
    final routineName = routineData['routineName'];
    final routineType = routineData['routineType'];

    // Get the current time to determine appropriate greeting
    final now = DateTime.now();
    final hour = now.hour;

    String timeGreeting = '';
    if (hour >= 5 && hour < 12) {
      timeGreeting = 'Good morning!';
    } else if (hour >= 12 && hour < 17) {
      timeGreeting = 'Good afternoon!';
    } else if (hour >= 17 && hour < 21) {
      timeGreeting = 'Good evening!';
    } else {
      timeGreeting = 'Time for your routine!';
    }

    // Create personalized titles based on routine type
    switch (routineType.toLowerCase()) {
      case 'moisturizer':
        return '$timeGreeting Time for your $routineName';
      case 'topical medications':
        return '$timeGreeting Don\'t forget your $routineName medication';
      case 'bathing':
        return '$timeGreeting Time for your $routineName bath routine';
      default:
        return '$timeGreeting Time for your $routineName routine';
    }
  }

  String _getNotificationBody(Map<String, dynamic> routineData) {
    final productName = routineData['productName'];
    final routineType = routineData['routineType'];
    final applicationAreas = List<String>.from(routineData['applicationAreas'] ?? []);

    String areaText = '';
    if (applicationAreas.isNotEmpty) {
      if (applicationAreas.length == 1) {
        areaText = 'to your ${applicationAreas.first.toLowerCase()}';
      } else if (applicationAreas.length == 2) {
        areaText = 'to your ${applicationAreas.join(' and ').toLowerCase()}';
      } else {
        areaText = 'to your selected areas';
      }
    } else {
      areaText = 'to your selected areas';
    }

    // Create personalized body messages based on routine type
    switch (routineType.toLowerCase()) {
      case 'moisturizer':
        return 'Apply $productName $areaText to keep your skin hydrated 💧';
      case 'topical medications':
        return 'Apply $productName $areaText as prescribed 💊';
      case 'bathing':
        return 'Time for your cleansing routine with $productName 🛁';
      default:
        return 'Don\'t forget to apply $productName $areaText ✨';
    }
  }

  void _showCustomMenu(BuildContext context, Map<String, dynamic> routine) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildCustomMenuSheet(routine),
    );
  }

  Widget _buildCustomMenuSheet(Map<String, dynamic> routine) {
    final routineName = routine['routineName'] ?? 'Unnamed Routine';

    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFF474ed8).withOpacity(0.1),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF474ed8).withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    _getRoutineTypeIcon(routine['routineType'] ?? ''),
                    color: const Color(0xFF474ed8),
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        routineName,
                        style: GoogleFonts.quicksand(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: AppColors.darkBlue,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        'Choose an action',
                        style: GoogleFonts.openSans(
                          fontSize: 12,
                          color: AppColors.greyText,
                        ),
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppColors.greyText.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Icon(
                      Icons.close,
                      color: AppColors.greyText,
                      size: 16,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Menu Items
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                _buildCustomMenuItem(
                  icon: Icons.edit_outlined,
                  title: 'Edit Routine',
                  subtitle: 'Modify routine settings',
                  iconColor: Colors.orange,
                  onTap: () {
                    Navigator.pop(context);
                    _editRoutine(routine);
                  },
                ),
                const SizedBox(height: 4),
                _buildCustomMenuItem(
                  icon: Icons.delete_outline,
                  title: 'Delete Routine',
                  subtitle: 'Remove this routine permanently',
                  iconColor: Colors.red,
                  onTap: () {
                    Navigator.pop(context);
                    _deleteRoutine(routine);
                  },
                ),
              ],
            ),
          ),

          // Bottom padding for safe area
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _buildCustomMenuItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color iconColor,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: iconColor.withOpacity(0.05),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: iconColor.withOpacity(0.1),
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: iconColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  icon,
                  color: iconColor,
                  size: 20,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: GoogleFonts.quicksand(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: AppColors.darkBlue,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: GoogleFonts.openSans(
                        fontSize: 12,
                        color: AppColors.greyText,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_ios,
                color: AppColors.greyText.withOpacity(0.5),
                size: 14,
              ),
            ],
          ),
        ),
      ),
    );
  }


  void _showRoutineDetails(Map<String, dynamic> routine) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildRoutineDetailsSheet(routine),
    );
  }

  Widget _buildRoutineDetailsSheet(Map<String, dynamic> routine) {
    final routineName = routine['routineName'] ?? 'Unnamed Routine';
    final productName = routine['productName'] ?? 'No Product';
    final routineType = routine['routineType'] ?? 'General';
    final applicationAreas = List<String>.from(routine['applicationAreas'] ?? []);
    final frequency = routine['frequency'] ?? 'Not Set';
    final interval = routine['interval'] ?? 'Not Set';
    final timeOfDay = List<String>.from(routine['timeOfDay'] ?? []);
    final reminderEnabled = routine['reminderEnabled'] ?? false;
    final notes = routine['notes'] ?? '';
    final createdAt = DateTime.parse(routine['createdAt'] ?? DateTime.now().toIso8601String());

    return Container(
      height: MediaQuery.of(context).size.height * 0.75,
      decoration: const BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _getRoutineTypeColor(routineType).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    _getRoutineTypeIcon(routineType),
                    color: _getRoutineTypeColor(routineType),
                    size: 24,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        routineName,
                        style: GoogleFonts.quicksand(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: AppColors.darkBlue,
                        ),
                      ),
                      Text(
                        'Created ${_formatDate(createdAt)}',
                        style: GoogleFonts.openSans(
                          fontSize: 14,
                          color: AppColors.greyText,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close, color: AppColors.greyText),
                ),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildDetailSection('Product/Medication', productName, Icons.medication),
                  _buildDetailSection('Routine Type', routineType, Icons.category),
                  _buildDetailSection('Frequency', frequency, Icons.repeat),
                  _buildDetailSection('Interval', interval, Icons.schedule),
                  if (timeOfDay.isNotEmpty)
                    _buildDetailSection('Time of Day', timeOfDay.join(', '), Icons.access_time),
                  if (applicationAreas.isNotEmpty)
                    _buildDetailSection(
                      'Application Areas (${applicationAreas.length})',
                      applicationAreas.join(', '),
                      Icons.accessibility_new,
                    ),
                  _buildDetailSection(
                    'Reminders',
                    reminderEnabled ? 'Enabled' : 'Disabled',
                    reminderEnabled ? Icons.notifications_active : Icons.notifications_off,
                  ),
                  if (notes.isNotEmpty)
                    _buildDetailSection('Notes', notes, Icons.note),
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {
                            Navigator.pop(context);
                            _editRoutine(routine);
                          },
                          icon: const Icon(Icons.edit),
                          label: Text(
                            'Edit Routine',
                            style: GoogleFonts.openSans(fontWeight: FontWeight.w600),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primaryBlue,
                            foregroundColor: AppColors.white,
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                          _deleteRoutine(routine);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red.withOpacity(0.1),
                          foregroundColor: Colors.red,
                          padding: const EdgeInsets.all(12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Icon(Icons.delete),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailSection(String title, String content, IconData icon) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.lightGrey,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 16, color: AppColors.primaryBlue),
              const SizedBox(width: 8),
              Text(
                title,
                style: GoogleFonts.openSans(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppColors.primaryBlue,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            content,
            style: GoogleFonts.openSans(
              fontSize: 14,
              color: AppColors.darkBlue,
            ),
          ),
        ],
      ),
    );
  }

  void _editRoutine(Map<String, dynamic> routine) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CareRoutinePage(editingRoutine: routine),
      ),
    ).then((_) => _loadRoutines());
  }

  void _deleteRoutine(Map<String, dynamic> routine) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          'Delete Routine',
          style: GoogleFonts.quicksand(
            fontWeight: FontWeight.bold,
            color: AppColors.darkBlue,
          ),
        ),
        content: Text(
          'Are you sure you want to delete "${routine['routineName']}"? This action cannot be undone.',
          style: GoogleFonts.openSans(color: AppColors.greyText),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: GoogleFonts.openSans(
                color: AppColors.greyText,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await _confirmDelete(routine);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: AppColors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: Text(
              'Delete',
              style: GoogleFonts.openSans(fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmDelete(Map<String, dynamic> routine) async {
    try {
      // Cancel related notifications
      final notificationService = NotificationService();
      final notificationId = routine['routineName'].hashCode.abs();
      await notificationService.cancelNotification(notificationId);

      // Delete from storage
      await CareRoutineStorage.deleteRoutine(routine['id']);

      // Reload the list
      await _loadRoutines();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Routine "${routine['routineName']}" deleted successfully',
              style: GoogleFonts.openSans(),
            ),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Error deleting routine: $e',
              style: GoogleFonts.openSans(),
            ),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }
}