import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_colors.dart';
import '../onboarding/onboarding_flow.dart';

/// ConsentPage - User consent and terms acceptance screen
///
/// This screen presents users with the application's terms and conditions,
/// requesting explicit consent before proceeding with account registration.
/// It serves as a compliance checkpoint in the onboarding process.
///
/// Key Features:
/// - Displays consent text and terms of service information
/// - Presents two action buttons for user decision (Agree/Do Not Agree)
/// - Uses custom card layout with asymmetric design for visual interest
/// - Implements brand-consistent typography and color scheme
///
/// User Interactions:
/// - "AGREE" button: User accepts terms and proceeds to onboarding flow
/// - "DO NOT AGREE" button: User declines and returns to previous screen
///
/// Data Flow:
/// - Read-only display screen with no data persistence
/// - Does not store consent status (handled in subsequent registration)
///
/// Navigation:
/// - Forward: OnboardingFlow (if user agrees)
/// - Backward: Returns to WelcomeScreen (if user does not agree)
class ConsentPage extends StatelessWidget {
  const ConsentPage({super.key});

  /// Builds the consent page with asymmetric card layout
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 40),
              // Title Section
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: _buildPageTitle(),
              ),
              const SizedBox(height: 40),
              // Card Section - Right aligned
              Expanded(
                child: Stack(
                  children: [
                    Positioned(
                      top: 0,
                      bottom: 0,
                      right: 0,
                      width: MediaQuery.of(context).size.width * 0.93,
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 40),
                        decoration: BoxDecoration(
                          color: AppColors.white,
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(32),
                            bottomLeft: Radius.circular(32),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.08),
                              blurRadius: 24,
                              offset: const Offset(-4, 8),
                            ),
                          ],
                        ),
                        child: _buildCardContent(context),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Builds the page title section with multi-line heading
  ///
  /// Creates a welcoming header split across multiple lines for emphasis.
  Widget _buildPageTitle() {
    return SizedBox(
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Welcome to',
            style: GoogleFonts.quicksand(
              fontSize: 35,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
              height: 1.2,
            ),
          ),
          Text(
            'EczeManage',
            style: GoogleFonts.quicksand(
              fontSize: 35,
              fontWeight: FontWeight.bold,
              color: AppColors.darkBlue,
              height: 1.2,
            ),
          ),
        ],
      ),
    );
  }

  /// Builds the main card content with consent text and action buttons
  ///
  /// Contains the consent header, descriptive text, and decision buttons.
  /// Uses flexible spacing to maintain layout across different screen sizes.
  Widget _buildCardContent(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(40, 48, 32, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildConsentHeader(),
          const SizedBox(height: 24),
          _buildConsentText(),
          const Spacer(),
          _buildButtons(context),
        ],
      ),
    );
  }

  /// Builds the consent header with multi-line text explaining the request
  ///
  /// Breaks the consent question across multiple lines for readability.
  Widget _buildConsentHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'The Eczema App asks',
          style: GoogleFonts.quicksand(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: AppColors.darkBlue,
            height: 1.3,
          ),
        ),
        Text(
          'for your consent for',
          style: GoogleFonts.quicksand(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: AppColors.darkBlue,
            height: 1.3,
          ),
        ),
        Text(
          'the following:',
          style: GoogleFonts.quicksand(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: AppColors.darkBlue,
            height: 1.3,
          ),
        ),
      ],
    );
  }

  /// Builds the main consent description text
  ///
  /// Displays the terms and conditions information that users must read
  /// before proceeding with registration.
  Widget _buildConsentText() {
    return Text(
      'By using EczeManage, you consent to the collection and storage of your health information for the purpose of tracking and managing your eczema condition. Your data will be stored securely and used solely to provide personalized care insights. You may withdraw consent and request data deletion at any time through the app settings. This app is not a substitute for professional medical advice.',
      textAlign: TextAlign.justify,
      style: GoogleFonts.openSans(
        fontSize: 17,
        fontWeight: FontWeight.w400,
        color: AppColors.darkBlue.withValues(alpha: 0.8),
        height: 1.6,
      ),
    );
  }

  /// Builds the action buttons for user consent decision
  ///
  /// Creates two vertically stacked buttons:
  /// - AGREE: Proceeds to onboarding flow
  /// - DO NOT AGREE: Returns to welcome screen
  Widget _buildButtons(BuildContext context) {
    return Center(
      child: SizedBox(
        width: 280, // Fixed width for consistent button sizing
        child: Column(
          children: [
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: () {
                  // User accepts terms - proceed to onboarding
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const OnboardingFlow(),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryBlue,
                  foregroundColor: AppColors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(26),
                  ),
                  elevation: 2,
                  shadowColor: AppColors.primaryBlue.withValues(alpha: 0.3),
                ),
                child: Text(
                  'AGREE',
                  style: GoogleFonts.openSans(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: AppColors.white,
                    letterSpacing: 0.4,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: () {
                  // User declines terms - return to welcome screen
                  Navigator.pop(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryBlue,
                  foregroundColor: AppColors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(26),
                  ),
                  elevation: 2,
                  shadowColor: AppColors.primaryBlue.withValues(alpha: 0.3),
                ),
                child: Text(
                  'DO NOT AGREE',
                  style: GoogleFonts.openSans(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppColors.white,
                    letterSpacing: 0.4,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
